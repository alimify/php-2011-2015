<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013
// Don't change below definitions if you don't know it's value :p

define('act',$_GET['act']);
define('url1','http://desitape.net');
define('url2','http://lyrics.desitape.net');
define('url3','http://pendufun.com');
define('index','index.php');
define('t',$_GET['t']);
define('arrow','<img src="arrow.gif" /> ');
define('darrow','<img src="dload.png" /> ');
define('height',''); // Set blank for default image size
define('width',''); // Set blank for default image size
define('PromoTitle','CXUideas'); // Used in Mp3 tag
define('albumart',''.str_replace(end(explode('/',$_SERVER['SCRIPT_NAME'])),'cover.png','http://'.$_SERVER['SERVER_NAME'].''.$_SERVER['PHP_SELF'].'')).''; // Path to the album art
$p = $_GET['p'];
?>
