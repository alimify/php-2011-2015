<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$ch = curl_init();
$url = ''.url2.'/muzic/exview.php?cat='.$_GET['cat'].'&p='.$_GET['p'].'';
include 'curl.php';
preg_match_all('|<title>(.*?)</title>|',$store,$outs);
echo $outs[0][0];
preg_match_all('|<a href="/muzic/view/(.*?)">(.*?)</a>|is',$store,$outs);
foreach($outs[1] as $out){
$out = urlencode($out);
$lname = $outs[2][$i];
echo '<div class="l"><a href="'.index.'?act=c&t='.$out.'">'.$lname.'</a></div>';
$i++;
}
// To Get Next, Back pages
if(preg_match('/Next/',$store) || preg_match('/Back/',$store)){
preg_match_all('|<a href="exview.php(.*?)">(.*?)</a>|is',$store,$outs);
$i=0;
foreach($outs[1] as $out){
$l = $outs[2][$i];
echo '<a href="'.$out.'">'.$l.'</a><br>';
$i++;
}}
include 'footer.php';
?>
