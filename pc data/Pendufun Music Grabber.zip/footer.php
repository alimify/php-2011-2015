<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

echo '<div align="center"><div class="footend"><table><tr><td align="left"></td><td>Developed by: <a href="index.php">CXUideas</a></td></td></tr></table></div>';
?>
