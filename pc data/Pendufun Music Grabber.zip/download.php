<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

ob_start();
include 'header.php';
$ch = curl_init();
$act = $_GET['act'];
if($act=='a'){
echo '<title>Download</title>';
$url = ''.url3.'/muzic/download/'.t.'';
include 'curl.php';
preg_match_all('|<a href="/muzicpc/dload.php(.*?)">(.*?)</a>|is',$store,$outs);
$i=0;
echo '<div class="t">Download</div>';
foreach($outs[1] as $out){
$l = $outs[2][$i];
$l = str_replace('<font color=red>',null,$l);
$l = str_replace('</font>',null,$l);
echo '<div class="l">'.darrow.'<a href="download.php'.$out.'&t='.t.'&act=b">'.$l.'</a></div>'; $i++;}
}
if($act=='b'){
$url = ''.url3.'/muzicpc/dload.php?id='.$_GET['id'].'&b='.$_GET['b'].'&cat='.$_GET['cat'].'';
$t = str_replace('.html',null,$_GET['t']);
$t = str_replace('/','-',$t);
$save = 'datas/'.$t.'.mp3';
if(!file_exists($save)){
if(copy($url,$save)){
include 'id.php';
header("location:$save");
} else echo 'Your Hosting does not allow copy function'; }
else { header("location:$save"); }
}
include 'footer.php';
ob_flush();
?>
