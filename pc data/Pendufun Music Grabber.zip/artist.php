<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact: cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$ch = curl_init();
$url = ''.url3.'/muzic/artist/'.t.'';
include 'curl.php';
preg_match_all('|<title>(.*?)</title>|',$store,$ts);
$title = ''.$ts[1][0].'';
echo '<title>'.$title.'</title>';
preg_match_all('|<a href="/muzic/view/(.*?)">(.*?)</a>|',$store,$outs);
include 'search.php';
echo '<div class="t">'.$title.'</div>';
foreach($outs[0] as $out){
$out = str_replace('/muzic/view/','index.php?act=c&t=',$out);
echo '<div class="l">'.$out.' (<font color="green">'.$title.'</font>)</div>'; }
include 'footer.php';
?>
