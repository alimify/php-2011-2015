<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact: cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$ch = curl_init();
$t = ''.t.'';
$i =0;
$act = $_GET['act'];
if(empty($act)){
$url = ''.url2.'/muzic/'.$_GET['ciat'].'.php';
include 'curl.php';
if($_GET['ciat']=='hindi_music'){
echo '<title>Hindi Music</title>'; }
preg_match_all('|<a href="(.*?)">(.*?)</a>|',$store,$outs);
if($_GET['ciat']=='punjabi_music'){
echo '<title>Punjabi Music</title>';
echo '<div class="t">Punjabi Music</div>';
}
foreach($outs[0] as $out){
if(!preg_match('/Home/',$out) && !preg_match('/vippendu.com/i',$out) && !preg_match('/Uploaded/i',$out) && !preg_match('/click/i',$out)){
$out = str_replace('punjabi_atoz_albums.php','view_atoz_albums.php?ciat=punjabi',$out);
$out = str_replace('/singles/','singles.php?ciat=',$out);
$out = str_replace('/catall/',''.index.'?act=b&t=',$out);
$out = str_replace('/top-30/','top30.php?tiat=',$out);
$out = str_replace('singles/','singles.php?ciat=',$out);
$out = str_replace('hindi_atoz_albums.php','view_atoz_albums.php?ciat=hindi',$out);
$out = str_replace('punjabi_atoz_artist.php','atoz_artist.php?ciat=punjabi',$out);
$out = str_replace('hindi_atoz_artist.php','atoz_artist.php?ciat=hindi',$out);
$out = str_replace('/cat_hq/','view_music.php?act=hq&t=',$out);
$out = str_replace('cat_hq/','view_music.php?act=hq&t=',$out);
$out = str_replace('/muzic','',$out);
$out = str_replace('/cat/',''.index.'?act=b&t=',$out);
$out = str_replace('cat/',''.index.'?act=b&t=',$out);
$out = str_replace('/cat_lq/','view_music.php?act=lq&t=',$out);
$out = str_replace('cat_lq/','view_music.php?act=lq&t=',$out);
if($_GET['ciat']=='hindi_music'){
if($i=='0'){
$t = '<div class="t">Bollywood Movies Music</div>'; }
else{$t=''; }
if($i=='5'){
$t2 = '<div class="t">Hindi Music</div>'; }
else{$t2=''; }
if($i=='2'){$b='<font color="red">[128 kbps]</font>';}
else{$b='';}
if($i=='6'){$b2='<font color="red">[128 kbps]</font>';}
else{$b2='';}
if($i=='7'){$b3='<img src="new.png" />';}
else{$b3='';}}
else{
if($i=='2'){
$b = '<font color="red">[128 kbps]</font>';}
else{$b='';}}
$banner = ''.$b.''.$b2.''.$b3.''.$b4.'';
echo ''.$t.''.$t2.'';
echo '<div class="l">'.arrow.''.$out.' '.$banner.'</div>';
$i++;
}}}
if($act=='lq' || $act=='hq'){
$url = ''.url2.'/muzic/cat_'.$_GET['act'].'/'.t.'';
include 'curl.php';
preg_match_all('|<a href="'.url3.'/muzic/view_'.$_GET['act'].'/(.*?)">(.*?)</a>|',$store,$outs);
$i =0;
preg_match_all('|<title>(.*?)</title>|is',$store,$ts);
echo '<title>'.$ts[1][0].'</title><div class="t">'.$ts[1][0].'</div>';
foreach($outs[1] as $lnk){
$lnkname = $outs[2][$i];
echo '<div class="l">'.arrow.'<a href="view_q.php?t='.$lnk.'">'.$lnkname.'</a></div>';
$i++; }
if(empty($p)){
preg_match_all('|Page 1 of (.*?) <a|is',$store,$outs);
echo str_replace('<a',null,$outs[0][0]); }
if(preg_match('/ Next .../',$store)){
preg_match_all('|<a class="btn" href="/muzic/cat_'.$_GET['act'].'/(.*?)"> Next ...</a>|',$store,$nxts);
$nxts[1][0] = str_replace('/muzic/cat_'.$_GET['act'].'/','view_music.php?act='.$_GET['act'].'&t=',$nxts[1][0]);
$nxts[1][0] = str_replace('.. Back ','Back',$nxts[1][0]);
echo '<a href="view_music.php?act='.$_GET['act'].'&t='.$nxts[1][0].'">Next</a>'; include 'quik_way.php'; }
}
include 'footer.php';
?>
