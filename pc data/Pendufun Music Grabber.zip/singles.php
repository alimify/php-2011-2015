<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
echo '<title>Singles</title><div class="t">Singles</div>';
$ch = curl_init();
$url = ''.url2.'/muzic/singles/'.$_GET['ciat'].'';
include 'curl.php';
$i =0;
preg_match_all('|<a href="'.url3.'/muzic/download/(.*?)">(.*?)</a>(.*?)<br|is',$store,$outs);
foreach($outs[1] as $out){
$f = str_replace('class="style1"','style="color:green;"',$outs[3][$i]);
$lname = $outs[2][$i];
echo '<div class="l">'.arrow.'<a href="download.php?act=a&t='.$out.'">'.$lname.'</a>'.$f.'</div>';
$i++;
}
if(empty($p)){
preg_match_all('|Page 1 of (.*?) <a|is',$store,$outs);
echo str_replace('<a',null,$outs[0][0]); }
if(preg_match('/ Next .../',$store)){
preg_match_all('|<a class="btn" href="/muzic/singles/(.*?)"> Next ...</a>|',$store,$nxts);
$nxts[1][0] = str_replace('/muzic/singles/','singles.php?ciat=',$nxts[1][0]);
$nxts[1][0] = str_replace('.. Back ','Back',$nxts[1][0]);
echo '<a href="?ciat='.$nxts[1][0].'">Next</a>'; include 'quik_way.php';}
include_once 'footer.php';
?>
