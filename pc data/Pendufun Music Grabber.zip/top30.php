<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact: cxuideas@gmail.com
// Scripted on 19/05/2013

include_once 'header.php';
$tiat = $_GET['tiat'];
if(!empty($tiat)){
$ch = curl_init();
$url = ''.url2.'/muzic/top-30/'.$tiat.'';
include 'curl.php';
preg_match_all('|<a href="(.*?)">(.*?)</a>|is',$store,$outs);
preg_match_all('|<title>(.*?)</title>|is',$store,$ts);

echo $ts[0][0];
echo '<div class="t">Top 30</div>';
$i=0;
foreach($outs[0] as $out){
if(preg_match('/muzic\/download\//i',$out)){
$j = $i+1; // To start from 1 instead of 0
$out = str_replace('/muzic/download/','download.php?act=a&t=',$out);
echo '<div class="l"><font color="green">'.$j.'.</font> '.$out.'</div>'; $i++;}
}
include 'footer.php'; }
else{
preg_match_all('|<a href="/muzic/top-30/(.*?)">(.*?)</a>|is',$store,$outs);
echo '<div class="l">'.arrow.' <a href="top30.php?tiat='.$outs[1][0].'">'.$outs[2][0].'</a></div>'; }
?>
