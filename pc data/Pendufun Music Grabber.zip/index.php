<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$act = ''.act.'';
$ch = curl_init();
if(empty($act)){
include 'search.php';
echo '<div class="t">Menu</div>';
echo '<title>PenduFun Music Grabber by CXUideas</title>';
$url = ''.url1.'/old.php';
include 'curl.php';
preg_match_all('|<a href="'.url2.'/muzic/(.*?)">(.*?)</a>|is',$store,$outs);
echo '<div class="l">'.arrow.'<a href="updates.php">Updates</a> <img src="new.png" /></div>';
foreach($outs[0] as $out){
$out = str_replace(''.url2.'/muzic/cat/',''.index.'?act=b&t=',$out);
$out = str_replace('punjabi_music.php','view_music.php?ciat=punjabi_music',$out);
$out = str_replace('hindi_music.php','view_music.php?ciat=hindi_music',$out);
$out = str_replace(''.url2.'/muzic/',null,$out);
echo '<div class="l">'.arrow.''.$out.'</div>';
} }
if($act=='b'){
include 'search.php';
echo '<div class="t">Collections</div>';
$i =0;
$url = ''.url2.'/muzic/cat/'.t.'';
include 'curl.php';
preg_match_all('|<title>(.*?)</title>|is',$store,$titles);
$title = ''.$titles[1][0].'';
echo '<title>'.$title.'</title>';

include 'top30.php';
preg_match_all('|<a href="'.url3.'/muzic/view/(.*?)">(.*?)</a>|is',$store,$outs);
foreach($outs[1] as $out){
$out = urlencode($out);
$lname = $outs[2][$i];
echo '<div class="l">'.arrow.'<a href="index.php?act=c&t='.$out.'">'.$lname.'</a></div>';
$i++;
}
if(empty($p)){
preg_match_all('|Page 1 of (.*?) <a|is',$store,$outs);
echo str_replace('<a',null,$outs[0][0]); }
if(preg_match('/ Next .../',$store)){
preg_match_all('|<a class="btn" href="/muzic/cat/(.*?)"> Next ...</a>|',$store,$nxts);
$nxts[1][0] = str_replace('/muzic/cat/',''.index.'?act=b&t=',$nxts[1][0]);
$nxts[1][0] = str_replace('.. Back ','Back',$nxts[1][0]);
echo '<a href="'.index.'?act=b&t='.$nxts[1][0].'">Next</a>'; }
include 'quik_way.php';
}
if($act=='c'){
echo '<div class="t">Download Page</div>';
$url = urldecode(''.url3.'/muzic/view/'.t.'');
include 'curl.php';
preg_match_all('|<img alt="(.*?)" src="(.*?)">|is',$store,$outs);
$outs[2][0] = str_replace('><br>',null,$outs[2][0]);

$outs[2][0] = str_replace('<span',null,$outs[2][0]);
echo '<center><img src="'.$outs[2][0].'" alt="'.$outs[1][0].'" width="'.width.'" height="'.height.'" /></center>';
preg_match_all('|<span class="style1">(.*?)</span>|is',$store,$outs);
$title = ''.$outs[1][0].'';
echo '<title>'.$title.'</title>';
preg_match_all('|<a href="/muzic/artist/(.*?)"><span class="mr">(.*?)</span></a>|is',$store,$arts);
$artist = implode(', ',$arts[0]);
$artist = str_replace('<span class="mr">',null,$artist);
$artist = str_replace('</span>',null,$artist);
$artist = str_replace('/muzic/artist/','artist.php?t=',$artist);
preg_match_all('|<span class="style1"> Releases Date :</span> (.*?)<br>|is',$store,$dateA);
$artist = str_replace('</span>',null,$artist);
$artist = str_replace('/muzic/artist/','artist.php?t=',$artist);
preg_match_all('|<span class="style1"> Releases Date :</span> (.*?)<br>|is',$store,$dateA);
$artist = str_replace('</span>',null,$artist);
$artist = str_replace('/muzic/artist/','artist.php?t=',$artist);
preg_match_all('|<span class="style1"> Releases Date :</span> (.*?)<br>|is',$store,$dateA);
$artist = str_replace('</span>',null,$artist);
$artist = str_replace('/muzic/artist/','artist.php?t=',$artist);
preg_match_all('|<span class="style1"> Releases Date :</span> (.*?)<br>|is',$store,$dateA);
$artist = str_replace('</span>',null,$artist);
$artist = str_replace('/muzic/artist/','artist.php?t=',$artist);
preg_match_all('|<span class="style1"> Releases Date :</span> (.*?)<br>|is',$store,$dateA);
$artist = str_replace('</span>',null,$artist);
$artist = str_replace('/muzic/artist/','artist.php?t=',$artist);
preg_match_all('|<span class="style1"> Releases Date :</span> (.*?)<br>|is',$store,$dateA);
echo '<div class="t">File Information</div>';
echo '<div class="l">Name: '.$title.'</div>';
$year= intval($dateA[1][0]);
if($year=='0'){
$year = 'Unknown'; }
echo '<div class="l">Year: '.$year.'</div>';
echo '<div class="l">Album Artists: '.$artist.'</div>';
preg_match_all('|<a href="(.*?)">(.*?)</a>|is',$store,$outs);
echo '<div class="t">Download</div>';
foreach($outs[0] as $out){
if(preg_match('/muzic\/download\//i',$out)){
$out = str_replace('/muzic/download/','download.php?act=a&t=',$out);
echo '<div class="l">'.darrow.''.$out.'</div>'; }
}}

include_once 'footer.php';
?>
