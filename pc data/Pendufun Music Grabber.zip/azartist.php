<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact: cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$ch = curl_init();
$az = $_GET['az'];
$n = $_GET['n'];
if(empty($az)){
$url = ''.url2.'/muzic/azartist.php?cat='.$_GET['cat'].''; }
else{
$url = ''.url2.'/muzic/artist.php?cat='.$_GET['cat'].'&az='.$az.'&p='.$_GET['p'].''; }
if(!empty($n)){
$url = ''.url2.'/muzic/album.php?cat='.$_GET['cat'].'&n='.$n.'';
}
include 'curl.php';
include 'search.php';
echo '<div class="t">A-Z Artists</div>';
$i =0;
preg_match_all('|<title>(.*?)</title>|is',$store,$titles);
$title = ''.$titles[1][0].'';
echo '<title>'.$title.'</title>';
if(empty($n)){
$b = 'album.php'; }
else{ $b = 'artist.php'; }
if(empty($_GET['az'])){
$b = 'artist.php'; }
if(!empty($_GET['cat']) && !empty($n)){
$b = '/muzic/view/'; }
preg_match_all('|<a href="'.$b.'(.*?)">(.*?)</a>|is',$store,$outs);
foreach($outs[1] as $out){
if(!empty($out)){

if($b!='/muzic/view/'){
$lname = $outs[2][$i];
echo '<div class="l"><a href="azartist.php'.$out.'">'.$lname.'</a></div>'; }

else{
$lname = $outs[2][$i];
echo '<div class="l"><a href="'.index.'?act=c&t='.$out.'">'.$lname.'</a></div>'; }
$i++; }
}
// To Get Next, Back pages
if(empty($p)){
preg_match_all('|Page 1 of (.*?) <a|is',$store,$outs);
echo str_replace('<a',null,$outs[0][0]); }
if(preg_match('/ Next .../',$store)){
preg_match_all('|<a href="artist.php(.*?)"> Next ...</a>|',$store,$nxts);
$nxts[1][0] = str_replace('artist.php','azartist.php',$nxts[1][0]);
$nxts[1][0] = str_replace('.. Back ','Back',$nxts[1][0]);
echo '<a href="azartist.php'.$nxts[1][0].'">Next</a>'; }
preg_match_all('|<a href="az.php(.*?)">(.*?)</a>|',$store,$outs);
$i =0;
foreach($outs[1] as $lnk){
$lname = $outs[2][$i];
echo '<div class="l"><a href="'.$lnk.'">'.$lname.'</a></div>';
$i++;}
preg_match_all('|<a href="/muzic/azalbums.php(.*?)">(.*?)</a>|is',$store,$bouts);
preg_match_all('|<a href="/muzic/azartist.php(.*?)">(.*?)</a>|is',$store,$outs);
$i=0;
foreach($outs[1] as $lnk){
$lname = $outs[2][$i];
echo $lnk;
echo $lname;
$i++;
echo $lnk;
echo $lname;
$i++;
}
include_once 'footer.php';?>
