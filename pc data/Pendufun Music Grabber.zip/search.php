<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

include_once 'header.php';
include 'define.php';
if(empty($_GET['sh'])){
echo '<div class="t">Search</div><div class="highlight"><form method="get" action="search.php">'; ?>
<div class=""><input type="text" name="ty" value="Search Here...." onfocus="if (this.value == 'Search Here....') {this.value = '';}" size="20"></div>
<?php echo'<div class=""><select size="1" name="sh">
<option selected>Song</option>
<option>Album</option>
<option>Artist</option>
</select></div><input type="submit" value="Search">
</form></div>'; }
else{
$ty = $_GET['ty'];
$sh = $_GET['sh'];
echo '<div class="t">Search Results</div>';
$url = ''.url2.'/muzic/search.php?ty='.$ty.'&sh='.$sh.'&p='.$_GET['p'].'';
$ch = curl_init();
include 'curl.php';
preg_match_all('|<title>(.*?)</title>|is',$store,$t);
echo $t[0][0];
if(preg_match('/Minimum/i',$store)){
echo 'Type atleast 3 Characters';
die();
}
else{
echo '<title>Search Results</title>';
if($sh=='Album'){
$i =0;
preg_match_all('|<a href="/muzic/view/(.*?)">(.*?)</a>|is',$store,$outs);
foreach($outs[1] as $out){
$out = urlencode($out);
$lname = $outs[2][$i];
echo '<div class="l">'.arrow.'<a href="index.php?act=c&t='.$out.'">'.$lname.'</a></div>';
$i++;
}}
if($sh=='Song'){
$i =0;
preg_match_all('|<a href="download/(.*?)">(.*?)</a><br><font color=green>Album : </font><a href="/muzic/view/(.*?)"><font color="#996600">(.*?)</font></a><br /><font color=green>Artist : (.*?)</font>|is',$store,$outs);
foreach($outs[1] as $download){
$dname = $outs[2][$i];
$album = $outs[3][$i];
$alblnk = $outs[4][$i];
$artist = $outs[5][$i];
echo '<div class="border">'.arrow.'<a style="color:#0099cc;" href="download.php?act=a&t='.$download.'">'.$dname.'</a><br>Album: <a style="color:#f00000;" href="'.index.'?act=c&t='.$album.'">'.$alblnk.'</a><br>Artist: '.$artist.'</div>';
$i++; }
}
if($sh=='Artist'){
$i =0;
preg_match_all('|<a href="album.php?(.*?)">(.*?)</a>|',$store,$out);
foreach($out[1] as $lnk){
$lnk = str_replace('?n=','artist.php?t=',$lnk);
$lnk = ''.$lnk.'.html';
$lname = $out[2][$i];
echo '<div class="l">'.arrow.'<a href="'.$lnk.'">'.$lname.'</a></div>';
$i++; }
}
if($sh=='Song' || $sh=='Artist'){
if(empty($p)){
preg_match_all('|Page 1 of (.*?) <a|is',$store,$outs);
echo str_replace('<a',null,$outs[0][0]); }
if(preg_match('/ Next .../',$store)){
preg_match_all('|<a class="btn" href="search.php(.*?)"> Next ...</a>|',$store,$nxts);
$nxts[1][0] = str_replace('search.php','search.php',$nxts[1][0]);
$nxts[1][0] = str_replace('.. Back ','Back',$nxts[1][0]);
echo '<a href="search.php'.$nxts[1][0].'">Next</a>'; }
}
}

include_once 'footer.php'; }
?>
