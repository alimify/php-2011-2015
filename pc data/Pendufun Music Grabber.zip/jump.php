<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

ob_start();
include 'define.php';
$go = $_GET['go'];
if($go=='Go'){
$p= $_GET['p'];
$cat= $_GET['cat'];
$q= $_GET['q'];

$p = $p-1;
$p = ''.$p.'0';
if($q=='hq' || $q=='lq'){
header('location:view_music.php?act='.$q.'&t='.$cat.'/'.$p.'.html');

}else{
header('location:'.index.'?act=b&t='.$cat.'/'.$p.'.html');
}}

ob_flush();
?>
