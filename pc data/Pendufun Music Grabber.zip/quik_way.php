<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

preg_match_all('|<form method="get" action="/muzic/jump.php">
Jump To : <input type="text" name="p" size="4" maxlength="3"> <input type="submit" name="go" value="Go">
<input type="hidden" name="cat" value="(.*?)"><input type="hidden" name="q" value="(.*?)"></form>|',$store,$jump);
$jump[0][0] = str_replace('/muzic/jump.php','jump.php',$jump[0][0]);
echo $jump[0][0];
preg_match_all('|<a href="/muzic/azalbums.php(.*?)">(.*?)</a>|is',$store,$bouts);
preg_match_all('|<a href="/muzic/azartist.php(.*?)">(.*?)</a>|is',$store,$outs);
echo '<div class="highlight">By A to Z Alphabet -<a href="azalbums.php'.$bouts[1][0].'">'.$bouts[2][0].'</a>/<a href="azartist.php'.$outs[1][0].'">'.$outs[2][0].'</a></div>';
?>
