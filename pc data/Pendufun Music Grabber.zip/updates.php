<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact: cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$ch = curl_init();
echo '<title>Updates</title>';
include 'search.php';
echo '<div class="t">Updates</div>';
$url = ''.url2.'/muzicpc/update.php';
include 'curl.php';
preg_match_all('|<a href="'.url1.'/muzic/cat/(.*?)"><strong>(.*?)</strong> </a> - <a href="/muzicpc/view/(.*?)">(.*?)</a> <span class="artist">(.*?)</span>|is',$store,$outs);
$i=0;
foreach($outs[1] as $lnk){
$n = $outs[2][$i];
$l2 = $outs[3][$i];
$ln2 = $outs[4][$i];
$n3 = $outs[5][$i];
$lnk = str_replace($n,''.index.'?act=b&t='.$n.'',$lnk);
echo '<div class="l"><a href="'.$lnk.'">'.$n.'</a> - <a style="color:#ff0000" href="'.index.'?act=c&t='.$l2.'">'.$ln2.'</a> <font color="339900">'.$n3.'</font> <font color="#ff6600">[</font><a style="color:#0066ff;" href="view_q.php?t='.$l2.'&q=lq">48</a>,<a style="color:#0066ff;" href="view_q.php?t='.$l2.'&q=hq">128 kbps</a><font color="#ff6600">]</font></div>';
$i++;
}
include 'footer.php';
?>
