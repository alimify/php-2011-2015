<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact: cxuideas@gmail.com
// Scripted on 19/05/2013

include 'header.php';
$az = $_GET['az'];
$ciat = $_GET['ciat'];
$ch = curl_init();
if(empty($az)){
echo '<title>A-Z Artists</title>';
echo '<div class="t">Singer Collection</div>';
$url = ''.url2.'/muzic/'.$ciat.'_atoz_artist.php';
include 'curl.php';
preg_match_all('|<a href="artist.php(.*?)">(.*?)</a>|is',$store,$outs);
$i =0;
foreach($outs[1] as $lnk){
$lname = $outs[2][$i];
echo '<div class="l"><a href="azartist.php'.$lnk.'">'.$lname.'</a></div>';
$i++;
}
}
else{
$url = ''.url2.'/muzic/artist.php?cat='.$_GET['cat'].'&az='.$_GET['az'].'&p='.$_GET['p'].'';
include 'curl.php';

echo '<title>'.$_GET['az'].'</title>';
preg_match_all('|<a href="album.php(.*?)">(.*?)</a>|is',$store,$outs);

foreach($outs[1] as $lnk){
$lname = $outs[2][$i];
echo '<div class="l"><a href="'.$lnk.'">'.$lname.'</a></div>';
$i++;}
preg_match_all('|Page 1 of (.*?) <a class="btn" href="/muzic/cat_lq/Punjabi/10.html"> Next ...</a>',$store,$outs);
}
preg_match_all('|<font color=black>By A to Z Alphabet -</font><a href="/muzic/azalbums.php(.*?)"><font color=red>Albums</font></a><font color=green>/</font><a href="/muzic/azartist.php(.*?)"><font color=red>Artist</font></a>|is',$store,$outs);
$i=0;
foreach($outs[1] as $lnk){
$lname = $outs[2][$i];
echo $lnk;
echo $lname;
}
include 'footer.php';
?>
