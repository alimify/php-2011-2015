<?php
// PenduFun Music Grabber
// Developed by CXUideas
// Scripted by Febin Baiju
// Contact cxuideas@gmail.com
// Scripted on 19/05/2013

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"></center><head>';

echo '<center><img src="logo.png" /></center>';
include 'cxu.css'; ?>
<head><style type="text/css"><!-- A:link {text-decoration:none} A:visited {color: #fffff; text-decoration: none;} --></style>
<?php include 'define.php'; ?>
