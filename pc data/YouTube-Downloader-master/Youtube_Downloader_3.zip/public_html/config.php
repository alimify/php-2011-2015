<?php
$head='<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html> <link rel="STYLESHEET" type="text/css" href="http://abswerbd.wapka.mobi/styles.css"/>
 <head><title>'.$title.' | WAPCITY.ML</title><meta name="keyword" content="free, download, video, youtube, movie,yaaya,arawap,sri lanka,3gpsearch" /><meta name="description" content="youtube videos direct download" /></head><body><div class="logo" align="center"><b>WAPCITY.ML</b></div><div class="menu"><form action="/search.php" method="get"><input type="text" name="q" class="search" size="13"/> <input type="submit" value="search" /></form></div>';
$foot='<div class="footer" align="center"><b>&copy;2014 WAPCITY.ML</b></div></body></html>
';
?>
