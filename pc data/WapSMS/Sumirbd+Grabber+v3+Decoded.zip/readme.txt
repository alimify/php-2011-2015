JUST FOLLOW BELOW :
edit config.php and enjoy own download portal. if u face any problem contact fb.com/raziulboss or bdboys.net