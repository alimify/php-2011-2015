<?php
/* Script by Raziul and bdboys.net team */
include 'config.php';
$file = file_get_contents('http://m.sumirbd.mobi/files/search/?'.$_SERVER['QUERY_STRING'].'');
$file=str_replace('http://m.sumirbd.mobi',''.$url.'',$file);
include 'function.php';
echo $file;
include 'footer.php';?>