<?php
/* Script by bdboys.net */
include 'config.php';
$id=$_GET['id'];
if(!$id){
echo '<br/><h2>Error: wrong path entered.</h2><br/>';
die();
}
$host ='http://m.sumirbd.mobi/files/download/id';
$link =''.$host.'/'.$id.'';
$h = get_headers($link);
$ti = $h[8];
$ti = str_replace('Location: ','',$ti);
$tiku = $ti;
$tiku = str_replace(' ','%20',$tiku);
// file name n replace
$sname = basename($tiku);
$sname = str_replace('sumirbd.mobi',''.$site.'',$sname);
$sname = str_replace('%20',' ',$sname);
// dir make
$dir = "bdboys";
$dir2 = "$dir/$id";
if(!is_dir($dir)){
mkdir($dir);
chmod($dir,0777);
}
if(!is_dir($dir2)){
mkdir($dir2);
chmod($dir2,0777);
}
// save n copy
$save = ''.$dir.'/'.$id.'/'.$sname.'';
$file_extension=pathinfo($save, PATHINFO_EXTENSION);
if(!file_exists($save)) {
if($file_extension=="mp3"){
if(copy($tiku,$save)){
if ($voice == 'ON') { file_put_contents(''.$save.'',    file_get_contents(''.$save.'').    file_get_contents('raziul.mp3')); }
@include 'tag.php'; }
} else {
copy($tiku,$save); }
header("Location: /$save");
} else {
header("Location: /$save");
}?>