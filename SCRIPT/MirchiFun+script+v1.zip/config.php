<?php
error_reporting(0);
$url = "http://mirchifun.9twap.com";
$home = "9xmdj.com";
$site = "9xmDJ.Com";
$copyright = 'www.9xmDJ.Com';
/* MP3 Tag Settings */
$albumart = "Art.jpg";
$mp3_album = "www.9xmDJ.Com";
$mp3_artist = "www.9xmDJ.Com";
$mp3_composer = "www.9xmDJ.Com";
$mp3_copyright = "www.9xmDJ.Com";
$mp3_comment = "Various Songs Available On www.9xmDJ.Com";
$mp3_genre = "www.9xmdj.com";
$mp3_year = "2014";
$mp3_original_artist = "www.9xmDJ.Com";
$mp3_encoded_by = "www.9xmDJ.Com";
?>
