* MirchiFun.Com Grabber Script (PHP) *
NB: Don't try to sell this script.!
------------------------------------
*HOW TO INSTALL*
1. Unzip/Extract Script On Your Server.
2. Go your hosting cpanel, and create a subdomain "d2" .
3. Now Edit config.php , header.php , footer.php , load.php
------------------------------------
*About Developer*
> NAME: Sohel Rana
> E-MAIL: xtwapmaster@gmail.com
> SITE: http://9twap.com
> PHONE: +8801917571588
> COUNTRY: Bangladesh
------------------------------------
* If you facing any problem about this Script, mail me at "xtwapmaster@gmail.com" .  ENJOY !
Thank You!
