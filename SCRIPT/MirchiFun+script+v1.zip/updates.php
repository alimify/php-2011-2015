<div class="updates">
<h2>Latest Updates</h2>
<div>No Updates Found!</div>
<div>No Updates Found!</div>
</div>
