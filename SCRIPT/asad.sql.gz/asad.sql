-- MySQL dump 10.11
--
-- Host: localhost    Database: bluetric_new
-- ------------------------------------------------------
-- Server version	5.0.95-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `mydnld`
--

DROP TABLE IF EXISTS `mydnld`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mydnld` (
  `id` int(100) NOT NULL auto_increment,
  `nm` varchar(255) NOT NULL default '',
  `dload` int(100) NOT NULL default '0',
  `lastdload` int(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mydnld`
--

LOCK TABLES `mydnld` WRITE;
/*!40000 ALTER TABLE `mydnld` DISABLE KEYS */;
INSERT INTO `mydnld` (`id`, `nm`, `dload`, `lastdload`) VALUES (1,'Wallpaper/logo.jpg',1,1328252141),(2,'Downloads/Wallpaper/car_bikes/041128132722_64.jpg',2,1328734595),(3,'Downloads/Games/nokia/240x320/FIA_3d_World_Rally_Championship(7xmbd.in).jar',2,1328301972),(4,'Downloads/Themes/sony_ericsson/176x220/Music_Wave(7xmbd.in).thm',4,1329854980),(5,'Downloads/Themes/sony_ericsson/176x220/Loneliness(7xmbd.in).thm',5,1330559198),(6,'Downloads/Themes/sony_ericsson/176x220/Blue_Steel(7xmbd.in).thm',4,1329854853),(7,'Downloads/Themes/sony_ericsson/128x160/Animated_Rain(7xmbd.in).thm',12,1331539450),(8,'Downloads/Themes/sony_ericsson/128x160/Animated_Heart(7xmbd.in).thm',15,1331601769),(9,'Downloads/Themes/sony_ericsson/128x160/Heart_Animated(7xmbd.in).thm',12,1330575392),(10,'Downloads/Themes/sony_ericsson/176x220/Black_W_Original(7xmbd.in).thm',6,1329856635),(11,'Downloads/Themes/sony_ericsson/176x220/Blue_Spiral_Animated(7xmbd.in).thm',4,1329859433),(12,'Downloads/Themes/sony_ericsson/128x160/Animated_Clock_Speed(7xmbd.in).thm',19,1330999085),(13,'Downloads/Themes/sony_ericsson/240x320/Animated_Lake(7xmbd.in).thm',4,1329855195),(14,'Downloads/Themes/sony_ericsson/240x320/Abstract_Grunge(7xmbd.in).thm',4,1329856516),(15,'Downloads/Themes/sony_ericsson/240x320/Abstract_Flower21(7xmbd.in).thm',4,1329856925),(16,'Downloads/Themes/sony_ericsson/240x320/Animated_Dog_Clock(7xmbd.in).thm',4,1329859084),(17,'Downloads/Themes/sony_ericsson/240x320/Animated_Blue_Lamour(7xmbd.in).thm',10,1331004104),(18,'Downloads/Themes/sony_ericsson/240x320/Animated_Black_Clock(7xmbd.in).thm',4,1329859318),(19,'Downloads/Themes/sony_ericsson/240x320/Blueish(7xmbd.in).thm',4,1330204692),(20,'Downloads/Themes/sony_ericsson/176x220/Red_Clock(7xmbd.in).thm',4,1330206336),(21,'Downloads/Themes/sony_ericsson/240x320/Animated_Light(7xmbd.in).thm',13,1331575084),(22,'Downloads/Themes/sony_ericsson/240x320/Swf_Vista_Clock(7xmbd.in).thm',4,1330209017),(23,'Downloads/Themes/sony_ericsson/176x220/Walkman_Animated(7xmbd.in).thm',4,1330210205),(24,'Downloads/Themes/sony_ericsson/240x320/Working_Vista_Swf(7xmbd.in).thm',4,1330211244),(25,'Downloads/Themes/sony_ericsson/240x320/Animated_Swf_Green_C(7xmbd.in).thm',8,1331651051),(26,'Downloads/Themes/sony_ericsson/176x220/Blue_Animated(7xmbd.in).thm',4,1329855303),(27,'Downloads/Wallpaper/games_wallpaper/Counter_Strike(7xmbd.in).jpg',1,1328371813),(28,'Downloads/Ringtones/mp3_tones/bollywood_tones/Jaane_Ye_Kya_Hua(7xmbd.in).mp3',1,1328375835),(29,'Downloads/Wallpaper/3D_wallpaper/3D_Picture_(7)_(7xmbd.in).jpg',1,1328377720),(30,'Downloads/Wallpaper/bangladeshi_model/tisha/nusrat-imroz-tisha-photo-10.jpg',1,1328476251),(31,'Downloads/Wallpaper/bangladeshi_model/tisha/Tisha-3.jpg',1,1328476426),(32,'Downloads/Games/nokia/240x320/Formula_Extreme(7xmbd.in).jar',2,1329461383),(33,'Downloads/Wallpaper/bangladeshi_model/tinni/Tinni_pic_5.jpg',1,1328476672),(34,'Downloads/Wallpaper/Nature_and_arts/Alone_Girl(7xmbd.in).jpg',1,1328476676),(35,'Downloads/Wallpaper/bangladeshi_model/tinni/Tinni_pic_4.jpg',1,1328476762),(36,'Downloads/Wallpaper/3D_wallpaper/3D_Picture_(18)_(7xmbd.in).jpg',1,1328476767),(37,'Downloads/Wallpaper/desi_girls/Desi_girls_101.jpg',2,1328738252),(38,'Downloads/Wallpaper/bangladeshi_model/tisha/nusrat-imroz-tisha-photo-11.jpg',1,1328476860),(39,'Downloads/Wallpaper/bangladeshi_model/tisha/nusrat-imroz-tisha-photo-12.jpg',1,1328476960),(40,'Downloads/Wallpaper/bangladeshi_model/tisha/nusrat-imroz-tisha-photo-4.jpg',1,1328476991),(41,'Downloads/Wallpaper/bangladeshi_model/tisha/nusrat-imroz-tisha-photo-3.jpg',1,1328477047),(42,'Downloads/Wallpaper/Nature_and_arts/Facebook(7xmbd.in).jpg',2,1328887946),(43,'Downloads/Wallpaper/desi_girls/Desi_girls_104.jpg',2,1328741838),(44,'Downloads/Wallpaper/bangladeshi_model/badhon/Badhon-4.jpg',1,1328477084),(45,'Downloads/Wallpaper/sun_set/Sun_Set_(17)(7xmbd.in).jpg',1,1328477100),(46,'Downloads/Wallpaper/sun_set/Sun_Set_(15)(7xmbd.in).jpg',1,1328477102),(47,'Downloads/Wallpaper/3D_wallpaper/3D_Picture_(11)_(7xmbd.in).jpg',1,1328477130),(48,'Downloads/Games/nokia/176x220/BMW_Sauber_F1_Challenge(7xmbd.in).jar',1,1328477152),(49,'Downloads/Wallpaper/games_wallpaper/Devil_May_Cry(7xmbd.in).jpg',1,1328477229),(50,'Downloads/Wallpaper/desi_girls/Desi_girls_100.jpg',2,1328740540),(51,'Downloads/Games/nokia/240x320/Urban_Attack(7xmbd.in).jar',2,1330024224),(52,'Downloads/Wallpaper/desi_girls/Desi_girls_10.jpg',2,1331679802),(53,'Downloads/Wallpaper/car_bikes/051123183841_78.jpg',1,1328736395),(54,'Downloads/Wallpaper/desi_girls/Desi_girls_102.jpg',1,1328737054),(55,'Downloads/Wallpaper/desi_girls/Desi_girls_103.jpg',1,1328739671),(56,'Downloads/Wallpaper/bangladeshi_model/tinni/Tinni-1.jpg',1,1329140572),(57,'Downloads/Wallpaper/bangladeshi_model/tisha/Tisha-1.jpg',1,1329261720),(58,'Downloads/Games/nokia/128x128/Albo_Return(7xmbd.in).jar',1,1329655830),(59,'Downloads/Wallpaper/car_bikes/051117202635_100.jpg',1,1329781235),(60,'Downloads/Wallpaper/car_bikes/1969_Camaro_Convertible.jpg',1,1329781815),(61,'Downloads/Games/nokia/240x320/Freestyle_Moto_X3(7xmbd.in).jar',1,1330023062),(62,'Downloads/Games/nokia/240x320/The_Crow(7xmbd.in).jar',1,1330023754),(63,'Downloads/Games/nokia/240x320/Tomb_Raider_Anniversary(7xmbd.in).jar',1,1330023945),(64,'Downloads/Ringtones/mp3_tones/bollywood_tones/Golmaal_(7xmbd.in).mp3',1,1330050275),(65,'Downloads/Ringtones/mp3_tones/bollywood_tones/Golmaal_(Remix)_(7xmbd.in).mp3',1,1330050547),(66,'Downloads/Wallpaper/3D_wallpaper/3D_Picture_(1)(7xmbd.in).jpg',1,1330064982),(67,'Downloads/Wallpaper/bangladeshi_model/tinni/Tinni_pic_1.jpg',1,1330185791),(68,'Downloads/Wallpaper/desi_girls/Desi_girls_11.jpg',1,1330271482),(69,'Downloads/Wallpaper/desi_girls/Desi_girls_105.jpg',1,1330271915),(70,'Downloads/Wallpaper/desi_girls/Desi_girls_106.jpg',1,1330272085),(71,'Downloads/Wallpaper/desi_girls/Desi_girls_108.jpg',1,1330272274),(72,'Downloads/Wallpaper/desi_girls/Desi_girls_110.jpg',1,1330272452),(73,'Downloads/Wallpaper/desi_girls/Desi_girls_109.jpg',1,1330272634),(74,'Downloads/Wallpaper/desi_girls/Desi_girls_107.jpg',1,1330274305),(75,'Downloads/Ringtones/mp3_tones/bollywood_tones/Aay__Re(7xmbd.in).mp3',1,1331348552);
/*!40000 ALTER TABLE `mydnld` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-13 22:23:36
