<?php

# Enter path to root WHMCS directory (relative or full)
$whmcspath = '../';

?>