<?php

// -------------------------- Page Settings - no need to edit by default --------------------------

$home_language_title = 'hometitle';
$home_page = 'home.php';
$home_tpl = 'home';
$home_forcessl = 'off';

// The home.php is no longer used (changed to index.php since V3.4) but the above code must remain to allow the redirect to occur

$company_page = 'company.php';
$company_tpl = 'company';
$company_forcessl = 'off';

$portal_page = 'portal.php';
$portal_tpl = 'portal';
$portal_forcessl = 'off';

$usage_page = 'acceptable-usage-policy.php';
$usage_tpl = 'acceptable-usage-policy';
$usage_forcessl = 'off';

$terms_page = 'terms-of-service.php';
$terms_tpl = 'terms-of-service';
$terms_forcessl = 'off';

$privacy_page = 'privacy-policy.php';
$privacy_tpl = 'privacy-policy';
$privacy_forcessl = 'off';

$custom1_page = 'web-hosting.php';
$custom1_tpl = 'web-hosting';
$custom1_forcessl = 'off';

$custom2_page = 'reseller-hosting.php';
$custom2_tpl = 'reseller-hosting';
$custom2_forcessl = 'off';

$custom3_page = 'vps-hosting.php';
$custom3_tpl = 'vps-hosting';
$custom3_forcessl = 'off';

$custom4_page = 'dedicated-servers.php';
$custom4_tpl = 'dedicated-servers';
$custom4_forcessl = 'off';

$custom5_page = 'cloud-hosting.php';
$custom5_tpl = 'cloud-hosting';
$custom5_forcessl = 'off';

$custom6_page = 'game-servers.php';
$custom6_tpl = 'game-servers';
$custom6_forcessl = 'off';

// New pages

$testimonials_page = 'testimonials.php';
$testimonials_tpl = 'testimonials';
$testimonials_forcessl = 'off';

$whychooseus_page = 'why-choose-us.php';
$whychooseus_tpl = 'why-choose-us';
$whychooseus_forcessl = 'off';

$affiliateprogram_page = 'affiliate-program.php';
$affiliateprogram_tpl = 'affiliate-program';
$affiliateprogram_forcessl = 'off';

// V1.1 pages

$custom7_page = 'virtual-private-network.php';
$custom7_tpl = 'virtual-private-network';
$custom7_forcessl = 'off';

$custom8_page = 'ssl-certificates.php';
$custom8_tpl = 'ssl-certificates';
$custom8_forcessl = 'off';

$custom9_page = 'hosting-addons.php';
$custom9_tpl = 'hosting-addons';
$custom9_forcessl = 'off';

$custom10_page = 'email-hosting.php';
$custom10_tpl = 'email-hosting';
$custom10_forcessl = 'off';

?>