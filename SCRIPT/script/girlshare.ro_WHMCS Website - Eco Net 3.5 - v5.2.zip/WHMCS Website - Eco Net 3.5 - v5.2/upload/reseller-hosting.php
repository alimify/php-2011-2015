 <?php
 
 /*
 
 This file contains the functions of the page - please refer the following guide on where/how to edit the HTML/text:
 
 http://www.zomex.com/lab/tutorials/whmcs1/understanding-the-template-structure.php
 
 Default page: Reseller Hosting
 
 */
 
 define("CLIENTAREA",true);
 include "configuration_template_v3-4.php";
 if ( $custom2_forcessl == 'on' ) { define("FORCESSL",true); }
 
 require("init.php");
 
 $z0mlang = getz0mlang();
 
 $ca = new WHMCS_ClientArea();
 
 $ca->setPageTitle($whmcs->get_lang('custom2title'));
 
 $ca->addToBreadCrumb('index.php',$whmcs->get_lang('globalsystemname'));
 $ca->addToBreadCrumb($custom2_page,$whmcs->get_lang('custom2title'));
 
 $ca->initPage();
 
 //$ca->requireLogin(); // Uncomment this line to require a login to access this page
 
 $ca->assign('variablename', $value);
 
 if ($ca->isLoggedIn()) {
 
   $result = mysql_query("SELECT firstname FROM tblclients WHERE id=".$ca->getUserID());
   $data = mysql_fetch_array($result);
   $clientname = $data[0];
 
   $ca->assign('clientname', $clientname);
 
 } else {
 
 }
 
 $ca->setTemplate($custom2_tpl);
 
 $ca->output();
 
 ?>