===========================================================================
Zomex - Eco Net V3.5 WHMCS Website
===========================================================================

    Release Version: 3.5
    Release Type: Stable Release
    Release Date: 6th December 2013

    PLEASE READ ALL OF THE ENCLOSED INSTRUCTIONS

===========================================================================
[ CONTENTS ]
===========================================================================

1. Server Requirements
2. New Installation Instructions & guides
3. Support
4. Remaining steps to make use of this template
5. WHMCS services we offer


===========================================================================
[ 1. SERVER REQUIREMENTS ]
===========================================================================

- PHP Version 5.x or later
- MySQL Version 4.1.x or later
- Curl Support (with SSL)
- GD Image Library
- Ioncube Loaders installed

All of our web hosting plans support WHMCS and this template . More details
can be found below:

http://www.zomex.com/hosting/web-hosting.php

If you're looking for a reseller hosting company we can highly recommend the
following companies (we have personally used both):

MDDHosting: http://www.zomex.com/link/mddhosting.php

HostGator: http://www.zomex.com/link/hostgator.php

===========================================================================
[ 2. NEW INSTALLATION INSTRUCTIONS & GUIDES ]
===========================================================================

For instructions on installing your Eco Net V3.5 WHMCS website please refer to:

http://www.zomex.com/lab/?p=354

We've compiled a detailed and growing list of guides & tutorials:

http://www.zomex.com/lab/?p=669

===========================================================================
[ 3. Support ]
===========================================================================

We have addressed the most popular questions/tutorials related to this
template and WHMCS in general below:

http://www.zomex.com/lab/category/tutorials/whmcs

If you can't find the answer to your question in our knowledge base feel
free to contact us using any method below and we will be happy to assist
you:

- Submit a support ticket:

https://www.zomex.com/clients/submitticket.php?step=2&deptid=1

- Use our contact form:

https://www.zomex.com/clients/contact.php

- Email us:

   - Email Jack at jack@zomex.com
   - Email support at support@zomex.com


===========================================================================
[ 4. Remaining steps to make use of this template ]
===========================================================================

In order to sell web hosting & domain registration services you must either
have:

- A reseller account (cPanel/WHM recommended)
- A VPS
- A dedicated server
- A Enom reseller account (optional - if you wish to resell domain names also)

and the following:

- A valid WHMCS licence

Once you have a way to resell web hosting here's what you'll need to do:

- Come up with a domain name for your business. If you don't already have one
feel free to register one with us below:

http://www.zomex.com/domains/

- Install WHMCS on a location of your choice. For use with this template we
recommend installing WHMCS on the root of your domain e.g mywebsite.com. If
you need any assistance with installing WHMCS we will be happy to do this for
free as you purchased the template. To take advantage of this please contact
support below:

http://www.zomex.com/clients/contact.php

- Install the files containing in the Upload folder to your WHMCS installation.
Once again we will be happy to install this for you for free. If this is of
interest to you please contact us today:

http://www.zomex.com/clients/contact.php

Alternatively we have created an installation guide here:

http://www.zomex.com/lab/?p=354

- Once your website is installed you will need to setup WHM/WHMCS & optionally
Enom. For more instructions on how to setup these please refer to WHMCS's
documentation here:

http://wiki.whmcs.com/

- Apply your plans/settings to your template using the guide below:

http://www.zomex.com/lab/?p=409

- Once these steps have been completed you will be all set!

===========================================================================
[ 5. WHMCS services we offer ]
===========================================================================

We also offer a wide range of WHMCS services from installation all the way
to configuration & automation setup. Visit the link below to view all of
our WHMCS services:

http://www.zomex.com/services/whmcs.php 