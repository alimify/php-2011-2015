<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju
* CXUideas | cxuideas@gmail.com

******************/

include_once 'config.php';
$cat = @$_GET['cat'];
$page = @$_GET['page'];
$sort = @$_GET['sort'];

$page = $page==0?1:$page;
$sort = $sort=='default'?$sort:'a2z';
if(empty($cat))

{
$url = 'http://wapking.cc/';

$title = ''.$sitename.' :: Unlimited Free Downloads Portal';

$index = true;
}
else
$url = 'http://wapking.cc/categorylist/'.$cat.'/'.$sort.'/'.$page.'.html';

$h = get_headers($url);
if(array_key_exists(7,$h) && preg_match('/location:/i',$h[7]))
{
$url = str_replace('Location: ',null,$h[7]);
}
include 'curl.php';
preg_match_all('|<a href="/(.*?)ist/(.*?)/(.*?)/1.html"><div>(.*?)</div></a>|',$content,$r);
preg_match_all('|<div id="cateogry">[^>]*<h2>(.*?)</h2>|',$content,$t);
if(empty($r[1][0]))
{
$title = 'Category Not Found';
$div_title = 'Not Found';

$err_msg = 'Category Not found';
}

else
{
$title = $index===true?$title:$t[1][0].' :: '.$sitename;
$div_title = $t[1][0];
}
include 'header.php';

if($index!=true)

{
preg_match_all('|<div class="dtype">(.*?)</div>|is',$content,$sorts);
echo str_replace('href="/','href="',$sorts[0][0]);
}
echo '<div class="catList">';
for($i=0;$i<count($r[1]);$i++)
{
if(($index===true) &&(in_array($i,array(11,12)))) break;
echo '<div class="catRow catRowHome"><a href="'.trim($r[1][$i]).'ist/'.$r[2][$i].'/'.$r[3][$i].'/1.html">'.preg_replace('|<img src="(.*?)" />|',null,$r[4][$i]).'</a></div>';
}include 'footer.php';
?>