<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju
* CXUideas | cxuideas@gmail.com

******************/

$sitename = 'MTunesBD'; // Sitename
$mp3_join = true; // set false to disable joining mp3 at last
$path_url = 'http://wapking.boxhost.me/'; // your site URL
?>