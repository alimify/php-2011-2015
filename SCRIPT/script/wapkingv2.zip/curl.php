<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

$useragent = 'Opera/9.80 (J2ME/MIDP; Opera Mini/4.4.29476/34.2220; U; en) Presto/2.8.119 Version/11.10';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt ($ch,CURLOPT_RETURNTRANSFER, 1);
@curl_setopt($ch, CURLOPT_FOLLOWLOCATION,TRUE);
curl_setopt ($ch,CURLOPT_MAXREDIRS,10);
curl_setopt ($ch,CURLOPT_USERAGENT,$useragent);
$content = curl_exec ($ch);
curl_close($ch);
?>
