<?php 
error_reporting (0);
include_once 'config.php'; include_once 'del.php'; ?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="title" content="<?=$sitename;?> :: :: Free Mobile Ringtones, Free Mobile Wallpapers, Free Mobile Themes, Free Mobile Downloads, Android Downlods, Free Android Applications, Thousands of mobile downlods, free sms, samsung, lg, htc, nokia, black berry" />
<meta name="robots" content="index, follow" />
<title><?=$title;?></title>

<base href="<?=$path_url;?>" />
<link href="css/waploft.css" type="text/css" rel="stylesheet"/>
<link rel="shortcut icon" href="images/icon.png" />
</head>
<body>
<center><img src="<?=$path_url;?>images/logo.png" /></center><?php
if($index==true)

{
echo '<div class="search tCenter"><form method="get" action="search.php">Search : <input type="text" name="find" id="find" value="" size="15" />
<input type="submit" name="commit" value="Search" id="file" /></form></div>';
include 'updates.php';
echo '<div class="ad1"><b>&nbsp;Top 21 Downloads:</b><br/><a href="'.$path_url.'top/today.html">Today</a> | <a href="'.$path_url.'top/yesterday.html">Yesterday</a> | <a href="'.$path_url.'top/week.html">Week</a> | <a href="'.$path_url.'top/month.html">Month</a> | <a href="'.$path_url.'top/all.html">All Time</a></div>';
}
if(!empty($div_title))
{
?>
<h2><?=$div_title;?></h2>

<?php
}
elseif(!empty($sub))
{
echo $sub;
}
if(isset($err_msg))
{
echo '<div class="">'.$err_msg.'</div>';
}
preg_match_all('|<div class="description">(.*?)</div>|is',$content,$desc);

if(!empty($desc[0][0]))
echo str_ireplace(array('wapking.cc','wapking','waploft.com','waploft'),null,preg_replace('|<a href="(.*?)">(.*?)</a>|',null,$desc[0][0]));
include 'header.add';
?>