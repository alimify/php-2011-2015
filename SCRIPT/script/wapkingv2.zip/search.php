<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

$k = $_GET['find'];

include 'config.php';
header('location:'.$path_url.'files/search/find/'.urlencode(base64_encode($k)).'');
?>