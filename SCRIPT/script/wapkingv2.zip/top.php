<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

include 'config.php';
$url = 'http://wapking.cc/top/'.$_GET['d'].'.html';
include 'curl.php';
$title = 'Popular downloads '.$_GET['d'].'';

$div_title = 'Popular downloads';
include 'header.php';
preg_match_all('|<td colspan="2"><a class="fileName" href="/fileDownload/(.*?)">(.*?)</a><br />(.*?)<br style="clear:both;"></td>|',$content,$m);

echo '<table cellspacing="0"><tbody>';
for($i=0;$i<count($m[0]);$i++)

{

$c = $i%2==0?'even':'odd';
echo '<tr class="'.$c.'"><td><a class="fileName" href="fileDownload/'.$m[1][$i].'">'.$m[2][$i].'</a><br />'.$m[3][$i].'<br style="clear:both;"></td></tr>';
}
echo '</tbody></table>';
include 'footer.php';
?>