<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju

* CXUideas | cxuideas@gmail.com

******************/

error_reporting(0);
ob_start();

include 'w.php';
$id = $_GET['id'];

$size = $_GET['size'];
$u = 'http://waploft.com/files/download/id/'.$id.'';
if(!empty($size))
$u = 'http://waploft.com/files/download/id/'.$id.'/size/'.$size.'';
include 'config.php';
$orig_url = get_headers($u);

$orig_url = trim(str_replace('Location: ',null,$orig_url[7]));
$ext = strtolower(@end(@explode('.',$orig_url)));
$base = basename($orig_url);

$paths = str_replace('/'.$base.'',null,preg_replace('@http://(.*?).waploft.com/@',null,$orig_url));
$filename = str_ireplace(array('wapking.cc','waploft.com'),$sitename,$base);

if(!file_exists($paths))
mkdir($paths,0777,true);
$r_file = $paths.'/'.$filename;
if(!file_exists($r_file))

{
if(copy($orig_url,$r_file))
{
if(strtolower(@end(@explode('.',$r_file)))=='mp3')
{
$sname = $r_file;
include 'id.php';
}
if(@in_array(strtolower(@end(@explode('.',$r_file))),array('jpg','jpeg','png','gif')))
{
watermark($r_file);
}
header('location:'.$path_url.''.$r_file.'');
}
}
else 
header('location:'.$path_url.''.$r_file.'');

ob_flush();
?>