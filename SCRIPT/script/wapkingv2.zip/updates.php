<?php
/******************

* Developed by CXUideas

* Project: Wapking Grabber

* Developed on 28/05/2014

* Coded by Febin Baiju
* CXUideas | cxuideas@gmail.com

******************/

include_once 'config.php';
$url = 'http://wapking.cc';
include 'curl.php';
preg_match_all('|<!-- SKYiTech.com :: Display Random files --><div class="updates">(.*?)<img alt="wapking.cc"|is',$content,$m);
echo str_ireplace(array('http://wapking.cc','href="/','</h2>'),array($path_url,'href="'.$path_url,'</h2><div class="updates">'),$m[1][0]).'</div></div></div>';
?>