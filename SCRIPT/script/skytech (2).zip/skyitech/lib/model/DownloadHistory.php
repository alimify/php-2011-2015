<?php

/**
 * Subclass for representing a row from the 'download_history' table.
 *
 * 
 *
 * @package lib.model
 */ 
class DownloadHistory extends BaseDownloadHistory
{
}
