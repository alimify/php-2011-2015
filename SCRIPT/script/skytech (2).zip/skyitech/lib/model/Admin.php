<?php

/**
 * Subclass for representing a row from the 'admin' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Admin extends BaseAdmin
{
}
