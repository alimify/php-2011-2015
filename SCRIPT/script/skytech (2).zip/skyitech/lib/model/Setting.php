<?php

/**
 * Subclass for representing a row from the 'setting' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Setting extends BaseSetting
{
}
