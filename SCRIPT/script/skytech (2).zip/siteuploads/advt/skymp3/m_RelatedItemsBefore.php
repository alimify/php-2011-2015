<center>
<div id="adzmedia"></div>
<script type="text/javascript">
(function() {
 var k = encodeURIComponent(document.referrer);
 var l = document.getElementById('adzmedia');
 var m = 'adzmedia'+(Math.random() * (1000 - 0 + 1) + 0);
 l.id=m;
 var d=document,
 h=d.getElementsByTagName('head')[0],
 s=d.createElement('script');
 s.type='text/javascript';
 s.async=true;
 s.src='http://rtb.adzmedia.com/api.js?adzone=5444&div='+m+'&ref='+k;
 h.appendChild(s);
}());
</script>
</center>