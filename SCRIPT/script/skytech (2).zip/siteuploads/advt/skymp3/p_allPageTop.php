<?php include("p_RelatedItemsBefore.php"); ?>
<div id="mainDiv">
	<script type="text/javascript">
<!--
function cIE4(){if (event.button==2){return false;}}
function cNS4(e){if (document.layers||document.getElementById&&!document.all){if (e.which==2||e.which==3){return false;}}}
if (document.layers){document.captureEvents(Event.MOUSEDOWN);document.onmousedown=cNS4;}else if (document.all&&!document.getElementById){document.onmousedown=cIE4;}
document.oncontextmenu=new Function("return false");
// -->
</script>