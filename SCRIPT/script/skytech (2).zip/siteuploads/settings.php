<?php
define('SETTING_MOB_DATA_DOMAIN', 'http://s1.skymp3.in');
define('SETTING_FILES_PER_PAGE', '8');
define('SETTING_ADVT_AFTER_EACH_FILES', '1');
define('SETTING_THUMB_DOMAIN', '/siteuploads/thumb');
define('SETTING_CATEGORY_PER_PAGE', '12');
define('SETTING_UPDATES_PER_PAGE', '10');
define('SETTING_TITLE', ' :: Free Bengali Mp3 Songs, Bollywood Movie Songs, Instrumental, Punjabi Hits, Bhojpuri Songs, DJ Remix Mp3 Songs Free Collection, SattaMatka, SattaKing, MatkaKing MobWay.In, MobBoss.In, WapLoft.cc, WapKing.in, WebMusic.In, Video9.In, MyMp3Fun.Com, DjMaza.Info');
define('SETTING_PC_DATA_DOMAIN', 'http://s2.skymp3.in');
define('SETTING_SEARCH_EXTENSIONS', 'MP3,APK,MP4,3GP,SWF,JPG,EXE,IPA');
?>