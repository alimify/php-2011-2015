
##################### Installation ###########################

Unzip this file to Your public_html folder 
& Edit Files below.

##########################################

What to edit ?

admin_settings.php
config.php
core.php
setup.php

##########################################

Change index.php

to enable PC Version.

##########################################

Powerful Search Engine ADDED

Secure Admin Panel ADDED With multiple Functions.

##########################################

Admin Panel : www.yoursite.com/login.php

##########################################

Admin Panel Contains :



############ Normal Functions ##############

File Manager
Mass Renamer v2 Files
URL Upload v2
Folder Copy v2

############ Advanced Functions ############

Tag Images v1
Watermark Images v2
Tag Mp3 v1.1
MP3 Tag+Upload v2
Manual Mp3 Tag v2.1
 
############ End ###########################

Logout


############################################

Note : Automatic tag change & MP3 Tag+Upload v2 will not work with this Free version (2.0).
       very Simple File Manager Added with this free version.
       
############################################

For more details Contact to The Admin :

Admin : Shopnil Shaon
www.facebook.com/shaon1993 