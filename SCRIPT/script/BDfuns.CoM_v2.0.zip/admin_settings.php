<?php $password='1234'; /*Admin Panel (yoursite/admpanel) password*/ ?>
