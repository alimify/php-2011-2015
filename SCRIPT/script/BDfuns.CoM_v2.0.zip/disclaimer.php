<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="styles.css" rel="stylesheet" class="c1" type="text/css">
<link rel="stylesheet" href="styles.css" type="text/css">
<title>Disclaimer </title>
</head>
<body><center><div style="text-align: left;margin-top:-20px;">
<br/>
<table width="100%" border="0" style="margin-bottom: -10px;"><tr><td width="300px">
<img src="img/logo.gif" border="0" style="margin-top:5px;" /></a></td><td width="200px"><a href="indexw.php"><button type=submit style="width:100px;height:50px"><strong>Mobile Version</strong></button></a></td>
<td align="right"><div style="font-family: Trebuchet MS, sans-serif;font-size: 16px;" align="right"><center>
Boost Up Your Mobile With Millions of Games, Themes, Ringtones, Music, Video Clips, Applications,flash file And Many More Under One Roof !!</center></div></td></tr></table></div><br>

<div id="menus"><div id="mainmenu"><ul><li class="first"><a href="indexpc.php">Home</a></li><li><a href="http://free4download.in/p_Music.html">Music</a></li><li><a href="http://free4download.in/p_Video.html">Video</a></li><li><a href="http://free4download.in/p_Theme.html">Themes</a></li><li><a href="http://free4download.in/p_PC-zone.html">PC zone</a></li><li><a href="http://free4download.in/p_Games.html">Games</a></li><li><a href="http://free4download.in/p_Software.html">Softwares</a></li><li><a href="http://free4download.in/p_Android.html">Android</a></li></ul></div></div><table width="100%" cellspacing="3"><tr>
<td style="width: 250px;max-width:250px;">
<div class="hd">Special Downloads</div>
<div class="cbox" style="padding: 5px;">
<div class="lnr" style="margin-bottom: 5px;color:black;">
<img src="img/movie.gif"/>&nbsp;<b>Full Hq 3Gp Mobile Movies : <a style="font-size: 15px;text-decoration: none;" href="http://movieswap.info/">3GP</a> |</b>
</div><a href="" style="font-size: 14px;text-decoration: none;">
<div class="lnr" style="margin-bottom: 5px;">
<img src="img/music.gif">&nbsp;<b>Full MP3 Songs<br />
<small>Largest Collection of Music !</small></b>
</div></a>
<div class="lnr" style="margin-bottom: 5px;color:black;">
<img src="img/mpg.gif">&nbsp;<b>Bollywood Videos : <a style="font-size: 15px;text-decoration: none;" href="">3GP</a></b>
</div><div class="lnr" style="margin-bottom: 5px;">
<img src="img/contact.gif">&nbsp;<b>Contact Us</b><b>
<a class="bk" style="color:#2A64B5;" href="contactus.php">Here</a></b>
</div></a></div></td><td>
<div class="hd"><center><b>Disclaimer</b></center></div><div class="cbox"><b>
All the Downloads available here are and will be for Representational Purpose only, Which are been Collected from a wide resource through out Internet.<br/>» You are kindly requested to delete those stuffs within 24hr's and buy the Original stuff from there Respective Owners.<br/>» If you think by publishing a particular Downloads/Service on this site your copyright has been violated, please send a mail at: free4download.in@gmail.com so we can remove the particular content from our site.<br/>» Any links provided or advertisements displayed on FREE4DOWNLOAD.IN site are for informational purposes only and we are not responsible for any damages or consequences.<br/>» If you do not agree with our terms, please do not continue viewing and leave the site immediately.<br/>
Happy surfing.</b>

</div></td></tr></table>
<div class="footer"><div class="defln">

Copyright &copy; Free4download.In 2011-12. All Rights Reserved.

<span style="float: left;">

Developed by :  <a href="http://indianmob.in" target="_blank">IndianMob.In</a>

</span><br>

</div><div class="defln">

<span style="float: left;">

Powered by: <a href="http://movieswap.info" target="_blank">Movieswap.Info</a>

</span>

<a href="disclaimer.php">Disclaimer</a> | <a href="contactus.php">Contact Us</a><br></div>
</div></center></body></html>