<!-- begin Ad World Media for channel:  , publisher: 27510 http://www.desirewap.info , Ad Dimension: Skyscraper - 120 x 600 -->
<script language="javascript">
document.write('<iframe src="http://newt1.adultadworld.com/jsc/z5/ff2.html?n=607;c=11452;s=27511;d=8;w=120;h=600;p=27511" frameborder=0 marginheight=0 marginwidth=0 scrolling="no" allowTransparency="true" width=120 height=600></iframe>');
</script>
<!-- end Ad World Media for channel:  , publisher: 27510 http://www.desirewap.info , Ad Dimension: Skyscraper - 120 x 600 -->