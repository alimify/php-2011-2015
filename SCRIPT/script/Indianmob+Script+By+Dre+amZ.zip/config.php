<?php

//Enable compression? (1 or 0)

$zip = 1;


// PCLZIP

$pclzip = 'pclzip.lib.php';

// ID

$mp3 = 'id.php'; // ibid should be pear.php





// Top

$top = '<?xml version="1.0" encoding="UTF-8" ?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>

';

// Bottom

$foot = '</body></html>';







?>