<div class="dl2"><strong>Service menu</strong></div>
<div class="even">link 1</div>
<div class="odd">link 2</div>
<div class="even">link 3</div>
<div class="odd">link4</div>