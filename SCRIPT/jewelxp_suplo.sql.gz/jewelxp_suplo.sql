-- MySQL dump 10.13  Distrib 5.5.37, for Linux (x86_64)
--
-- Host: localhost    Database: jewelxp_suplo
-- ------------------------------------------------------
-- Server version	5.5.37-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `filepostfix` varchar(50) NOT NULL,
  `title` text NOT NULL,
  `thumbw` int(3) NOT NULL,
  `thumbh` int(3) NOT NULL,
  `set` varchar(255) NOT NULL,
  `dthumbw` int(3) NOT NULL,
  `dthumbh` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `username`, `password`, `email`, `sitename`, `filepostfix`, `title`, `thumbw`, `thumbh`, `set`, `dthumbw`, `dthumbh`) VALUES (1,'kingbd','bdking','jewelworld9@gmail.com','KingBD.Net','[KingBD.Net]','Welcome To KingBD.Net',50,60,'aHR0cDovL2Z1bGwybW9iLnRrLw==',50,60);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_setting`
--

DROP TABLE IF EXISTS `admin_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_setting` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `value` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `adminsetting_id` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_setting`
--

LOCK TABLES `admin_setting` WRITE;
/*!40000 ALTER TABLE `admin_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` double NOT NULL,
  `name` varchar(256) NOT NULL,
  `path` text NOT NULL,
  `pathc` text NOT NULL,
  `totalitem` double NOT NULL,
  `folder` text NOT NULL,
  `newitemtag` tinyint(1) NOT NULL,
  `updateitemtag` tinyint(1) NOT NULL,
  `subcate` tinyint(1) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `clink` text NOT NULL,
  `des` text NOT NULL,
  `thumb` text NOT NULL,
  `kram` double NOT NULL,
  `sub` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_index` (`id`),
  KEY `date_index` (`date`),
  KEY `parentid_index` (`parentid`),
  KEY `kramindex` (`kram`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`, `parentid`, `name`, `path`, `pathc`, `totalitem`, `folder`, `newitemtag`, `updateitemtag`, `subcate`, `date`, `clink`, `des`, `thumb`, `kram`, `sub`) VALUES (1,0,'Games','&nbsp;&raquo;&nbsp;<a href=\"?pid=1\">Games</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/1/Games.html\">Games</a>',2,'upload_file/1/',0,0,0,'2014-05-29 12:37:53','Games','','',1,'');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `dname` text NOT NULL,
  `cid` double NOT NULL,
  `ext` varchar(5) NOT NULL,
  `thumbext` varchar(5) NOT NULL,
  `size` varchar(10) NOT NULL,
  `desc` text NOT NULL,
  `download` double NOT NULL,
  `view` double NOT NULL,
  `newtag` tinyint(1) NOT NULL,
  `imagetype` tinyint(1) NOT NULL,
  `kram` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_index` (`id`),
  KEY `download_index` (`download`),
  KEY `kramindex` (`kram`),
  KEY `cidindex` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` (`id`, `name`, `dname`, `cid`, `ext`, `thumbext`, `size`, `desc`, `download`, `view`, `newtag`, `imagetype`, `kram`) VALUES (1,'lolwa','KQIIact[KingBD.Net]',1,'jpg','','51599','',0,0,0,0,1),(2,'valovasha express title song.3gp','ccff2[KingBD.Net]',1,'3gp','','7469755','',10,5,1,0,2);
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_book`
--

DROP TABLE IF EXISTS `guest_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest_book` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(17) COLLATE utf8_unicode_ci NOT NULL,
  `flag` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `uagent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uprofile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_book`
--

LOCK TABLES `guest_book` WRITE;
/*!40000 ALTER TABLE `guest_book` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `update`
--

DROP TABLE IF EXISTS `update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `update` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `link` text NOT NULL,
  `home` tinyint(1) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `update`
--

LOCK TABLES `update` WRITE;
/*!40000 ALTER TABLE `update` DISABLE KEYS */;
/*!40000 ALTER TABLE `update` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-09-29  0:00:20
