<?php include "db.php"; ?>
<?php include "functions.php";

?>

<?php
$id=formpost("id");
$sql="SELECT MAX(a_id) AS Maxa_id FROM forum_answer WHERE question_id='$id'";
$result=mysql_query($sql);
$rows=mysql_fetch_array($result);
if($rows) { $Max_id = $rows['Maxa_id']+1; } else { $Max_id = 1; }
$a_name=formpost("a_name");
$a_email=dump_udata("email");
$a_answer=formpost("a_answer");
$datetime=date("j-m-y H:i:s");
$sql2="INSERT INTO forum_answer(question_id, a_id, a_name, a_email, a_answer, a_datetime) VALUES('$id', '$Max_id', '$a_name', '$a_email', '$a_answer', '$datetime')";
$result2=mysql_query($sql2);
if($result2) { echo "Message Posted! If you are not Redireted to forum click here <a href='view_topic.php?id=$id'>Forum</a>";
header('Location:/view/'.$id.'');
$sql3="UPDATE forum_question SET reply='$Max_id' WHERE id='$id'";
$result3=mysql_query($sql3);
} else {  echo "ERROR"; } mysql_close(); ?>
<?php include "foot.php"; ?>