<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Delete site");

if($userlog==1){

echo '<div class="title">Delete site</div>';
$site=formget("id");

$uid=dump_udata("id");

$chsite=mysql_query("SELECT * FROM sites WHERE userid='$uid' AND id='$site'");

if(mysql_num_rows($chsite)>0){
  
  if(isset($_POST['captcha'])){
     $captcha=formpost("captcha");

   if($_SESSION['captcha']!=$captcha){
      echo '<div class="error">Captcha code was wrong!</div>';
    }
   else {
      $delsite=mysql_query("DELETE FROM sites WHERE id='$site'");
      if($delsite){
        echo '<div class="success">Site deleted successfully! <a href="/sites">Continue</a></div>';
      }
      else {
        echo 'unk';
      }
    }
  }
  echo '<div class="form"><form method="post">Do you really want to delete this site? <br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in the image.<br/><input type="text" name="captcha"/><br/><table><tr><td><input type="submit" value="Yes"/></form></td><td><form action="/sites" method="post"><input type="submit" value="No"/></form></td></tr></table></div>';

}
else {
  echo 'As I know you dont own this.';
  }
  echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/sites">My Sites</a></div>';
  
 include 'foot.php';

}
else {
 header('Location:/');
  }

?>
  

     