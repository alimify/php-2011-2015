<?php include "db.php"; ?>
<?php include "functions.php"; ?>
<?php
$user=formpost("name");
$detail=formpost("detail");
$name=formpost("name");
$email=formpost("email");

if(strlen($detail)<1) {
echo "No  Msg";
} else
{
$datetime=date("d/m/y h:i:s"); //create date time

$sql="INSERT INTO forum_question(topic, detail, name, email, datetime)VALUES('None', '$detail', '$user', '$email', '$datetime')";
$result=mysql_query($sql);
if($result){
header('Location:/wallarea');
}
else {
echo "ERROR";
}
mysql_close();
}
?>