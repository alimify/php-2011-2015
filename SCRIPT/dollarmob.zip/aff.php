<?php 
include "db.php";
include "functions.php";

headtag("$SiteName - Affiliation Panel");
if($userlog==1) {
$user=dump_udata("firstname");
$hammad = mysql_query("SELECT * FROM userdata WHERE firstname='$user'");
$khan = mysql_fetch_array($hammad);
$bal = $khan['pubalance'];
$pnt = $khan['point'];
$uid = $khan['id'];
$time = date("F j Y"); 


echo ' <div class="title">Refferel System</div> <div class="ad">=> <b>Share below link with your friends And Earn <font color=red>0.023$ (2 Taka)</font> Per Affiliate. If They Finish Their balance <font color=green>10 TAKA(0.13$)</font></b> When Refferal user Reach His Balance 0.13$ (10 BDT)<br/>
 - Dont Register More Than 1 id (You Donot Get Money And You Blocked)<br/>
- We Will Automaticaly Add Referal Balance When Ref User Reach 0.13$ (10 TAKA)<br/>
 - ALL Referrers Show Here after Validation By DollarMob Admin
</div>';

echo '<div class="title">Your Affiliate Summary</div>';

echo '<div class="ad"><p><input type="text" name="aff" size="30" value="http://dollarmob.com/aff/'.$user.'"/></p></div>';

 
$result = mysql_query('SELECT * FROM ref WHERE refid ="'.$user.'"');
$hmm = mysql_num_rows($result);
$val = $result['validated'];

echo '<div class="ad"><p>Number of Affiliates:<b id="num">'.$hmm.'</b></p>';

while ($row = mysql_fetch_array($result, MYSQL_ASSOC))

 {
if($hmm<='0')
{
echo '<div class="error">You have not refered anyone</div>';
}
   else {
if($row['validated']==0)
{
$st = 'Pending';
}
else {
$st = 'Approved';
}
   echo '<p><em>User : <font color="green"><b>'.$row['refuser'].'</b></font> <b id="num">['.$st.']</b></em></p></div>';
  } 
  }

echo '</div>';
echo '<div class="ad"><a href="/">Go to Dashboard</a></div>';
}
else { header('Location:/');
}
include 'foot.php';

?>
