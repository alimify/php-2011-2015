<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Logout");

if($userlog==1){

session_destroy();

header('Location:/user/login');

include 'foot.php';
}
else {
header('Location:/');
}
?>
