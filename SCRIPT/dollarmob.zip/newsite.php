<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Add new site");

if($userlog==1){

 $uid=dump_udata("id");

 echo '<div class="title">Add new site</div>';

 if(isset($_POST["name"]) AND isset($_POST["url"]) AND isset($_POST["desc"]) AND isset($_POST["captcha"])){

    $name=formpost("name");
    $url=formpost("url");
    $url=strtolower($url);
    $url=str_replace('http://',null,$url);
    $desc=formpost("desc");
    $captcha=formpost("captcha");


    $errors=array();

    if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$url)){
       $errors[]='Site url is not valid!';
     }

    if(strlen($name)<1){
      $errors[]='Site name cannot be empty!';
     }

    if($_SESSION["captcha"]!=$captcha){
      $errors[]='Captcha code was wrong!';
     }

    if(empty($errors)){
       $url='http://'.$url.'';
       $add=mysql_query("INSERT INTO sites (userid,name,url,descr,status) VALUES ('$uid','$name','$url','$desc','<font color=\'green\'>Active</font>')");
       if($add){
        echo '<div class="success">Site successfully added! <a href="/sites">Continue..</a></div>';
       }
       else {
         echo '<div class="error">Unknown error creationg site!</div>';
       }
    }
    else {
     dump_error($errors);
    }
   }
  echo '<div class="form"><form method="post">Site name:<br/><input type="text" name="name"/><br/>Site url:<br/><input type="text" name="url" value="http://"/><br/>Site description:<br/><textarea name="desc"></textarea><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Add site"/></form></div>';
 
 echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/sites">My Sites</a></div>';
  
 include 'foot.php';

}

else {

header('Location:/');
}

?>
    