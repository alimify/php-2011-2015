<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag();
echo '<div class="title">Why Us ? </div>';



echo '<div class="ad"><img src="http://dollarmob.com/tick.png" alt=""/> 24/7 Offline / Online Dedicated  Support !</div>';

echo '<div class="ad"><img src="http://dollarmob.com/tick.png" alt=""/> Withdrawals Are Processed Daily !</div>';

echo '<div class="ad"><img src="http://dollarmob.com/tick.png" alt=""/> Awasome Cost Per Click Rate Ever !</div>';

echo '<div class="ad"><img src="http://dollarmob.com/tick.png" alt=""/> Payments Via Recharge,bKash,Skrill & PayPal !</div>';

echo '<div class="ad"><img src="http://dollarmob.com/tick.png" alt=""/> Real Time Statistics & Live Dashboard !</div>';

if($userlog==1){
echo '<div class="title">Welcome, <b>'.ucfirst(dump_udata("firstname")).'</b></div>';

echo '<div class="ad"><table><tr><td><img src="welcome.png" alt="-" width="20" height="25"/></td><td><b><a href="user/dashboard">User Panel</a></b><br/><small>P.Bal: '.dump_udata("pubalance").'$ | A.Bal: '.dump_udata("adbalance").'$</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="frm.png" alt="-" width="20" height="25"/></td><td><b><a href="wallarea">Public Wall Area</a></b><br/><small>Make A Public Post If You Need User Help</small></td></tr></table></div>';


echo '<div class="ad"><table><tr><td><img src="hp.png" alt="-" width="20" height="25"/></td><td><b><a href="support-ticket">Support Ticket</a></b><br/><small>Create A Ticket If You Need Staff Help</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="proof.png" alt="-"/></td><td><b><a href="payments-proof">Payments</a></b><br/><small>Payments Made by DollarMob</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="exit.png" alt="-" width="20" height="25"/></td><td><b><a href="user/logout">Logout</a></b><br/><small>Logout From DollarMob</small></td></tr></table></div>';
}
else {

echo '<div class="title">Main Menu</div>';

echo '<div class="ad"><table><tr><td><img src="login.png" alt="-" width="20" height="25"/></td><td><b><a href="user/login">User Login</a></b><br/><small>Existing User Login</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="register.png" alt="-" width="20" height="25"/></td><td><b><a href="user/registration">Registration</a></b><br/><small>New user registration</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="pin.png" alt="-" width="20" height="25"/></td><td><b><a href="user/forgot">Forgot Password</a></b><br/><small>Forgot Your Password Get It Back Now</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="proof.png" alt="-" width="20" height="25"/></td><td><b><a href="payments-proof">Payments</a></b><br/><small>Payments Made by DollarMob</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="faq.png" alt="-" width="20" height="25"/></td><td><b><a href="/f.a.q">F.A.Q</a></b><br/><small>Frequently asked questions</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="terms.png" alt="-" width="20" height="25"/></td><td><b><a href="user/terms">Terms</a></b><br/><small>Terms of service</small></td></tr></table></div>';

echo '<div class="ad"><table><tr><td><img src="ccontact.png" alt="-" width="20" height="25"/></td><td><b><a href="contact">Contact</a></b><br/><small>Contact DollarMob team</small></td></tr></table></div>';

}
$imp=mysql_query("SELECT * FROM imp");
$imps=0;

while($show=mysql_fetch_array($imp)){
$imps=($imps+$show['imp']);
}

$clciks=mysql_num_rows(mysql_query("SELECT * FROM clicks"));
$users=mysql_num_rows(mysql_query("SELECT * FROM userdata"));
echo '<div class="title">Features</div>';
echo '<div class="form"><table><tr><td align="center"><a href="/show-publishers"><img src="/publish.png" alt="Publisher"/></a></td><td><a href="/show-publishers"><b>Publisher</b></a><br/>Get paid from your mobile sites traffic. Start monetize your mobile traffic with easy integration in few minutes.</td></tr></table></div>';
echo '<div class="form"><table><tr><td align="center"><a href="/show-advertisers"><img src="/advertis.png" alt="Advertiser"/></a></td><td><a href="/show-advertisers"><b>Advertisers</b></a><br/>Boost sales and get new customers with our innovative tools. Witness your ads reaching large audience. </td></tr></table></div>';
echo '<div class="form"><table><tr><td align="center"><a href="/ucpromo"><img src="/uc.png" alt="UcPromo" width="35" height="40"/></a></td><td><a href="/ucpromo"><b>Uc Promote</b></a><br/>Earn Huge Amount By Promote Uc.We Give 0.04-0.14 Per UC Install.So Start Promote Uc With Us</td></tr></table></div>';
echo '<div class="form"><table><tr><td align="center"><a href="/affearn"><img src="/aff.png" alt="Affil" width="35" height="40"/></a></td><td><a href="/affearn"><b>Affialative</b></a><br/>Now We Can Help You To Earn.We Give 2 Taka For Every Affiliate.So Start Affiliate Of Your Account </td></tr></table></div>';

echo '<div class="title">Statistics</div>';
echo '<div class="form"><b id="num">'.number_format($imps).'</b> Impressions Served.<br/><b id="num">'.number_format($clciks).'</b> Clicks Served.<br/><b id="num">'.number_format($users).'</b> Users and increasing.</div>';

echo '<div class="foot" align="center"><font color="white"><b>&#169; All rights Reserved<br/><a href="/"><font color="white">DollarMob.Com</font></a> Pvt. 2014</b></font><br/></div>';

echo '</body></html>';
?>
