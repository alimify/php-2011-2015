<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Terms");

echo '<div class="form">';

echo '- In case we find that your site is against our rules we reserve the right to confiscate/ban/delete your account at any time without warning or notice.<br/>';

echo '- Your sites should not contain any illegal materials including obscenity, offending, discriminating material, racism, communalism of any kind.<br/>';

echo '- You will not use illegal means to generate impressions/clicks.<br/>';

echo '- You will not click DollarMob ads yourself.<br/>';

echo '- Modifying the adcode and caching/modifying the ads would not be done.<br/>';

echo '- This site is free for users so we can delete any site if we think the site is unfit for our network or any of our users/advertisers/publishers.<br/>';

echo '- We reserve full rights to change, delete or add any thing including user accounts.<br/>';
echo '<b>By using any of the services of DollarMob, you agree to abide by these terms and conditions.</b></div>';


echo '<div class="ad"><img src="/home.png"/> <a href="/">HOME</a></div>';
include 'foot.php';

?>