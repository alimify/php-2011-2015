<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("Payment Proofs - $SiteName");

echo '<div class="title">Payments Made by DollarMob</div>';

$getData=mysql_query("SELECT * FROM invoice WHERE status LIKE '%Paid (%' ORDER BY id DESC");

while($fetchData=mysql_fetch_array($getData)){
echo '<div class="ad"><b>Payee Name:</b> '.ucwords($fetchData["name"]).'<br/><b>Amount:</b><b id="num">'.$fetchData["amount"].'$</b><br/><b>Requested On:</b> '.$fetchData["time"].'<br/><b>Method:</b> '.$fetchData["method"].'<br/><b>Via:</b> '.substr($fetchData["via"],0,4).'******<br/><b>Status:</b> <font color="green">'.$fetchData["status"].'</font></div>';
}

echo '<div class="ad"><img src="/home.png"/> <a href="/">HOME</a></div>';

include 'foot.php';

?>