<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Invoices");

if($userlog==1){


$uid=dump_udata("id");

echo '<div class="title">All Invoices</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$invo=mysql_query("SELECT * FROM invoice WHERE userid='$uid' ORDER BY id DESC LIMIT $start,$end");
if(mysql_num_rows($invo)>0){
echo '<div class="form"><table style="border-collapse: collapse;" align="center">
  <tr>
    <th class="tbl2">ID</th>
    <th class="tbl2">Amount</th>
    <th class="tbl2">Method</th>
    <th class="tbl2">Via</th>
    <th class="tbl2">Status</th>

  </tr>';
while($show=mysql_fetch_array($invo)){
  echo '
  <tr>
    <td class="tbl"><b id="num">#'.$show["id"].'</b></td>
    <td class="tbl">'.$show["amount"].'$</td>
    <td class="tbl">'.$show["method"].'</td>
    <td class="tbl">'.$show["via"].'</td>
    <td class="tbl">'.$show["status"].'</td>

  </tr>';
}
echo '</table></div>';
echo '<div class="ad"><a href="/invoices/'.($start+1).'">Next</a></div>';
 }
else {

echo '<div class="ad">There is no invoice!</div>';
}


echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>
