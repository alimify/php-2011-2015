<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("Advertise - Statistics");


if($userlog==1){

$aid=formget("id");
$uid=dump_udata("id");


$chad=mysql_query("SELECT * FROM advertises WHERRE id='$aid' AND userid='$uid'");



$tclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE adid='$aid'"));
$vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE adid='$aid' AND status='VALID'"));
$bclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE adid='$aid' AND status='INVALID'"));
$spent=($vclicks*0.005);
$date=date("l , F d , Y");
$tdclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE adid='$aid' AND time='$date'"));
$tvclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE adid='$aid' AND status='VALID' AND time='$date'"));
$tbclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE adid='$aid' AND status='INVALID' AND time='$date'"));
$tspent=($tvclicks*0.005);

echo '<div class="title">Ad stats for ID#'.$aid.'</div>';
echo '<div class="form"><b>Total Clicks:</b> '.$tclicks.'<br/><b>Total Valid Clicks:</b> '.$vclicks.'<br/><b>Total Bonus Clicks:</b> '.$bclicks.'<br/><b>Total Spent:</b> '.$spent.'$<br/><b>Today Clicks:</b> '.$tdclicks.'<br/><b>Today Valid Clicks:</b> '.$tvclicks.'<br/><b>Today Bonus Clicks:</b> '.$tbclicks.'<br/><b>Today Spent:</b> '.$tspent.'$</div>';


$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$stat=mysql_query("SELECT * FROM clicks WHERE adid='$aid' ORDER BY id DESC LIMIT $start,$end");

include_once('country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysql_host='localhost';
$ip2c->db_user='dollarmo_p';
$ip2c->db_pass='&,M&k+X$;gPl';
$ip2c->db_name='dollarmo_p';
$ip2c->table_name='ip2c';
if(mysql_num_rows($stat)>0){
while($show=mysql_fetch_array($stat)){
echo '<div class="ad">Date: '.$show["time"].'<br/>IP: '.$show["ip"].'<br/>User Agent: '.$show["ua"].'<br/>Country: '. $ip2c->get_country_name($show["ip"]) . ' <br/>Spent: $0.005<br/>Type: '.$show["status"].'</div>';
}

echo '<div class="ad"><a href="-'.($start+1).'">Next</a></div>';
}
else {
echo '<div class="ad">There is no clicks!</div>';
}
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/advertise">Advertises</a></div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>
