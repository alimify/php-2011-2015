<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Frequently asked questions");

echo '<div class="title"><img src="/faq.png" width="16px" height="16px"/> F.A.Q</div>';

echo '<div class="form">';

echo '&#187; <a href="#what-is-dollarmob">What is DollarMob?</a><br/>';

echo '&#187; <a href="#how-it-works">How does DollarMob works?</a><br/>';

echo '&#187; <a href="#how-to-earn">How to earn from DollarMob?</a><br/>';

echo '&#187; <a href="#how-to-withdraw">How to Withdraw?</a><br/>';

echo '&#187; <a href="#how-to-advertise">How to advertise?</a><br/>';

echo '&#187; <a href="#how-to-addbalance">How to Add Funds?</a><br/>';

echo '&#187; <a href="#payment-methods">Payment Methods?</a><br/>';

echo '&#187; <a href="#payment-time">How Much Time Does It Takes To Process The Payment?</a><br/>';

echo '</div>';

echo '<div class="title">Answers:</div>';

echo '<div class="form"><a name="what-is-dollarmob"></a><b>What is DollarMob?</b><br/>DollarMob is a mobile advertising platform where user can earn revenue by publishing ads and also can advertise their products.</div>';

echo '<div class="form"><a name="how-it-works"></a><b>How does DollarMob works?</b><br/>On DollarMob, site owners can advertise their sites free of cost. You just share your users with other site owners who in return provide you their visitors.Also, you can convert the number of visitors you share into cash.</div>';


echo '<div class="form"><a name="how-to-earn"></a><b>How to earn from DollarMob?</b><br/> It is very simple to start benefiting from DollarMob. The basic structure of how DollarMob works is:<br/>
- <a href="/register">Account Signup</a><br/>
- Add your Mobile site from your dashboard.<br/>
- You place DollarMob ads on your site using PHP adcode or Javascript adcode.<br/>
- For each valid click you earn Upto 0.006$.<br/>
- For each valid click you receive from DollarMob, 0.002$-0.006$(Depend on you) will be deducted from your account. Invalid click will be given free as Bonus Clicks.<br/>
- Your visitors will come back to your site since they know your site. But users which we will send to your site will be new users for your site. This will help you grow traffic many times.</div>';

echo '<div class="form"><a name="how-to-advertise"></a><b>How to advertise?</b><br/>To advertise on DollarMob. Go to your dashboard>advertise>create ad to create new advertise. You can add funds or transfer funds from publisher account. You can also target country and devices.</div>';

echo '<div class="form"><a name="how-to-addbalance"></a><b>How to Add Funds?</b><br/>To add funds, goto your dashboard and then click on Add funds. Create an invoice and pay to DollarMob.</div>';

echo '<div class="form"><a name="payment-methods"></a><b>Payment Methods?</b><br/>Currently DollarMob support bellow methods:<br/>-Recharge (BD, IND)  <br/>- Paypal<br/>- Moneybookers (Skrill)<br/>- Bank Wire<br/>If you want any new payment methods please <a href="/contact">contact us</a>.</div>';


echo '<div class="form"><a name="payment-time"></a><b>How Much Time Does It Takes To Process The Payment?</b><br/>Currently DollarMob is paying within 15 days from invoice validation.</div>';

echo '<div class="form"><a name="how-to-withdraw"></a><b>How To Withdraw?</b><br/>To withdraw money please request money from your dashboard while your account balance is greater than $1. Please check our <a href="#payment-methods">payment methods</a>.</div>';

echo '<div class="ad"><img src="/home.png"/> <a href="/">HOME</a></div>';
include 'foot.php';

?>
