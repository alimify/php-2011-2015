<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Support ticket");

if($userlog==1){
 $uid=dump_udata("id");
 $ticket=formget("id");

 echo '<div class="title">Support ticket #'.$ticket.'</div>';

  
 $chticket=mysql_query("SELECT * FROM tickets WHERE userid='$uid' AND id='$ticket'");

 if(mysql_num_rows($chticket)>0){
   
   $tdtl=mysql_fetch_array($chticket);
   
echo '<div class="ad"><div style="background:#ececec;padding:2px;margin:2px;">Me ('.$tdtl["time"].')</div><div class="ad"><b>'.$tdtl["title"].'</b><br/>'.$tdtl["msg"].'</div></div>';

 $reply=mysql_query("SELECT * FROM treplys WHERE tid='$ticket'");
 
 if(mysql_num_rows($reply)>0){
    $replys=mysql_fetch_array($reply);

   
   echo '<div class="ad"><div style="background:#ececec;padding:2px;margin:2px;">Replied by Admin ('.$replys["date"].')</div><div class="ad"><b>Re1: '.$tdtl["title"].'</b><br/>'.$replys["reply"].'</div></div>';
    }

}
else {
 echo 'holy its not your ticket';
 }

  echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/support-ticket">Support Tickets</a></div>';
 
 include 'foot.php';

 }

 else {

 header('Location:/');
 }

?>
  