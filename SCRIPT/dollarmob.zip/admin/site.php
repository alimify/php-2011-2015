<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Site Details");

if($adminlog==1){

 $sid=formget("id");

 $sdata=mysql_query("SELECT * FROM sites WHERE id='$sid'");
 $sfdata=mysql_fetch_array($sdata);

 echo '<div class="title">Site Details: #'.$sid.'</div>';
 echo '<div class="form"><b>Site Name:</b> '.$sfdata["name"].'<br/><b>Site Url:</b> '.$sfdata["url"].'<br/><b>Site Description:</b> '.$sfdata["descr"].'<br/><b>Status:</b> '.$sfdata["status"].'<br/><b>Owner:</b> <a href="user.php?id='.$sfdata["userid"].'">USER#'.$sfdata["userid"].'</a><br/><br/><b>ACTIONS:</b><br/>- <a href="sitestat.php?id='.$sfdata["id"].'">Statistics</a><br/>- <a href="sblock.php?id='.$sfdata["id"].'">Block Site</a><br/>- <a href="sactivate.php?id='.$sfdata["id"].'">Active Site</a></div>';
 echo '<a href="sites.php"><div class="ua">SITES</div></a>';
 include '../foot.php';
}
else {
header('Location:login.php');
}
?>