<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Reffer");

if($adminlog==1){

$act=formget("act");
$user=formget("user");

$hammad = mysql_query("SELECT * FROM ref WHERE refuser='$user' AND validated='0'");
$khan = mysql_fetch_array($hammad);

$adding = mysql_query('SELECT * FROM userdata WHERE firstname="'.$khan['refid'].'"');
$points = mysql_fetch_array($adding);

$ref=$khan['refid'];
$wolfadd=$points['pubalance']+0.026;

if ($act=="approve")
{
echo '<div class="done">Successfully Updated</div>';
mysql_query('UPDATE ref SET validated = "1"
WHERE refuser = "'.$user.'"');

mysql_query('UPDATE userdata SET pubalance = "'.$wolfadd.'"
WHERE firstname = "'.$khan['refid'].'"');

mysql_query("INSERT INTO notifications (user, news , other, stat)
VALUES (''.$ref.'', 'Your Reffer user has been Successfully Approved', 'none', 'none')");

echo "done";
include "../foot.php";

die();
}
else

if ($act=="delete")
{
echo '<div class="title">Deleted</div>';
mysql_query('DELETE FROM ref WHERE id="'.$_GET['id'].'"');
echo '<div class="success">Deleted Successfully</div>';
echo '<div class="lgn"><font color=red><b>'.$user.' delete successfully</b></font></div>';
include "../foot.php";
die();
}

echo '<div class="title">Validation Of referrers</div>';
$result = mysql_query('SELECT * FROM ref WHERE validated ="0"');
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
   echo '<div class="ad">Unvalidated Referrer : <b><a href="user.php?user='.$row['refuser'].'">'.$row['refuser'].'</a></b> Referred By <b><a href="user.php?user='.$row['refid'].'">'.$row['refid'].'</a></b> site = <b>'.$row['site'].'</b> <a href="?act=approve&user='.$row['refuser'].'"><font color=red>Approve</font></a> |<a href="?act=delete&id='.$row['id'].'"><font color=red>Reject</font><br></div>';

}
}
else
{ header('Location:/');
}
include "../foot.php";
?>