<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Sites");

if($adminlog==1){

echo '<div class="title">Sites</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$ads=mysql_query("SELECT * FROM sites ORDER BY id DESC LIMIT $start,$end");
 
 while($sites=mysql_fetch_array($ads)){
  echo '<a href="site.php?id='.$sites["id"].'"><div class="ua">Site ID: '.$sites["id"].'<br/>Url: '.$sites["url"].'<br/>Status: '.$sites["status"].'</div></a>';
 }
 echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';
 echo '<a href="index.php"><div class="ua">Home</div></a>';
 include '../foot.php';
}
else {
header('Location:index.php');
}
?>