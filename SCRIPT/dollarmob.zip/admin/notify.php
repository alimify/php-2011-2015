<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

$uid=formget("id");
$user=formget("usr");

if(isset($_POST['reply'])){

$reply=formpost("reply");
 $doreply=mysql_query("INSERT INTO notifications (user,news) VALUES ('$user','$reply')");

 if($doreply){
   echo '<div class="success">User '.$user.' has Notified!</div>';
 }
 else {
   echo 'Unknown error!';
 }
 }
 echo '<div class="title">Notify '.$user.'</div><div class="form"><form method="post">Notify: <br/><textarea name="reply"></textarea><br/><input type="submit" value="Reply"/></form></div>';


if(mysql_num_rows(mysql_query("SELECT * FROM notifications"))){

$result = mysql_query('SELECT * FROM notifications WHERE user="'.$user.'"');
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
   echo '<div class="title">User: <b>'.$row[user].'</b> <a href="?act=yes&id='.$row['id'].'"><font color=red>x</font></a></div>
<div class="ad"> '.$row['news'].' </div>';
}

}
else
{
echo "no news";

}

echo '<a href="notify.php"><div class="ua">Notify</div></a>';
include '../foot.php';
}
else {
header('Location:login.php?error=log&err=session');
}

?>