<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);

$invoice=mysql_query("SELECT * FROM invoice WHERE status='PENDING' ORDER BY id DESC LIMIT $start,$end");


while($invoices=mysql_fetch_array($invoice)){
echo '<div class="ad">INVOICE: #'.$invoices["id"].'<br/>Amount: '.$invoices["amount"].'$<br/>Method: '.$invoices["method"].' ('.$invoices["via"].')<br/>Created: '.$invoices["time"].'<br/>Created By: <a href="user.php?id='.$invoices["userid"].'">USER#'.$invoices["id"].'</a><br/> <a href="validate.php?id='.$invoices["id"].'">Validate</a> - <a href="pay.php?id='.$invoices["id"].'">Pay Now</a></div>';
}

echo '<div class="ad"><a href="?page='.($page+1).'">Next</a></div>';
echo '<a href="index.php?redir=unpay"><div class="ua">Home</div></a>';

include '../foot.php';

}
else {

header('Location:/login.php?error=ticket&reason=session');
}

?>
