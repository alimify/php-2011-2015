<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

echo '<div class="title">All Users</div>';

echo '<div class="form">Sort By: <a href="?sort=latest">Latest</a> - <a href="?sort=money">Balance</a> - <a href="?sort=name">Name</a></div>';

$sort=formget("sort");
$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*10;
$end=($start+10);
if($sort=="money"){
$stat=mysql_query("SELECT * FROM userdata ORDER BY pubalance DESC LIMIT $start,$end");
}
elseif($sort=="name"){
$stat=mysql_query("SELECT * FROM userdata ORDER BY firstname ASC LIMIT $start,$end");
}
else {
$stat=mysql_query("SELECT * FROM userdata ORDER BY id DESC LIMIT $start,$end");
}
if(mysql_num_rows($stat)>0){

echo '<div class="form">';
while($show=mysql_fetch_array($stat)){

echo '<a href="user.php?id='.$show["id"].'"><div class="ua">Email: '.$show["email"].'<br/>Name: '.ucfirst($show["firstname"]).' '.ucfirst($show["lastname"]).'<br/>User ID: '.$show["id"].'</div></a>';

}
echo '</div>';
echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';
}

echo '<a href="index.php?goto=home"><div class="ua" align="center"><b>HOME</b></div></a>';

include '../foot.php';
}
else {

header('Location:login.php?error=session&out=no&valid=no&session=no');
}

?>
