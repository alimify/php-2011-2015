<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

 $vid=formget("id");

$doit=mysql_query("UPDATE adinvoice SET status='VALIDATED' WHERE id='$vid'");
 if($doit){
   $get_use=mysql_query("SELECT * FROM adinvoice WHERE id='$vid'");
   $get_us=mysql_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysql_fetch_array($get_u);
   $emailz=$get_user["email"];
   $newbal=$get_user["adbalance"];
   $adbal=($newbal+$get_us["amount"]);
   mysql_query("UPDATE userdata SET adbalance='$adbal' WHERE id='$uid'");
   
   echo '<div class="success">Successfully validated!</div>';
       $to      = $emailz;
    $subject = 'Advertise Invoice Validated At DollarMob';
    $message = 'Dear '.$get_user["firstname"].',
We are happy to tell you that your Adinvoice #DollarMob'.$vid.' has been successfully validated and the balance has added in your advertisement balance!

Thank You!



Thanks,
DollarMob.Com';
    $headers = 'From: DollarMob.Com<'.$Adminmail.'>' . "\r\n" .
    'Reply-To: '.$Adminmail.'' . "\r\n" .
    'X-Mailer: DollarMob';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unadinvo.php"><div class="ua">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>