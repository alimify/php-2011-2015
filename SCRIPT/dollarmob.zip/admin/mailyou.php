<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<link href="../style.css" rel="stylesheet" type="text/css" />
<div class="line"><b>Mail Users</b></div>
<title>Mail All Users</title>
<?php
include "../db.php";
include "../db.php";
if (isset($_REQUEST['subject']))
//if "subject" is filled out, send email
  {
  //send email
  $subject = $_REQUEST['subject'] ;
  $message = $_REQUEST['message'] ;
$rs = mysql_query('SELECT email from userdata LIMIT 0, 2000');
$from = "support@dollarmob.com";
$headers = "From:" . $from;

while(list($mail) = mysql_fetch_row($rs))
{
// Send Email
mail($mail,$subject,$message,$headers);

  echo '<div class="ok">'.$row[user].'<font color=green>Mail Sent SuccessFully !</font></div><br/>';
}
  }
else
//if "subject" is not filled out, display the form
  {
  echo "<form method='post' action='mailyou.php'>
  Subject: <input name='subject' type='text' /><br />
  Message:<br />
  <textarea name='message' rows='15' cols='40'>
  </textarea><br />
  <input type='submit' />
  </form>";
  }
?>
<?php include "../foot.php"; ?>
