<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Admin Panel Beta");

if($adminlog==1){

echo '<div class="title">Welcome, <b><font color="white">Administrator ('.ucwords($admu).')</font></b></div>';

$auser=mysql_query("SELECT * FROM userdata WHERE status='ACTIVE'");
$tuser=mysql_num_rows(mysql_query("SELECT * FROM userdata"));
$iuser=mysql_query("SELECT * FROM userdata WHERE status='INACTIVE'");
$buser=mysql_query("SELECT * FROM userdata WHERE status='BLOCKED'");
$asite=mysql_query("SELECT * FROM sites WHERE status='<font color=\'green\'>Active</font>'");
$bsite=mysql_query("SELECT * FROM sites WHERE status='BLOCKED'");
$rads=mysql_query("SELECT * FROM advertises WHERE status='RUNNING'");
$pads=mysql_query("SELECT * FROM advertises WHERE status='PENDING'");
$bads=mysql_query("SELECT * FROM advertises WHERE status='REFUSED'");

$uc_act=mysql_query("SELECT * FROM ucuser WHERE userid='1'");
$uc_inact=mysql_query("SELECT * FROM ucuser WHERE userid='0'");

$reffer_act=mysql_query("SELECT * FROM ref WHERE validated='1'");
$reffer_inact=mysql_query("SELECT * FROM ref WHERE validated='0'");

$ausers=mysql_num_rows($auser);
$iusers=mysql_num_rows($iuser);
$busers=mysql_num_rows($buser);
$asites=mysql_num_rows($asite);
$bsites=mysql_num_rows($bsite);
$rad=mysql_num_rows($rads);
$pad=mysql_num_rows($pads);
$bad=mysql_num_rows($bads);
$ucact=mysql_num_rows($uc_act);
$ucinact=mysql_num_rows($uc_inact);
$refferact=mysql_num_rows($reffer_act);
$refferinact=mysql_num_rows($reffer_inact);

$ticket=mysql_query("SELECT * FROM tickets WHERE status='Waiting for Admin\'s reply'");

if(mysql_num_rows($ticket)>0){

$tickets=mysql_num_rows($ticket);

echo '<a href="ticket.php"><div class="error">There are '.$tickets.' tickets waiting for reply!</div></a>';
}

if(mysql_num_rows($pads)>0){

$padv=mysql_num_rows($pads);

echo '<a href="advertise.php"><div class="error">There are '.$padv.' advertise waiting for activation!</div></a>';
}

if(mysql_num_rows($uc_inact)>0){

$udv=mysql_num_rows($uc_inact);


echo '<a href="ucweb.php"><div class="error">There are '.$udv.' UcWeb waiting for activation!</div></a>';
}

if(mysql_num_rows($reffer_inact)>0){

$reff=mysql_num_rows($reffer_inact);


echo '<a href="reffer.php"><div class="error">There are '.$reff.' Affialative waiting for activation!</div></a>';
}

$chinvo=mysql_query("SELECT * FROM invoice WHERE status='PENDING'");

if(mysql_num_rows($chinvo)>0){
$invo=mysql_num_rows($chinvo);
echo '<a href="unpayinvo.php"><div class="error">There are '.$invo.' Unpaid user invoices!</div></a>';
}

$adchinvo=mysql_query("SELECT * FROM adinvoice WHERE status='PENDING'");

if(mysql_num_rows($adchinvo)>0){
$adinvo=mysql_num_rows($adchinvo);
echo '<a href="unadinvo.php"><div class="error">There are '.$adinvo.' Unchecked ad invoices!</div></a>';
}

echo '<div class="form"><form method="get" action="user.php"><input type="text" name="id" value="User Id"/><input type="submit" value="Go"/></form><form method="get" action="search.php"><input type="text" name="q" value="Search User"/><input type="submit" value="Search"/></form></div>';

$total_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks"));
$total_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE status='VALID'"));
$date2=date("d-m-Y");
$today_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date2'"));
$today_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date2' AND status='VALID'"));
$total_iclicks=($total_clicks-$total_vclicks);
$today_iclicks=($today_clicks-$today_vclicks);
$total_earn=($total_vclicks*0.005);
$today_earn=($today_vclicks*0.005);
$total_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice"));
$paid_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE status LIKE '%Paid%'"));
$pending_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE status LIKE '%Pending%'"));
$validated_invo=mysql_num_rows(mysql_query("SELECT * FROM invoice WHERE status LIKE '%Validated%'"));

$total_news=mysql_num_rows(mysql_query("SELECT * FROM news"));
$total_reply=mysql_num_rows(mysql_query("SELECT * FROM newsreplys"));

echo '<div class="title">Main Menu</div>';

echo '<div class="form" style="padding:0px;margin:2px;">';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="users.php">Users</a></b><br/>'.$tuser.' Total, '.$ausers.' Active, '.$iusers.' Inactive, '.$busers.' Blocked.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="sites.php">Sites</a></b><br/>'.($asites+$bsites).' Total, '.$asites.' Active, '.$bsites.' Blocked.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="stats.php">Statistics</a></b><br/>'.$total_clicks.' Total, '.$today_clicks.' Today, '.$total_earn.'$ Total, '.$today_earn.'$ Today.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="advertise.php">Advertises</a></b><br/>'.($rad+$pad+$bad).' Total, '.$rad.' Running, '.$pad.' Pending, '.$bad.' Refused.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="invoice.php">Invoices</a></b><br/>'.$total_invo.' Total, '.$paid_invo.' Paid, '.$pending_invo.' Pending, '.$validated_invo.' Validated.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="alluc.php">UcWeb</a></b><br/>'.$ucact.' Active, '.$ucinact.' Inactive.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="mail.php">Mail</a></b><br/>Mail To User</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="mailyou.php">Mail All</a></b><br/>Mail To All User</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="reffer.php">Affialative</a></b><br/>'.$refferact.' Active, '.$refferinact.' Waiting.</div>';

echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="news.php">News</a></b><br/>'.$total_news.' News, '.$total_reply.' Replies.</div>';

if($admin_id=='pranto'){

$admin_count=count(glob("admins/*.pra"));
echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="admins.php">Admins</a></b><br/>'.$admin_count.' Active Admins</div>';
}


echo '<div style="border-bottom:1px dotted #ccc;padding:4px;"><b><a href="account.php">Account</a></b><br/>Manage Account and Password</div>';
echo '</div>';

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="logout.php">Logout</a></div>';
include '../foot.php';



}
else {

header('Location:login.php?redir=index');

}


?>
