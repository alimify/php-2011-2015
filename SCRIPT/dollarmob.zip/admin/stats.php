<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Stats");

if($adminlog==1){

$total_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks"));
$total_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE status='VALID'"));
$date=date("d-m-Y");
$today_clicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date'"));
$today_vclicks=mysql_num_rows(mysql_query("SELECT * FROM clicks WHERE time='$date' AND status='VALID'"));
$total_iclicks=($total_clicks-$total_vclicks);
$today_iclicks=($today_clicks-$today_vclicks);
$total_earn=($total_vclicks*0.005);
$today_earn=($today_vclicks*0.005);

echo '<div class="title">Statistics</div>';
echo '<div class="form" align="center"><table><tr><td><div class="ad" style="padding:5px;margin:5px;"><div style="background:#ececec;padding:2px;margin:2px;" align="center"><b>Total:</b></div><div class="ad" style="padding:3.5px">Total clicks: '.$total_clicks.'<br/>Total Valid Clicks: '.$total_vclicks.'<br/>User earned total: '.$total_earn.'$</div></td><td><div class="ad" style="padding:5px;margin:5px;"><div style="background:#ececec;padding:2px;margin:2px;" align="center"><b>Today:</b></div><div class="ad" style="padding:3.5px">Today clicks: '.$today_clicks.'<br/>Today Valid Clicks: '.$today_vclicks.'<br/>User earned today: '.$today_earn.'$</div></td></tr></table></div>';

echo '<div class="title">Statistic Report</div>';

$page=formget("page");

if(empty($page)){
$page=0;
}
$start=$page*50;
$end=($start+50);

$stat=mysql_query("SELECT * FROM clicks ORDER BY id DESC LIMIT $start,$end");

include_once('../country/ip2country.php');
$ip2c=new ip2country();
$ip2c->mysql_host='localhost';
$ip2c->db_user='dollarmo_p';
$ip2c->db_pass='&,M&k+X$;gPl';
$ip2c->db_name='dollarmo_p';
$ip2c->table_name='ip2c';
if(mysql_num_rows($stat)>0){

echo '<div class="form"><table style="border-collapse: collapse;" align="center">
<tr>
<th class="tbl2">Date</th>
<th class="tbl2">IP</th>
<th class="tbl2">User-Agent</th>
<th class="tbl2">Country</th>
<th class="tbl2">Type</th>
<th class="tbl2">From</th>
<th class="tbl2">Ads</th>
<th class="tbl2">Site</th>
</tr>';

while($show=mysql_fetch_array($stat)){



echo '<tr>
<td class="tbl">'.$show["time"].'</td>
<td class="tbl">'.$show["ip"].'</td>
<td class="tbl">'.strstr(urldecode($show["ua"]),'(',true).'</td>
<td class="tbl">'. $ip2c->get_country_name($show["ip"]) . '</td>
<td class="tbl">'.$show["status"].'</td>
<td class="tbl"><a href="'.$show["host"].'">'.strstr(str_replace('http://',null,$show["host"]),'/',true).'</a></td>
<td class="tbl">'.$show["adtype"].'</td>
<td class="tbl"><a href="site.php?id='.$show["siteid"].'">'.$show["siteid"].'</a></td>
</tr>';


}

echo '



</table></div>';

echo '<div class="ad"><a href="?page='.($start+1).'">Next</a></div>';
}
else {
echo '<div class="ad">There is no clicks!</div>';
}

echo '<a href="index.php"><div class="ua">HOME</div></a>';
include '../foot.php';
}
else{
header('Location:index.php');
}
?>
