<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate Invoice");

if($adminlog==1){

 $vid=formget("id");

 $nextWeek =time()+(15 * 24 * 60 * 60);
 $date=date("d-m-Y",$nextWeek);

 $doit=mysql_query("UPDATE invoice SET status='VALIDATED ( Will be paid on $date)' WHERE id='$vid'");
 if($doit){
   $get_use=mysql_query("SELECT * FROM invoice WHERE id='$vid'");
   $get_us=mysql_fetch_array($get_use);
   $uid=$get_us["userid"];
   $get_u=mysql_query("SELECT * FROM userdata WHERE id='$uid'");
   $get_user=mysql_fetch_array($get_u);
   $emailz=$get_user["email"];
   echo '<div class="success">Successfully validated!</div>';
       $to      = $emailz;
    $subject = 'DollarMob - Invoice Validated';
    $message = 'Dear '.$get_user["firstname"].',
We are happy to tell you that your invoice #DollarMob'.$vid.' has been successfully validated. It will be paid within '.$date.' and you will get a notification email.

Thank You!

Thanks,
DollarMob Team,
DollarMob.Com';
    $headers = 'From: DollarMob.Com<'.$Adminmail.'>' . "\r\n" .
    'Reply-To: '.$Adminmail.'' . "\r\n" .
    'X-Mailer: DollarMob';

    mail($to, $subject, $message, $headers);
 }
 else {
  echo 'Unknown error';
 }
echo '<a href="unpayinvo.php"><div class="ua">HOME</div></a>'; 

 include '../foot.php';

 }
 else {
 header('Location:login.php');
 }
?>