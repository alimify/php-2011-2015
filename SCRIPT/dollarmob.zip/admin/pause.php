<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Ads");

if($adminlog==1){

$aid=formget("id");

 $doit=mysql_query("UPDATE advertises SET status='Paused' WHERE id='$aid'");
 if($doit){
   echo 'Advertise Paused!';
 }
 else {
  echo 'ad is not running.';
 }
echo '<a href="advertise.php"><div class="ua">Advertises</div></a>';
include '../foot.php';
}
else {
header('Location:index.php');
}
?>