<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<link href="../style.css" rel="stylesheet" type="text/css" />
<div class="line"><b>Mail Users</b></div>
<title>Mail Users</title>
<?php
include "../db.php";
include "../db.php";

if (isset($_REQUEST['mail']))
//if "mail" is filled out, send email
  {
  //send email
  $subject = $_REQUEST['subject'] ;
  $message = $_REQUEST['message'] ;
  $mail = $_REQUEST['mail'] ;
$from = "support@dollarmob.com";
$headers = "From:" . $from;

// Send Email
mail($mail,$subject,$message,$headers);

  echo '<div class="ok"> <font color=red><b>'.$mail.'</b></font> - <font color=green>Mail Sent SuccessFully !</font></div><br/>';
}
else
//if "mail" is not filled out, display the form
  {
  echo "<form method='post' action='mail.php'>
  Subject: <input name='subject' type='text' /><br />
 Mail: <input name='mail' type='text' /><br />
  Message:<br />
  <textarea name='message' rows='15' cols='40'>
  </textarea><br />
  <input type='submit' />
  </form>";
  }
?>
<?php include "../foot.php"; ?>