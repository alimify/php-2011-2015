<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - Validate UcWeb");

if($adminlog==1){

$time = date("F j Y"); 
$act=formget("act");
$user=formget("user");
$id=formget("id");

echo '<div class="title">Ucweb</div>';

$result=mysql_query("SELECT * FROM ucuser WHERE userid=0");

if($act=='added'){

$link=formpost("uclink");

$hammad = mysql_query('SELECT * FROM userdata WHERE firstname="'.$user.'"');
$khan = mysql_fetch_array($hammad);
$email = $khan['email'];

mysql_query('UPDATE ucuser SET uclink="'.$link.'", userid="1" WHERE user="'.$user.'"');
echo '<div class="ad">'.$user.' -  '.$link.' UcLink Set Automaticaly</div>';

$to = $khan['email'];
$subject = "Congratulations your site Approved On DollarMob.Com";
$message = 'Congratulation '.$user.',

Your Site On DollarWap.Com Ucweb Promoting Has been Approved

Please follow these steps to Earn Money:

Step One: Copy promotion link

Your promotion link is '.$link.', please promote the link any where.and get 0.04$ per install
Step Two: Promote UC Browser

Put the promotion link of yours on your sites or anywhere you could take advantage of, start promoting UC Browser with your promotion link.
you can check your daily install statistics in DollarMob.Com Control Panel.

If you have any questions, please send a mail for inquiry to '.$Adminmail.', we will reply as soon as possible. Thank you for your support for DollarMob.Com!

DollarMob Team

Regards,
DollarMob Admin';
$from = "support@dollarmob.com";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);
mysql_query("INSERT INTO notifications (user, news , other, stat)
VALUES ('$user', 'Your Site On DollarMob.Com Ucweb Promoting Has been Approved', 'none', 'none')");
}



elseif($act=='sent'){

echo '<div class="line"><b>Set UcWeb Link user '.$user.'</b></div>';
echo '<form action="?act=added&user='.$user.'" method="post">
UcLink <input type="text" name="uclink" /><br>
<input type="submit" value="Submit" />
</form>';
}

elseif($act=='del'){

$hammad = mysql_query('SELECT * FROM userdata WHERE firstname="'.$user.'"');
$khan = mysql_fetch_array($hammad);
$mail = $khan['mail'];

mysql_query('DELETE FROM ucuser WHERE user="'.$user.'"');
echo '<div class="error">'.$user.' -  UcLink Rejected Automaticaly</div>';

$to = $khan['email'];
$subject = "Sorry your site Not Approved On DollarMob";
$message = 'Dear '.$user.',

Your Site On DollarMob.Com Ucweb Promoting Has been Not Approved
Becouse One of Below Reasons.
1) We Dont Found Our Adcode On Your Site
2) Your Site Already In Ucweb. 
3) Your Site Is Non-Adult Site.
4) No Contents On Your Site.

For Approve!
Please Submit A Top list or adult site..
and dont submit site that already added in ucweb.

If you have any questions, please send a mail for inquiry to '.$Adminmail.', we will reply as soon as possible. Thank you for your support for DollarMob!

DollarMob Team

Regards,
DollarMob Admin';
$from = "support@dollarmob.com";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);
mysql_query("INSERT INTO notifications (user, news , other, stat)
VALUES ('$user', 'Sorry your site Not Approved On Ucweb Promoting', 'none', 'none')");
}
else
{
$result=mysql_query("SELECT * FROM ucuser WHERE userid=0");

while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
$url = $row['link'];
$id = $row['id'];
$site = $row['title'];
$cat = $row['cat'];
$user = $row['user'];

   echo '<div class="ad"><b>User Name: <a href="user.php?id='.$khan['id'].'">'.$row['user'].'</a></b><br/>
Site Url: <font color=green>'.$row['link'].'</font><br/>Title: <font color=red>'.$row['title'].'</font>
<br/>Catagorie: <font color=red>'.$row['cat'].'</font><br/>

<a href="?act=sent&id='.$row['id'].'&user='.$row['user'].'"><b>[Set Link]</b></a> || <a href="?act=del&id='.$row['id'].'&user='.$row['user'].'"><b>[Reject]</b></a></div>
';
}
}
include "../foot.php";

} else { header('Location:/');
}

?>
