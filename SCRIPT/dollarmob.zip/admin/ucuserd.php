<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include '../db.php';
include '../functions.php';

headtag("$SiteName - UcPromoter Details");

if($adminlog==1){

 $sid=formget("id");

 $sdata=mysql_query("SELECT * FROM ucuser WHERE id='$sid'");
 $sfdata=mysql_fetch_array($sdata);

 echo '<div class="title">UC Site Details: #'.$sid.'</div>';
 echo '<div class="form"><b>Title:</b> '.$sfdata["title"].'<br/><b>Site Url:</b> '.$sfdata["link"].'<br/><b>Site Type:</b> '.$sfdata["cat"].'<br/><b>Uc Link:</b> '.$sfdata["uclink"].'<br/><b>Owner:</b>USER# '.$sfdata["user"].'</a><br/><b>Install:</b>'.$sfdata["install"].'</a><br/><b>UC BAl:</b>'.$sfdata["ucbal"].' $</a><br/><b>ACTIONS:</b><a href="ucweb.php?act=sent&id='.$sfdata['id'].'&user='.$sfdata['user'].'"><b>[Set Link]</b></a> || <a href="ucweb.php?act=del&id='.$sfdata['id'].'&user='.$sfdata['user'].'"><b>[Reject]</b></a></div>';
 echo '<a href="alluc.php"><div class="ua">SITES</div></a>';
 include '../foot.php';
}
else {
header('Location:login.php');
}
?>