<?php  

//Adsfresh

 include "db.php";
 include "functions.php";

headtag("$SiteName - EARN MONEY VIA AFFIALATIVE");


echo '<div class="title"><b>Earn Money Via Affiliate:</b></div>
<div class="form"><b>Rules Of Affialative:-</b><br/>
     <ol>
            <li><b>Share Your Afflite link(Collect From Dashboard) with your friends And Earn <font color=red>2 TAKA</font> Per Affiliate. If They Finish Their balance <font color=green>10 TAKA(0.133$)</font></b> When Refferal user Reach His Balance 10 TAKA</li>
            <li>Dont Register More Than 1 id (You Donot Get Money And You Blocked)</li>
            <li>We Will Automaticaly Add Referal Balance When Ref User Reach 10 Taka.</li>
            <li>ALL Referrers Show Here after Validation By DollarMob Admin</li>
</br>
<a href="/user/registration"><b>Register Now !</b></a></div>

';
include 'foot.php';


?>
