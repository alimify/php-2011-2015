<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Adcodes");

if($userlog==1){

echo '<div class="title"><b>UCWEB Reports(August)</b></div>';
echo '<div class="ok"><b><font color="red">Must Read This :</font>This is All Users Report and Ucreport Will
Update Daily Till 10 Am
The Formate Of this Report Is Username : Date Java
Installs-Android Installs, Total Java Installs= , Total Android
Installs=
If Any Question you can mail me @
support@dollarmob.com
<font color="red">Price : Java=0.04$/per install & Android=0.12$/install</font></b></div>';

echo '<div class="ad"><b><font color="red">bdkawser</font> :14st 0-2,15st 1-3,16st 2-13,17st 0-6,18st 1-4,19st 1-13,20st 1-15,21st 1-4,22st 0-3,23st 1-9,24st 0-6,25st 1-9,26st 0-6,27st 0-5,28st 0-5,29st 0-4,30st 0-2,31st 1-4</br>Java=10, Android=113</b></div>';

echo '<div class="ad"><b><font color="red">Ashraf</font> :14st 0-0,15st 0-0,16st 0-55,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=55</b></div>';


echo '<div class="ad"><b><font color="red">bashir</font> :14st 0-0,15st 0-0,16st 0-1,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-1,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=2</b></div>';

echo '<div class="ad"><b><font color="red">BDmovies24.com</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-1,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=1</b></div>';


echo '<div class="ad"><b><font color="red">Junior</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st -0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=0</b></div>';

echo '<div class="ad"><b><font color="red">arshadwap</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-31,20st 0-57,21st 0-36,22st 0-0,23st 0-27,24st 0-37,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-42,30st 0-22,31st 0-0</br>Java=0, Android=252</b></div>';

echo '<div class="ad"><b><font color="red">virendra</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=0</b></div>';


echo '<div class="ad"><b><font color="red">Jintu</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=0</b></div>';


echo '<div class="ad"><b><font color="red">raziul</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 2-0,21st 0-0,22st 0-0,23st 1-1,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 1-0,29st 0-0,30st 0-0,31st 0-0</br>Java=4, Android=1</b></div>';

echo '<div class="ad"><b><font color="red">Mobi2Chat</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=0,</b></div>';

echo '<div class="ad"><b><font color="red">pridhiman</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=0</b></div>';

echo '<div class="ad"><b><font color="red">Ontohin</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 0-0,29st 0-0,30st 0-0,31st 0-0</br>Java=0, Android=0</b></div>';

echo '<div class="ad"><b><font color="red">Sarwar</font> :14st 0-0,15st 0-0,16st 0-0,17st 0-0,18st 0-0,19st 0-0,20st 0-0,21st 0-0,22st 0-0,23st 0-0,24st 0-0,25st 0-0,26st 0-0,27st 0-0,28st 4-5,29st 2-1,30st 1-0,31st 0-0</br>Java=7, Android=6</b></div>';

include 'foot.php';
}
else {
header('Location:/');
}
?>
