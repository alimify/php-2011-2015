<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Forgot password");

if($userlog==1){
header('Location:/user/dashboard');
}
else {
  if(isset($_POST['user_email']) AND isset($_POST['captcha'])){
     
     $user_email=formpost("user_email");
     $captcha=formpost("captcha");
     $captcha=strtoupper($captcha);

     $errors=array();


     $check_email=mysql_query("SELECT * FROM userdata WHERE email='$user_email'");
     if(mysql_num_rows($check_email)<1){
        $errors[]='No such user with this email!';
      }
     if(strlen($user_email)<1){
        $errors[]='Email field left empty!';
      }
     
     if($_SESSION['captcha']!=$captcha){
         $errors[]='Captcha code was wrong!';
       }



     if(empty($errors)){
        $token=md5(microtime()*2);
        $check_if=mysql_query("SELECT * FROM passret WHERE email='$user_email'");
        if(mysql_num_rows($check_if)<1){
        $do_input=mysql_query("INSERT INTO passret (email,token) VALUES ('$user_email','$token')");
         }
        else {
        $do_input=mysql_query("UPDATE passret SET token='$token' WHERE email='$user_email'");
         }

        if($do_input){
           
           
        
   
    $to      = $user_email;
    $subject = 'Password Reset';
    $message = 'Dear user,

Please click bellow link to rest your password and choose a new one!

http://dollarmob.com/reset/'.$user_email.'/'.$token.'



Support:
support@dollarmob.com
+88-018-326-10786

Thanks,
DollarMob Team,
DollarMob.Com';
    $headers = 'From: DollarMob.Com<support@dollarmob.com>' . "\r\n" .
    'Reply-To: support@dollarmob.com' . "\r\n" .
    'X-Mailer: DollarMob';

    mail($to, $subject, $message, $headers);
echo '<div class="title"><img src="/success.png"/> Success!</div>';
echo '<div class="success">Your Password reset link has successfully sent to your email!</div>';


}
}
else {
echo '<div class="title"><img src="/error.png"/> Error happened!</div>';
echo '<div class="error">';
foreach($errors as $error){
echo ''.$error.'<br/>';
}

echo '</div>';
}


}
echo '<div class="title"><img src="/forgot.png"/> Password reset</div>';
echo '<div class="form"><form method="post"><label for="user_email">Email:</label><br/><input type="text" name="user_email"/><br/><label for="captcha">Captcha:</label><br/><img src="/im'.md5(microtime()).'.jpg" alt="loading"/><br/>Input the characters showing in the image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Reset"/></form></div>';

}

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> &#171; Password reset</div>';

include 'foot.php';

?>