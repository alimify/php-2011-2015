<?php  

//Adsfresh

 include "db.php";
 include "functions.php";

headtag("$SiteName - Sex Download Menu");


echo '<div class="title"><b>Sex Download Menu</b></div>
<div class="form"><a href="http://sunbux.info/ads.php?id=s61pteaafg">Xclusive Best Wap Sites !</a></div>
<div class="form"><a href="http://wapdollar.in/serve.php?id=iK8yf3bvHn"><img src="http://wapdollar.in/banner5.gif" border="0" /></a></b></div>
<div class="form"><script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=5xeq9wg8m6"></script></div>
';
include 'foot.php';


?>
