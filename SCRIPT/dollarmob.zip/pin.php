<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Transfer Money");

if($userlog==1){

echo '
<div class="title" align="center"><b>Set Pin</b></div>';
$user=dump_udata("firstname");
$getu = mysql_query("SELECT * FROM userdata WHERE firstname='$user'");
$getu1 = mysql_fetch_array($getu);
$id = $getu1['id'];
$user = $getu1['firstname'];

// Secure Your Data
function hammad($str) {
$str = htmlentities(mysql_real_escape_string(trim($str)), ENT_QUOTES, 'UTF-8');



$str = nl2br($str);



$str = addslashes($str);



$str = str_replace("'", "&#39;", $str);



$str = str_replace('\\', "&#92;", $str);



$str = str_replace("|", "I", $str);



$str = str_replace("||", "I", $str);



$str = str_replace("/\\\$/", "&#36;", $str);



return $str;
}
$pin = hammad($_POST['pin']);


if((isset($_POST['pin']))) {

$pin=formpost("pin");
$pin = mysql_query("SELECT * FROM skip WHERE user='$user'");
$getpin = mysql_num_rows($pin);

$do=mysql_query('INSERT INTO skip (user, pin, other)
VALUES ("'.$user.'","'.$pin.'", "none")');

if($do) {
    print "<div class='ok'>Pin Activated Successfully !</div>";
} else {
    print "<div class='error'>UNABLE TO EDIT !</div>";
}

}


$pin = $getu1['pin']; 

$site= $getu1['site'];

if($getpin>0)
{
echo 'Unknown error';
} else {
echo '<div class="form"><form action="pin.php" method="post">
<label for="user">Secure Pin:</label><br />
<input size="30" maxlength="5" type="number" name="pin" value="" />
<input type="submit" class="btn_awesome btn" value="Edit" />
</div>


</form></div>';

}
}
else { header('Location:/'); }

include "foot.php"; ?>