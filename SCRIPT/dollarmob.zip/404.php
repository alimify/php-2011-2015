<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - 404 Error");

echo '<div class="title">404 ERROR:</div>';

echo '<div class="error">The page you are looking for was not found on the server!</div>';

echo '<div class="ad"><img src="/home.png"> <a href="/">Home</a></div>';

include 'foot.php';
?>