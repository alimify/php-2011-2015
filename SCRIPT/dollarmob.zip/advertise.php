<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Advertisement management");

if($userlog==1){

echo '<div class="title">Advertises</div>';
$uid=dump_udata("id");

$adver=mysql_query("SELECT * FROM advertises WHERE userid='$uid'");

if(mysql_num_rows($adver)>0){
echo '<div class="form"><table style="border-collapse: collapse;" align="center">
  <tr>
    <th class="tbl2">Name</th>
    <th class="tbl2">URL</th>
    <th class="tbl2">Device</th>
    <th class="tbl2">Country</th>
    <th class="tbl2">Status</th>

  </tr>';
 while($show=mysql_fetch_array($adver)){
  echo '
  <tr>
    <td class="tbl"><a href="/adv/'.$show["id"].'">'.$show["name"].'</a></b></td>
    <td class="tbl">'.$show["url"].'</td>
    <td class="tbl">'.$show["device"].'</td>
    <td class="tbl">'.$show["country"].'</td>
    <td class="tbl">'.$show["status"].'</td>

  </tr>';
}
echo '</table></div>';
}
else {

echo '<div class="ad">There is no Ad created by you!</div>';

}

echo '<div class="ad"><a href="/newad">Create new Ad</a></div>';

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';

}

else {


header('Location:/');

}

?>

