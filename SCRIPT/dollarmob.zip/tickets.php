<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Support tickets");

if($userlog==1){

 echo '<div class="title">Support tickets</div>';

  $uid=dump_udata("id");
  
  $ticket=mysql_query("SELECT * FROM tickets WHERE userid='$uid'");

  if(mysql_num_rows($ticket)>0){
     
     while($tickets=mysql_fetch_array($ticket)){
      $tid=$tickets["id"];
      $replyd=mysql_fetch_array(mysql_query("SELECT * FROM treplys WHERE tid=$tid"));

         echo '<div class="ad"><a href="/ticket/'.$tickets["id"].'"><b>'.$tickets["title"].'</b></a><br/>Created: '.$tickets["time"].'. Status: ('.$tickets["status"].' at '.$replyd["date"].')</div>';
         }

    }
   else {

    echo '<div class="ad">There is no support ticket created by you!</div>';
  }

 echo '<div class="ad"><a href="/newticket">Open new ticket</a></div>';

  echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
 
 include 'foot.php';

 }

 else {

 header('Location:/');
 }

?>
  