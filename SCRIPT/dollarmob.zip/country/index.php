<?php
header('Location:/');
?>