<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Pause Ads");

if($userlog==1){

echo '<div class="title">Pause Ad</div>';
$site=formget("id");

$uid=dump_udata("id");

$chsite=mysql_query("SELECT * FROM advertises WHERE userid='$uid' AND id='$site'");

if(mysql_num_rows($chsite)>0){
  

      $delsite=mysql_query("UPDATE advertises SET status='Paused' WHERE id='$site'");
      if($delsite){
        echo '<div class="success">Ad Paused successfully! <a href="/advertise">Continue</a></div>';
      }
      else {
        echo 'unk';
      }

}
else {
  echo 'As I know you dont own this.';
  }
  echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/advertise">My Ads</a></div>';
  
 include 'foot.php';

}
else {
 header('Location:/');
  }

?>
  

     