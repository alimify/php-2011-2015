<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Publisher");

echo '<div class="title">Publishers:</div>';

echo '<div class="form"><b>Discover our world class mobile advertising platform</b><br/>


    * Register for FREE
    <br/>* Start earning in few minutes.
    <br/>* Show most relevant ads only (Filter Ad).
    <br/>* Fast and easy to integrate.
    <br/>* Comprehensive reporting.
    <br/>* Support various programming languages.
    <br/>* Support various ad format.
    <br/>* Online support.
    <br/>* Show branded and trusted ads.
    <br/>* Monitor site traffic from your mobile.

<br/><a href="/user/registration">Start Earning Now!</a></div>';


echo '<div class="ad"><img src="/home.png"/> <a href="/">HOME</a></div>';
include 'foot.php';

?>
