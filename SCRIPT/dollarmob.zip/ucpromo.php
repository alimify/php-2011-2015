<?php  

//Adsfresh

 include "db.php";
 include "functions.php";

headtag("$SiteName - About UC Promote");


echo '<div class="title"><b>Earn Money From Ucweb Browser Promotion</b></div>
<div class="form">We will help you to earn money from ucweb browser.<br/><b>Rules For Earning:-</b><br/>
     <ol>
            <li><b>Notice- </b>You Must <b>Add your Site</b> On Publisher Panel And Put Ad Code On Your Site.If We <b>Not Find Our Adcode</b> On Your Site Your Request Will Be <b>Rejected</b></li>
            <li>If you have <b>Adult Site or Toplist</b> then you can use this service, We donot allow non adult site,</li>
            <li>We will give you <b>0.12$/install</b> on per valid install on ucweb</li>
            <li><b>Payment-</b>Your payment will be paid to your bank or via recharge.</li>
            <li><b>Report-</b>We will give your daily installation report on our control panel.</li>
            <li><b>Report-</b>Minimum Payout is just 1$ , You can request your payment any time.</li>
        </ol>
    <p><br/>
    Payment-We will transfer your ucweb balance to your main balance between 1-20th of earch month.<br/><br/>
  <a href="/user/registration"><b>Register Now !</b></a></div>

';
include 'foot.php';


?>
