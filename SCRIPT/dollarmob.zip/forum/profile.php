<?php include "../inc/def.php"; ?>
<?php include "../inc/usrchk.php";
?>
<?php include "../inc/header.php"; ?>
<link rel="shortcut icon" href="../icon.png" /><link rel="stylesheet" type="text/css" href="../xtremestyle/xtremeitech.css"/>
<div class="lwt" align="center">Support Forum</div>
<?php
$user = secureget('user');
$hammad = mysql_query("SELECT * FROM users WHERE user='$user'");
$khan = mysql_fetch_array($hammad);

$getclk = mysql_query('SELECT * FROM clicks WHERE uid="'.$khan['id'].'"');
$clk = mysql_num_rows($getclk);

$getimp = mysql_query('SELECT * FROM imp WHERE uid="'.$khan['id'].'"');
$imp = mysql_num_rows($getimp);

$getforum = mysql_query('SELECT * FROM forum_question, forum_answer WHERE id="$id"');
$forum = mysql_num_rows($getforum);

echo '<div class="line" align="center">'.$khan['user'].' Info</div>';
echo '<div class="lwt">- Nick : '.$khan['user'].'</div>';
echo '<div class="lwt">- Points : '.$khan['point'].'</div>';
echo '<div class="lwt">- Balance : $'.$khan['bal'].'</div>';
echo '<div class="lwt">- eMail : '.$khan['mail'].'</div>';
echo '<div class="lwt">- Register On : '.$khan['regon'].'</div>';
echo '<div class="lwt">- Login On : '.$khan['laston'].'</div>';

include "../inc/footer.php";
?>
