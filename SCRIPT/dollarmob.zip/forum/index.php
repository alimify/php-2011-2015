<?php include "../db.php"; ?>
<?php include "../functions.php";
?>
<div class="lwt" align="center">Support Forum</div>
<?php if($guest==0) { echo "<div class='line' align='center'><a href='create_topic.php'><b><font color=white>New Thread</b></font></a></div>"; } else { echo "<div class='prob' align='center'>Login/Register to Post Thread & Reply</div>"; }  ?>
<?php
$sql="SELECT * FROM forum_question ORDER BY id DESC";
// OREDER BY id DESC is order result by descending
$result=mysql_query($sql);
?>
<?php
while($rows=mysql_fetch_array($result)){ // Start looping table row
?>
<br/><div class="ln"><br/>
<b><? echo $rows['name']; ?></b><br/> - At : <? echo $rows['datetime']; ?><br/> <a href="view_topic.php?id=<? echo $rows['id']; ?>">Comments <? echo $rows['reply']; ?> </a><br/></b></div><br/>
<?php
// Exit looping and close connection
}
mysql_close();
?>
<?php include "../foot.php"; ?>
