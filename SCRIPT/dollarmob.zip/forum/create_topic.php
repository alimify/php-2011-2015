<?php include "../db.php"; ?>
<?php include "../functions.php";

<div class="title" align="center">Support Forum</div>
<div class='line' align ='center'><b>Create Theme</b></div><div class='lwt'><form id="form1" name="form1" method="post" action="add_topic.php">
Forum Name :<br/><input name="topic" type="text" id="topic" size="25" /></div><div class="lwt">Message :<textarea name="detail" cols="25" rows="3" id="detail"></textarea></div><div class="lwt"><input name="name" type="hidden" id="name" value="<?php echo $user ?>" /><input type="submit" name="Submit" value="Submit" />
</form></div>
<?php include "../foot.php"; ?>
