<?php include "../def.php"; ?>
<?php include "../functions.php";
?>
<div class="lwt" align="center">Support Forum</div>
<?php
$id=formget("id");
$sql="SELECT * FROM forum_question WHERE id='$id'";
$result=mysql_query($sql);
$rows=mysql_fetch_array($result);

$avatar="SELECT * FROM users WHERE id='$id'";
$result8=mysql_query($avatar);
$row=mysql_fetch_array($result8);

$avatar = $row['avatar'];
?>

<table class="title" width="98%" border="0" cellspacing="0" cellpadding="0">

<tr>
<td rowspan="2" class="adleft">
<?php if($avatar!='')
{
echo "<img src='$avatar' width='45' height='50' alt='Avatar' />";
}
else
{
echo "<img src='$siteurl/pics/avatar.jpg' width='45' height='50' alt='Guest'>";
}  ?> </td> <td>
 <?php echo $rows['name']; ?>
</td>   <td class="adright">
 <?php echo $rows['datetime']; ?>

<br/>
<div align='right'>Views : <?php echo $rows['view']; ?><br/>Replies : <?php echo $rows['reply']; ?>
</td>
</tr>
</table><div class="ad"> <?php echo $rows['detail']; ?></div>
<div class="line">Replies</div><div class="lwt"><?php
$sql2="SELECT * FROM forum_answer WHERE question_id='$id'";
$result2=mysql_query($sql2);
while($rows=mysql_fetch_array($result2)) { ?>

<table width="98%" border="0" cellspacing="0" cellpadding="0">

<tr>
<td rowspan="2" class="adright"><div class="ln">
<?php if($avatar!='')
{
echo "<img src='$avatar' width='45' height='50' alt='Avatar' />";
}
else
{
echo "<img src='$siteurl/pics/avatar.jpg' width='45' height='50' alt='Guest'>";
}  ?>
</td>

<td class="lwt"><strong><a href="profile.php?user=<?php echo $rows['a_name']; ?>"><?php echo $rows['a_name']; ?></a></strong><br/><? echo $rows['a_datetime']; ?>
</td>
</tr>
</table>
</div><div class='lwt'><?php echo $rows['a_answer'];?></div> <br/>
<?php } $sql3="SELECT view FROM forum_question WHERE id='$id'"; $result3=mysql_query($sql3); $rows=mysql_fetch_array($result3);
$view=$rows['view'];
if(empty($view)){$view=1;
$sql4="INSERT INTO forum_question(view) VALUES('$view') WHERE id='$id'";
$result4=mysql_query($sql4); }
$addview=$view+1;
$sql5="update forum_question set view='$addview' WHERE id='$id'";
$result5=mysql_query($sql5); mysql_close(); ?><br/>
<?php if($guest==0) {  ?><div class="line">Reply Answers</div> <div class='lwt'><form name="form1" method="post" action="add_answer.php"><input name="a_name" type="hidden" id="a_name" value="<?php echo $user ?>">
<textarea name="a_answer" cols="25" rows="3" id="a_answer"></textarea></div><div class="lwt">
<input name="id" type="hidden" value="<?php echo $id; ?>"><input type="submit" name="Submit" value="Comment"> </form></div>
<?php } include "../foot.php"; ?>
<html>
<body style="background-color:#f7f7f7;">

</body>
</html>
