<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include '../db.php';
include '../functions.php';


$uid=formget("uid");
$sid=formget("sid");



if(mysql_num_rows(mysql_query("SELECT * FROM sites WHERE userid='$uid' AND id='$sid'"))<1){


echo 'document.write(\'Site Not Found!\');';
exit;

}

$siteCh=mysql_fetch_array(mysql_query("SELECT * FROM sites WHERE id='$sid'"));

if($siteCh["status"]=='Pending'){

echo 'document.write(\'Site is Pending!\');';
exit;
}
if($siteCh["status"]=='BLOCKED'){

echo 'document.write(\'Site is Rejected!\');';
exit;
}




//copycat
$ip = '';
$ua = urlencode($_SERVER["HTTP_USER_AGENT"]);
$browser = '';

// Extract full IP info (including Opera Mini)
if (empty($ip)) {
$keyname_ip_arr = array(
'HTTP_X_FORWARDED_FOR',
'HTTP_REMOTE_ADDR_REAL',
'HTTP_X_CLIENT_IP',
'HTTP_CLIENT_IP',
'REMOTE_ADDR'
);

foreach ($keyname_ip_arr as $keyname_ip) {
if (!empty($_SERVER[$keyname_ip])) {
// Split string into tokens using commas as delimiters. If no commas are present, the string
// appear in the resulting array as a single token.
$tokens = explode(',', $_SERVER[$keyname_ip]);
$tokensLength = count($tokens);
if ($tokens !== false) {
// Check for valid IP addresses from the last token to the first.
for ($i = 0; $i < $tokensLength; $i++) {
$token = trim($tokens[$i]);
if (empty($token)) {
continue;
}
// Convert the IP Address into an integer value. If false is returned, the token is not a valid IP Address
$ip_l = ip2long($token);
if ($ip_l === false) {
continue;
}

// Begin Private/Reserved IPV4 ranges address checking. This code block is optional
// The following long values are converted private IP ranges
if (($ip_l >= 0 && $ip_l <= 17301503)
|| ($ip_l >= 50331648 && $ip_l <= 83886079)
|| ($ip_l >= 100663296 && $ip_l <= 134217727)
|| ($ip_l >= 135856128 && $ip_l <= 167772159)
|| ($ip_l >= 167772160 && $ip_l <= 184549375)
|| ($ip_l >= 1677721600 && $ip_l <= 1694498815)
|| ($ip_l >= 1711276032 && $ip_l <= 1728053247)
|| ($ip_l >= 1744830464 && $ip_l <= 1761607679)
|| ($ip_l >= 2130706432 && $ip_l <= 2147483647)
|| ($ip_l >= 2432696320 && $ip_l <= 2432761855)
|| ($ip_l >= 2734686208 && $ip_l <= 2734751743)
|| ($ip_l >= 2851995648 && $ip_l <= 2852061183)
|| ($ip_l >= 2885681152 && $ip_l <= 2894069759)
|| ($ip_l >= 3204448256 && $ip_l <= 3221291007)
|| ($ip_l >= 3226992640 && $ip_l <= 3227058175)
|| ($ip_l >= 3227844608 && $ip_l <= 3228762111)
|| ($ip_l >= 3230400512 && $ip_l <= 3230793727)
|| ($ip_l >= 3232235520 && $ip_l <= 3232956415)
|| ($ip_l >= 3258384384 && $ip_l <= 3258449919)
|| ($ip_l >= 3323002880 && $ip_l <= 3323265023)
|| ($ip_l >= 3758096384 && $ip_l <= 4026531839)
|| ($ip_l >= 1681915904 && $ip_l <= 1686110207)
) {
continue;
}
// End Private/Reserved IPV4 ranges address checking.
$ip = urlencode(long2ip($ip_l));
break;
}
}
if (!empty($ip)) {
break;
}
}
}
}

// extract full UA info


// extract browser info
$browser = '';
if ((!empty($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])
|| !empty($_SERVER['HTTP_X_OPERAMINI_PHONE'])
|| !empty($_SERVER['HTTP_X_MXIT_PROFILE']))
&& strpos($_SERVER['HTTP_USER_AGENT'], 'OperaMini') !== false
) {
$browser = 'OPERAMINI';
} else if (!empty($_SERVER['HTTP_X_BOLT_PHONE_UA'])
&& strpos($_SERVER['HTTP_USER_AGENT'], 'Bolt') !== false
) {
$browser = 'BOLT';
} else if (strpos($_SERVER['HTTP_USER_AGENT'], 'UCWEB') !== false
|| strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false
|| strpos($_SERVER['HTTP_USER_AGENT'], 'UC Browser') !== false
) {
$browser = 'UCWEB';
} else if (strpos($_SERVER['HTTP_USER_AGENT'], 'OviBrowser') !== false
|| strpos($_SERVER['HTTP_HOST'], 'browser.ovi.com') !== false
) {
$browser = 'OVI';
}
//end cat

if($ua==""){
echo 'document.write(\'User-Agent is ghost!\');';
exit;
}

$ref=$_SERVER['HTTP_REFERER'];
$pc_browser=0;
$agentt = $_SERVER['HTTP_USER_AGENT'];

if (preg_match("/window/i", $agentt)) {
$pc_browser++;
}

if (preg_match("/mac/i", $agentt)) {
$pc_browser++;
}

if (preg_match("/microsoft/i", $agentt)) {
$pc_browser++;
}

if (preg_match("/linux/i", $agentt)) {
$pc_browser++;
}


$pr='<a href="http://click.dollarmob.com/?pu='.base64_encode("http://c.mobpartner.mobi/?pool=45705").'&uid='.base64_encode($uid).'&sid='.base64_encode($sid).'&uip='.base64_encode($ip).'&uua='.base64_encode($ua).'&ubrowser='.base64_encode($browser).'&ureferer='.base64_encode($ref).'&utype='.base64_encode("MobPartner").'"><img src="http://r.mobpartner.mobi/?pool=45705" alt="AdsGem Ads"/></a>';




$date=date("d-m-Y");
$chimp=mysql_query("SELECT * FROM imp WHERE uid='$uid' AND date='$date'");
$chimpc=mysql_fetch_array($chimp);
if(mysql_num_rows($chimp)>0){
$newimp=($chimpc["imp"]+1);
mysql_query("UPDATE imp SET imp='$newimp' WHERE uid='$uid' AND date='$date'");
}
else {
mysql_query("INSERT INTO imp (uid,imp,date) VALUES ('$uid',1,'$date')");
}

echo 'document.write(\''.$pr.'\');';

header('Content-type:application/js');
?>