<?php
if(!function_exists("show_wapboost_ads"))
{
// Do not change this code without prior permission from wapboost.com
function show_wapboost_ads(){
$st=microtime(true);
$uid='32980';  // your wapboost account id
$site_id='8958';  // your wapboost site id
$mode='live'; //use 'test' for test mode
$type=3;  // 1 for text only; 2 for image only; 3 for both image and text (recommended)

$params = array();
$ignore = array('HTTP_PRAGMA' => true);
foreach ($_SERVER as $k => $v) {
if ((substr($k, 0, 4) == 'HTTP'||$k == 'REMOTE_ADDR' || $k == 'REQUEST_URI') && empty($ignore[$k]) && isset($v)) {
$params[] = urlencode($k) . '=' . urlencode($v);
}
}
$getparams = implode('&', $params);

$wapboost_adurl="http://wapboost.com/adv/?uid=$uid&mode=$mode&site_id=$site_id&type=$type&$getparams";
$ch = curl_init();
$request_timeout = 5; // 5 seconds timeout
curl_setopt($ch, CURLOPT_URL, $wapboost_adurl);
curl_setopt($ch, CURLOPT_TIMEOUT, $request_timeout);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $request_timeout);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$wapboost_adcontents = curl_exec($ch);
$getserver= curl_getinfo($ch);
curl_close($ch);
if($getserver["http_code"]==200) {
$wapboost_adcontents=str_replace("<time>", (microtime(true)-$st), $wapboost_adcontents);    
return $wapboost_adcontents; }
}
}

?>
<?php
// Use this function to print Ads
// Do not call this function more than 2 times
// or the impressions and clicks will be counted as non-genuine
echo show_wapboost_ads();

?>	
	
