<?/*
## WapDollar.In Php Ad Code
## Version: v1.4
## Updated: 02/01/2013 
## Creater: Suraj Kumar
*/


//Do not change anything in this code if you will change without any given instruction then your account may be blocked.
//Use this code in only non adult site or non adult toplist else your account will be blocked


    $keyname_ip_arr = array('HTTP_X_FORWARDED_FOR', 'HTTP_REMOTE_ADDR_REAL', 'HTTP_CLIENT_IP', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'); 
    foreach ($keyname_ip_arr as $keyname_ip) { 
        if (!empty($_SERVER[$keyname_ip])) { 
            $ip = $_SERVER[$keyname_ip]; 
            break; 
        } 
    } 
    if (strstr($ip, ',')) {
        $ips = explode(',', $ip);
         if(substr($ips[0], 1, 3)=='10.'&&strlen($ips[1])>5)
            $ip = trim($ips[1]);
        else $ip = trim($ips[0]);
    } 
    if(!preg_match("^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}^", $ip)) $ip = $_SERVER["REMOTE_ADDR"]; 
  

 
  $keyname_ua_arr = array('HTTP_X_DEVICE_USER_AGENT', 'HTTP_X_OPERAMINI_PHONE_UA', 'HTTP_X_BOLT_PHONE_UA', 'HTTP_X_MOBILE_UA', 'HTTP_USER_AGENT');
foreach ($keyname_ua_arr as $keyname_ua) {
  if (isset($_SERVER[$keyname_ua]) && !empty($_SERVER[$keyname_ua])) {
    $ua = rawurlencode($_SERVER[$keyname_ua]);
  
  }
}

     

$sua = rawurlencode($_SERVER['HTTP_USER_AGENT']);
$site=rawurlencode("http://". $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI']);
$adult="no";
$freead="yes";  // change it to "no" if you don't want to show free ads in your site
$key="nta3y3skte";
$url='http://ad.wapdollar.in/phpwap.php?ip='.$ip.'&key='.$key.'&uag='.$ua.'&site='.$site.'&adult='.$adult.'&sua='.$sua.'&freead='.$freead.'';

$ch = curl_init();
$request_timeout = 5; // 5 seconds timeout
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_TIMEOUT, $request_timeout);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $request_timeout);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$page = curl_exec($ch);
$getserver= curl_getinfo($ch);
curl_close($ch);
 if($getserver["http_code"]==200) {

$str=array("<a href=\"","\">","</a>","<img src=\"http://file.wapdollar.in/image/adv/0d92ccd5cc543d75326b1cf55edb97be.jpg\" />","<br /><font color=\"red\"><b>Click Here</b></font>");
$page = str_replace($str,"",$page);
header('Location:'.$page.'');
}
  
?>