<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Edit Advertise");

if($userlog==1){

echo '<div class="title">Edit Advertise</div>';
$site=formget("id");

$uid=dump_udata("id");

$chsite=mysql_query("SELECT * FROM advertises WHERE userid='$uid' AND id='$site'");

if(mysql_num_rows($chsite)>0){

  if(isset($_POST['title']) AND isset($_POST['url']) AND isset($_POST['type']) AND isset($_POST['device']) AND isset($_POST['country'])){
     
     
    $name=formpost("title");
    $url=formpost("url");
    $url=strtolower($url);
    $url=str_replace('http://',null,$url);
    $type=formpost("type");
    $device=formpost("device");
    $country=formpost("country");

    
    $errors=array();

    if(!preg_match('/([a-z0-9\.-])\.([a-z0-9\.-])/',$url)){
       $errors[]='Site url is not valid!';
     }

    if(strlen($name)<1){
      $errors[]='Site name cannot be empty!';
     }

   if(empty($errors)){
      $url='http://'.$url.'';
      $edsite=mysql_query("UPDATE advertises SET name='$name',url='$url',type='$type',device='$device',country='$country',status='PENDING',cset='no',dset='no' WHERE userid='$uid' AND id='$site'");

      if($edsite){
         echo '<div class="success">Advertise edited successfully! <a href="/advertise">Continue</a></div>';
       }
       else {
          echo 'unknoen err';
        }

     }
     else {
       dump_error($errors);
     }
 
     }
   $ssite=mysql_fetch_array($chsite);
  echo '<div class="form"><form method="post">Ad name/banner url: (300x40px)<br/><input type="text" name="title" value="'.$ssite["name"].'"/><br/>Ad url:<br/><input type="text" name="url" value="'.$ssite["url"].'"/><br/>Type:<br/><select name="type"><option value="text">Text</option><option value="banner">Banner</option></select><br/>Device:<br/>Device names with commas or spaces or dots. like Android, Java. 
[NB: Do nothing  to select all device]<br/><textarea name="device"></textarea><br/>Country:<br/>Country names with commas or spaces or dots. like BD, IN, US. 
[NB: Do nothing to select all country]<br/><textarea name="country"></textarea><br/><input type="submit" value="Edit"/></form></div>';

 }
 else {
   echo '<div class="error">You do not own this adv!</div>';
  }

 echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/advertise">My Ads</a></div>';
  
 include 'foot.php';
}

else {

header('Location:/');
}
?>