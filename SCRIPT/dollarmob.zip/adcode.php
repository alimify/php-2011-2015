<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Adcodes");

if($userlog==1){

echo '<div class="title">Adcode</div>';
$site=formget("id");

$uid=dump_udata("id");

$chsite=mysql_query("SELECT * FROM sites WHERE userid='$uid' AND id='$site'");

if(mysql_num_rows($chsite)>0){




echo '<b>Note</b><span style="color:#FB0B0B"></br>*For Adult wapsite please use Javascript Code.<br/>*For nonAdult wapsite please use HTML Banner Code.<br/>*For blog/Website please use 320x280 Banner or 728x90 Banner Code.</span><div class="form"><b>Javascript Code(Adult):</b><br/><textarea><script type="text/javascript" src="http://show.dollarmob.com/?uid='.$uid.'&sid='.$site.'"></script></textarea><br/><b>HTML Banner Code(nonAdult):</b><br/><textarea><a href="http://show.dollarmob.com/html.php?uid='.$uid.'&sid='.$site.'"><img src="http://dollarmob.com/adtools/banner.php" alt=""/></a></textarea><br/><b>HTML Text Code:</b><br/><textarea><a href="http://show.dollarmob.com/html.php?uid='.$uid.'&sid='.$site.'">Top Mobile Downloads</a></textarea><br/><b>(320x280)Banner Code:</b><br/><textarea><a href="http://show.dollarmob.com/html.php?uid='.$uid.'&sid='.$site.'"><img src="http://dollarmob.com/adtools/banner2.php" alt=""/></a></textarea><br/><b>(728x90)Banner Code:</b><br/><textarea><a href="http://show.dollarmob.com/html.php?uid='.$uid.'&sid='.$site.'"><img src="http://dollarmob.com/adtools/banner3.php" alt=""/></a></textarea></div>';

}
else {
echo '<div class="error">You do not own this site!</div>';
}

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/sites">My Sites</a></div>';

include 'foot.php';
}
else {

header('Location:/');
}
?>

