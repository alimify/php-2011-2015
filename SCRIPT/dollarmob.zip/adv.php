<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Advertise details");

if($userlog==1){

 $aid=formget("id");
 $uid=dump_udata("id");

 echo '<div class="title">Advertise Details:</div>';

 $chadv=mysql_query("SELECT * FROM advertises WHERE id='$aid' AND userid='$uid'");
 if(mysql_num_rows($chadv)>0){
   $advdata=mysql_fetch_array($chadv);
   echo '<div class="form"><b>Adv Name / Banner URL:</b> '.$advdata["name"].'<br/><b>Adv URL:</b> '.$advdata["url"].'<br/><b>Status:</b> '.$advdata["status"].'<br/><b>Device:</b> '.$advdata["device"].'<br/><b>Country:</b> '.$advdata["country"].'<br/><br/><b>ACTIONS:</b><br/>- <a href="/edadv/'.$aid.'">Edit Ad</a><br/>- <a href="/paadv/'.$aid.'">Pause Ad</a><br/>- <a href="/delad/'.$aid.'">Delete Ad</a><br/>- <a href="/adstat/'.$aid.'-">Ad Stats</a></div>';
 }
 else {
  echo '<div class="ad">No adv found!</div>';
 }
 echo '<div class="ad"><img src="/home.png"/> <a href="/advertise">Advertises</a></div>';
 include 'foot.php';
 }
 else {
  header('Location:login.php');
 }
 ?>
  
  