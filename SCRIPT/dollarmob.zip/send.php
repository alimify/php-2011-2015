<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Transfer Money");

if($userlog==1){

$act=formget("act");
$id=formget("id");
$uid=dump_udata("id");
$user=dump_udata("firstname");
$hammad = mysql_query("SELECT * FROM userdata WHERE firstname='$user'");
$khan = mysql_fetch_array($hammad);
$bal = $khan['pubalance'];
$pnt = $khan['point'];
$uid = $khan['id'];
$time = date("F j Y"); 


if($act=="send")
{
    echo '<div class="title">Transfer Money To Another User Account
</div>

<div class="success" align="center">You have <font color="red"><b>'.$bal.'</b></font> $ in your publisher account.</div>';

echo '<div class="form"><form action="/send/sent" method="post">
Enter (Reciever) user name:<br/><input type="text" name="usert" maxlength="12" value=""/><br/>Enter amount( In <b id=num>USD</b>):<br/><input type="number" name="amount" maxlength="5" value=""/>  <br/><input type="submit" value="Send Money"></div>';

echo '
<div class="title">
Last 10 Transactions
</div>';

$query = " SELECT * FROM send WHERE uid='$uid' order by id desc LIMIT 10";
$result = mysql_query($query) or die('Error, query failed');

// print the random numbers
while($row = mysql_fetch_array($result))
{
   echo '<div class="ad"><em>
<p><b>Date:</b> '.$row['time'].'<br/><b id="num">$'.$row['bal'].' USD</b>  Sent to <b color="red">'.$row['user'].'</b><br/></p></em></div>';

}

$set= " SELECT * FROM send WHERE user='$user' order by id desc LIMIT 10";
$rec = mysql_query($set) or die('Error, query failed');

// print the random numbers
while($rows = mysql_fetch_array($rec))
{
   echo '<div class="ad"><em>
<p><b>Date:</b> '.$rows['time'].'<br/><b id="num">$'.$rows['bal'].' USD</b>  Received from <b color="red">'.$rows['user1'].'</b><br/></p></em></div>';

}

 echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
include 'foot.php';
}

else if($act=="sent")
{
        echo '<div class="title">Tranfering Balance</div>';
$mymoney=formpost("amount");

$usr1=formpost("usert");
$amt=formpost("amount");

$sen = mysql_query("SELECT * FROM userdata WHERE firstname='$usr1'");
$riya = mysql_fetch_array($sen);
$bals = $riya['pubalance'];
$newm = $amt+$bals;
$setb = $bal-$amt;
if(mysql_num_rows($sen)==0) {
die("<div class='ok'>NO such User Found</div>");

}
if($user==$usr1)
{
        
    echo '<div class="error">You Cant Transfer Money To Your Own Account !</div>';
    
}

else
if($mymoney>$khan['pubalance'])
{
    
    echo '<div class="error">Dont Have Enough Money To Transfer</div>';
   
}

else if($mymoney<1)
{
    
    echo '<div class="error">Minimum 1 $  For Transfer To Other User</div>';
    
}
else 
if($mymoney<=0)
{
        
    echo '<div class="error">Dont Have Enough Money To Transfer</div>';
    
}

else {

echo '<div class="success"><b>'.$amt.'$ Transfered To '.$usr1.'</b> Your New Balance <font color="green"><b>'.$setb.'$</b></font></div>';

mysql_query("UPDATE userdata SET pubalance='$newm' WHERE firstname = '$usr1'");

mysql_query("UPDATE userdata SET pubalance='$setb' WHERE firstname = '$user'");

$do = mysql_query("INSERT INTO send (uid,bal,user,time,user1) VALUES ('$uid','$amt','$usr1','$time','$user')") or die("Unable to Process ".mysql_error());
}
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include "foot.php";

}
}
else
{ header('Location:/');
}
?>