<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Open new support ticket");

echo '<div class="title">Open new ticket</div>';
if($userlog==1){

 $uid=dump_udata("id");
 $date=date("h:i:s A , l , F d , Y");

 if(isset($_POST['title']) AND isset($_POST['msg']) AND isset($_POST['captcha'])){
    
    $title=formpost("title");
    $msg=formpost("msg");
    $captcha=formpost("captcha");

    
    $errors=array();

    if(strlen($title)>24){
      $errors[]='Support ticket title must be within 24 characters!';
     }
     if(strlen($title)<1){
       $errors[]='Title cannot be empty!';
      }
      if(strlen($msg)<1){
       $errors[]='Message cannot be empty!';
      }
     if($_SESSION['captcha']!=$captcha){
       $errors[]='Captcha was wrong!';
      }
    
     if(empty($errors)){
      
       $cst=mysql_query("INSERT INTO tickets (userid,title,msg,time,status) VALUES ('$uid','$title','$msg','$date','Waiting for Admin\'s reply')");
       if($cst){
         echo '<div class="success">Your ticket has been created! <a href="/support-ticket">Continue</a></div>';
        }
        else {
         echo 'unk';
        }

      }
      else {
  
       dump_error($errors);
      }

    }

  echo '<div class="form"><form method="post">Ticket title:<br/><input type="text" name="title"/><br/>Message:<br/><textarea name="msg"></textarea><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Open ticket"/></form></div>';


 
  echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/support-ticket">Support Tickets</a></div>';
 
 include 'foot.php';

 }

 else {

 header('Location:/');
 }

?>
  
       


    
 