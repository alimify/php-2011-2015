<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Buy balance");


if($userlog==1){

$uid=dump_udata("id");

echo '<div class="title">Buy Balance</div>';

$method=formget("method");

if($method=='moneybookers'){

if(isset($_POST['email']) AND isset($_POST['amount']) AND isset($_POST['captcha'])){

 $email=formpost("email");
 $amount=formpost("amount");
 $captcha=formpost("captcha");

 $errors=array();
 
 if(strlen($email)<1){
   $errors[]='Email cannot be empty!';
   }

 if(strlen($amount)<1){
   $errors[]='Amount cannot be empty!';
   }

 if($_SESSION['captcha']!=$captcha){
   $errors[]='Captcha code was wrong!';
   }

 if(empty($errors)){
  
   $doit=mysql_query("INSERT INTO adinvoice (userid,method,amount,email,status) VALUES ('$uid','moneybookers','$amount','$email','Pending')");

   if($doit){
     echo '<div class="success">Your invoice has created. Please send '.$amount.'$ to <b>support@dollarmob.com</b> and our Admins will check it and will add the amount to your balance.</div>';
    }

  }
  else {
   dump_error($errors);
  }
}

echo '<div class="form"><form method="post">Moneybookers Email:<br/><input type="text" name="email"><br/>Amount:<br/><input type="text" name="amount"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Create Invoice"/></form></div>';

}

//end moneybookers

if($method=='paypal'){

if(isset($_POST['email']) AND isset($_POST['amount']) AND isset($_POST['captcha'])){

 $email=formpost("email");
 $amount=formpost("amount");
 $captcha=formpost("captcha");

 $errors=array();
 
 if(strlen($email)<1){
   $errors[]='Email cannot be empty!';
   }

 if(strlen($amount)<1){
   $errors[]='Amount cannot be empty!';
   }

 if($_SESSION['captcha']!=$captcha){
   $errors[]='Captcha code was wrong!';
   }

 if(empty($errors)){
  
   $doit=mysql_query("INSERT INTO adinvoice (userid,method,amount,email,status) VALUES ('$uid','paypal','$amount','$email','Pending')");

   if($doit){
     echo '<div class="success">Your invoice has created. Please send '.$amount.'$ to <b>kohitoorindiaco@gmail.com</b> and our Admins will check it and will add the amount to your balance.</div>';
    }

  }
  else {
   dump_error($errors);
  }
}

echo '<div class="form"><form method="post">Paypal Email:<br/><input type="text" name="email"><br/>Amount:<br/><input type="text" name="amount"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Create Invoice"/></form></div>';

}

//end paypal

if($method=='bkash'){

if(isset($_POST['number']) AND isset($_POST['amount']) AND isset($_POST['captcha'])){

 $email=formpost("number");
 $amount=formpost("amount");
 $captcha=formpost("captcha");

 $errors=array();
 
 if(strlen($email)<1){
   $errors[]='Number cannot be empty!';
   }

 if(strlen($amount)<1){
   $errors[]='Amount cannot be empty!';
   }

 if($_SESSION['captcha']!=$captcha){
   $errors[]='Captcha code was wrong!';
   }

 if(empty($errors)){
  
   $doit=mysql_query("INSERT INTO adinvoice (userid,method,amount,email,status) VALUES ('$uid','bkash','$amount','$email','Pending')");

   if($doit){
     echo '<div class="success">Your invoice has created. Please send '.$amount.'$ to <b>01832610786</b> and our Admins will check it and will add the amount to your balance.</div>';
    }

  }
  else {
   dump_error($errors);
  }
}

echo '<div class="form"><form method="post">BKash Number:<br/><input type="text" name="number"><br/>Amount:<br/><input type="text" name="amount"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Create Invoice"/></form></div>';

}

//end BKash

if($method=='airtel'){

if(isset($_POST['email']) AND isset($_POST['amount']) AND isset($_POST['captcha'])){

 $email=formpost("email");
 $amount=formpost("amount");
 $captcha=formpost("captcha");

 $errors=array();
 
 if(strlen($email)<1){
   $errors[]='Account number cannot be empty!';
   }

 if(strlen($amount)<1){
   $errors[]='Amount cannot be empty!';
   }

 if($_SESSION['captcha']!=$captcha){
   $errors[]='Captcha code was wrong!';
   }

 if(empty($errors)){
  
   $doit=mysql_query("INSERT INTO adinvoice (userid,method,amount,email,status) VALUES ('$uid','bank','$amount','$email','Pending')");

   if($doit){
     echo '<div class="success">Your invoice has created. Please send '.$amount.'$ to <b>+919818071048</b> and our Admins will check it and will add the amount to your balance.</div>';
    }

  }
  else {
   dump_error($errors);
  }
}

echo '<div class="form"><form method="post">A/M No:<br/><input type="text" name="email"><br/>Amount:<br/><input type="text" name="amount"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Create Invoice"/></form></div>';

}

//end bank

//end userlog

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';


}
else {

header('Location:/');

}

?>

