<?php

echo file_get_contents('big.jpg');
header('Content-type: image/gif');
header('Content-title: DollarMob');
?>
