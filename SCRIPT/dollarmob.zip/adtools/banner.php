<?php

echo file_get_contents('html.jpg');
header('Content-type: image/gif');
header('Content-title: DollarMob');
?>
