<?php

echo file_get_contents('728 i pic.jpg');
header('Content-type: image/gif');
header('Content-title: DollarMob');
?>
