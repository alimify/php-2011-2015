<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Contact us");

echo '<div class="title">Contact us</div>';


if(isset($_POST['email']) AND isset($_POST['msg']) AND isset($_POST['subject']) AND isset($_POST['captcha'])){

 $eemail=formpost("email");
 $esub=formpost("subject");
 $emsg=formpost("msg");
 $captcha=formpost("captcha");
 $errors=array();

 if(!preg_match('/^([a-zA-Z0-9_.-]+)\@([a-zA-Z0-9_.-]+)\.([a-zA-Z0-9_.-]+)$/', $eemail)){
  $errors[]='Email is not valid!';
 }

 if(strlen($eemail)<1){
  $errors[]='Email left empty!';
 }
 if(strlen($esub)<1){
  $errors[]='Subject left empty!';
 }
 if(strlen($emsg)<1){
  $errors[]='Msg left empty!';
 }
 if($_SESSION['captcha']!=$captcha){
  $errors[]='Cakk';
 }

 if(empty($errors)){


      $to = "support@dollarmob.com";
    $subject = 'DollarMob User support ['.$esub.']';
    $message = 'Dear Administration,
You have a message from '.$eemail.' . Bellow is the message:
[ '.$emsg.' ]';
    $headers = 'From: DollarMob System<'.$eemail.'>' . "\r\n" .
    'Reply-To: '.$eemail.'' . "\r\n" .
    'X-Mailer: Adsgem';

    mail($to, $subject, $message, $headers);
 echo '<div class="success">Email successfully sent. You will be replied within 72 hours. Thank you for contacting!</div>';
}
else {

 dump_error($errors);
}
}
echo '<div class="form"><form method="post">Email: <br/><input type="text" name="email"/><br/>Subject:<br/><input type="text" name="subject"/><br/>Message:<br/><textarea name="msg"></textarea><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the words from image.<br/><input type="text" name="captcha"/><br/><input type="submit" value="Send"/></form></div>';
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a></div>';


include 'foot.php';

?>
   
 
