<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - Add funds");

if($userlog==1){

echo '<div class="title">Add funds</div>';

echo '<div class="form">There are several ways to add funds to your account. Present ways at DollarMob to add funds is given bellow:<br/>
<div class="ad"><table><tr><td><img src="adf.png" alt="-" width="20" height="25"/></td><td><b><a href="/transfer-from-publisher">Transfer From Publisher Bal</a></b><br/><small>You Can Transfer Your Bal From Publisher Bal ('.dump_udata("pubalance").'$)</small></td></tr></table></div>
<div class="ad"><table><tr><td><img src="mb.png" alt="-" width="20" height="25"/></td><td><b><a href="/buy-moneybookers">MoneyBooker (SKRILL)</a></b><br/><small>Add Advertiser Fund From Your Moneybooker Account</small></td></tr></table></div>
<div class="ad"><table><tr><td><img src="paypal.png" alt="-" width="20" height="25"/></td><td><b><a href="/buy-paypal">Paypal </a></b><br/><small>Add Advertiser Fund From Your Paypal Account</small></td></tr></table></div>
<div class="ad"><table><tr><td><img src="bkash-logo.jpg" alt="-" width="20" height="25"/></td><td><b><a href="/buy-bkash">BKASH</a></b><br/><small>Add Advertiser Fund From Your B-KASH Account For BD Users Only.</small></td></tr></table></div>
<div class="ad"><table><tr><td><img src="airtel.png" alt="-" width="20" height="25"/></td><td><b><a href="/buy-airtel">Airtel Money</a></b><br/><small>Add Advertiser Fund From Your Airtel Money Account For Indian Users Only.</small></td></tr></table></div>
</div>';

echo '<div class="ad"><img src="/home.png"> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';

}
else {
header('Location:/');
}
?>
