<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

echo '<div class="foot" align="center"><font color="white"><b>All rights reserved<br/><a href="/"><font color="white">DollarMob.Com</font></a> Pvt. 2014</b></font></div>';

echo '</body></html>';

?>
