<?php include 'db.php';
 include 'functions.php'; 
headtag("$SiteName Forum");
  
echo '<div class="title" align="center">Support Forum</div>';
if($userlog==1) {
$user=dump_udata("firstname");
echo '<div class="form"><form id="form1" name="form1" method="post" action="/add_topic.php">
Create a Topic:<br/><textarea name="detail" id="detail" rows="2"></textarea><input name="name" type="hidden" id="name" value="'.$user.'" /><input type="submit" name="Submit" value="Send" />
</form></div>'; }

$sql="SELECT * FROM forum_question ORDER BY id DESC";
// OREDER BY id DESC is order result by descending
$result=mysql_query($sql);

// how many rows to show per page
$rowsPerPage = 20;
// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}

// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

$sql = " SELECT * FROM forum_question order by id desc  " . 
         " LIMIT $offset, $rowsPerPage ";
$result=mysql_query($sql);



while($rows=mysql_fetch_array($result)){ // Start looping table row

echo '<div class="top"><table width="95%" border="0" cellspacing="0" cellpadding="0">

<tr>
<td align="left">';
 if($avatar!='')
{
echo "<img src='$avatar' width='45' height='50' alt='Avatar' />";
}
else
{
echo "<img src='/web/avatar.jpg' width='45' height='50' alt='Guest'>";
}  echo '</td> <td align="left"><b>
 '.$rows['name'].'</b>
</td>   <td align="right">
  '.$rows['datetime'].'

<br/>';
echo '<div align="right">Views : '.$rows["view"].'<br/>Replies : '.$rows["reply"].'
</td>
</tr>
</table><div class="ar"></div><div class="msg"><b font color="blue"> '.$rows["detail"].'</b></div><b><a href="http://dollarmob.com/view/'.$rows["id"].'">[Comments]</a></b><br/><br/></div>';
} 
if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < 100)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}
// print the navigation link
echo $first . $prev . $nav . $next  ;
mysql_close();
include 'foot.php'; ?>
