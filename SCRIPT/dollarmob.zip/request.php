<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - Request Payout");

if($userlog==1){

echo '<div class="title">Request Payout</div>';
if(dump_udata("pubalance")<1.00){
 echo '<div class="error">Your account balance is '.dump_udata("pubalance").'$! Which is lower than our minimum payment amount (1$). Please earn more and then request payout!</div>';
 }
else {
$uid=dump_udata("id");
if(isset($_POST["amount"]) AND isset($_POST["method"]) AND isset($_POST["via"]) AND isset($_POST["captcha"]) AND isset($_POST["name"])){

$amount=formpost("amount");
$method=formpost("method");
$via=formpost("via");
$captcha=formpost("captcha");
$name=formpost("name");
$errors=array();

if(!is_numeric($amount)){
  $errors[]='Amount must be a numeric value!';
 }


if(strlen($amount)<1){
  $errors[]='Amount cannot be empty!';
 }

if(strlen($method)<1){
  $errors[]='Payment method cannot be empty!';
 }

if($_SESSION["captcha"]!=$captcha){
$errors[]='Captcha Code was wrong!';
}
if(strlen($via)<1){
  $errors[]='Email/Number cannot be empty!';
 }

if($amount>dump_udata("pubalance")){
  $errors[]='Amount is bigger than account balance!';
}

if(empty($errors)){
  $date=date("l , F d , Y"); 
  $doit=mysql_query("INSERT INTO invoice (userid,amount,method,via,status,time,name) VALUES ('$uid','$amount','$method','$via','PENDING','$date','$name')");
  $newbal=(dump_udata("pubalance")-$amount);
  $minusb=mysql_query("UPDATE userdata SET pubalance='$newbal' WHERE id='$uid'");
  if($doit AND $minusb){
   echo '<div class="success">Invoice successfully Created and will be paid soon!</div>';
  }
  else {
   echo '<div class="error">Error creating invoice!</div>';
}

}
else {

dump_error($errors);

}
}
echo '<div class="form"><form method="post">Amount (Min. $1.00  Max. As Your Account Bal '.dump_udata("pubalance").'$)<br/><input type="text" name="amount"/><br/>Payment method:<br/><select name="method"><option value="Paypal">Paypal</option><option value="Moneybookers">Moneybookers</option><option value="Bkash">BKash (BD)</option><option value="Airtel Money">Airtel Money</option></select><br/>Name:<br/><input type="text" name="name"/><br/>Email/Mobile/Account Number:<br/><input type="text" name="via"/><br/>Captcha:<br/><img src="/im'.md5(microtime()).'.jpg"/><br/>Input the characters showing in image!<br/><input type="text" name="captcha"/><br/><input type="submit" value="Request"/></form></div>';

}
}
else {

header('Location:/');
}

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
include 'foot.php';

?>