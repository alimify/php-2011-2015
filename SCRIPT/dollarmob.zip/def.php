<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="/favicon.ico" />
<title>'.$headtitle.'</title>
<link rel="stylesheet" type="text/css" href="/web/style.css" />
</head><body><img align="center" src="/web/logo.png" height="90" width="290" alt="Adsfresh" />
<?php include 'db.php'; ?>
<?php
$time = date("d-m-Y");
function secureget($field) {
    $field = $_GET[$field];
    $field = mysql_real_escape_string($field);
    $field = stripcslashes($field);
    return $field;
    }
    
    function secure($field) {
    $field = $_POST[$field];
    $field = mysql_real_escape_string($field);
    $field = stripcslashes($field);
    return $field;
    }
    
    function securecook($field) {
    $field = $_COOKIE[$field];
    $field = mysql_real_escape_string($field);
    $field = stripcslashes($field);
    return $field;
    }

function check($str) {
    $str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
    $str = nl2br($str);
    $str = strtr($str, array (
        chr(0)=> '',
        chr(1)=> '',
        chr(2)=> '',
        chr(3)=> '',
        chr(4)=> '',
        chr(5)=> '',
        chr(6)=> '',
        chr(7)=> '',
        chr(8)=> '',
        chr(9)=> '',
        chr(10)=> '',
        chr(11)=> '',
        chr(12)=> '',
        chr(13)=> '',
        chr(14)=> '',
        chr(15)=> '',
        chr(16)=> '',
        chr(17)=> '',
        chr(18)=> '',
        chr(19)=> '',
        chr(20)=> '',
        chr(21)=> '',
        chr(22)=> '',
        chr(23)=> '',
        chr(24)=> '',
        chr(25)=> '',
        chr(26)=> '',
        chr(27)=> '',
        chr(28)=> '',
        chr(29)=> '',
        chr(30)=> '',
        chr(31)=> ''
    ));

    $str = str_replace("'", "&#39;", $str);
    $str = str_replace('\\', "&#92;", $str);
    $str = str_replace("|", "I", $str);
    $str = str_replace("||", "I", $str);
    $str = str_replace("/\\\$/", "&#36;", $str);
    $str = mysql_real_escape_string($str);
    return $str;
}
?>
