<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/

include 'db.php';
include 'functions.php';

headtag("$SiteName - My Account");

if($userlog==1){

 $uid=dump_udata("id");

echo '<div class="title">My Account</div>';

echo '<div class="form"><b>Personal Info:</b> <br/>
 Full Name: '.ucfirst(dump_udata("lastname")).'<br/>
 Address1: '.dump_udata("address1").'<br/>
 Address2: '.dump_udata("address2").'<br/>
 State: '.ucfirst(dump_udata("state")).'<br/>
 City: '.ucfirst(dump_udata("city")).'<br/>
 Zipcode: '.dump_udata("zipcode").'<br/>
 Country: '.ucfirst(dump_udata("country")).'<br/>
 Mobile: '.dump_udata("mobile").'<br/><a href="/edit_account">Edit Account</a><br/><b>Account Info:</b><br/>
UserName: '.ucfirst(dump_udata("firstname")).'<br/>
 Email: '.dump_udata("email").'<br/>
 Password: ********<br/><a href="/change_password">Change Password</a></div>';

echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

include 'foot.php';


}

else {

header('Location:/');
}
?>



