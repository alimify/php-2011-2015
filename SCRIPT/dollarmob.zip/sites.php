<?php

/************************************

Script : Adnetwork
Website : http://facebook.com/pranto007

Script is created and provided by Pranto (http://facebook.com/pranto007)
**************************************/
include 'db.php';
include 'functions.php';

headtag("$SiteName - My Sites");

if($userlog==1){
$uid=dump_udata("id");

echo '<div class="title">My sites</div>';

$site=mysql_query("SELECT * FROM sites WHERE userid='$uid'");
echo '<div class="form"><table style="border-collapse: collapse;" align="center">
  <tr>
    <th class="tbl2">Name</th>
    <th class="tbl2">URL</th>
    <th class="tbl2">Description</th>
    <th class="tbl2">Status</th>
    <th class="tbl2">Actions</th>
<th class="tbl2">User Id</th>
<th class="tbl2">Site Id</th>

  </tr>';
if(mysql_num_rows($site)>0){
 while($show=mysql_fetch_array($site)){
  echo '
  <tr>
    <td class="tbl"><a href="/viewsite/'.$show["id"].'">'.$show["name"].'</a></b></td>
    <td class="tbl">'.$show["url"].'</td>
    <td class="tbl">'.$show["descr"].'</td>
    <td class="tbl">'.$show["status"].'</td>
    <td class="tbl"><a href="/adcode/'.$show["id"].'">Codes</a></td>
<td class="tbl">'.$uid.'</td>
    <td class="tbl">'.$show["id"].'</td>
  </tr>';
 }
echo '</table></div>';
 }
 else {
  echo '<div class="ad">You have not added any site!</div>';
  }

 echo '<div class="ad"><a href="/newsite">Add new site</a></div>';

 echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';
 
 include 'foot.php';

}

else {

header('Location:/');

}

?>
