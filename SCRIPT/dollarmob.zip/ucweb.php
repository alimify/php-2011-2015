<?php include "db.php"; ?>
<?php include "functions.php";
headtag("$SiteName - UC Promoter");
?> 
<?php
if($userlog==1) {
    
$act = formget('act');
$user=dump_udata("firstname");
$getu = mysql_query("SELECT * FROM userdata WHERE firstname='$user'");
$getu1 = mysql_fetch_array($getu);
$id = $getu1['id'];
$bal = $getu1['pubalance'];

if((isset($_POST['title']))&&(isset($_POST['url']))&&(isset($_POST['cid']))) {

$title=formpost("title");
$url=formpost("url");
$cat=formpost("cid");

if((empty($title))||(empty($url))||(empty($cat))) {
    print "<div id='button'>One ore more required fields were left blank !!</div>";
    die();
}

$do=mysql_query('INSERT INTO ucuser (link, title, cat, user, userid, uclink, ucbal, install)
VALUES ("'.$url.'","'.$title.'","'.$cat.'", "'.$user.'", "0", "none", "0.00", "0")');
if($do){
echo '<div class="success">Your Site Is Submit Done And Waiting For Admin Approval. <a href="http://dollarmob.com/ucweb">Continue</a></div>';
include 'foot.php';
die();
} 
}
if($act=="fresh")
{
$get = mysql_query("SELECT * FROM ucuser WHERE user='$user'") or die();
$getu1 = mysql_fetch_array($get);
$status = $getu1['userid'];

if($status=='1'){
echo '<p>Your Site Is Already Approved, This Action Not Allowed</p>';
include 'foot.php';
die();
}

echo '<div class="ok">submit again ! <img src="/thumb.png" alt=""/> <meta http-equiv="refresh" content="0;url=/ucweb.php"> </div></div>';
mysql_query('DELETE FROM ucuser WHERE user="'.$user.'"');
}

echo '<div class="title">Rules For Earning</div>';
echo '<div class="ad">
      <b>Notice- </b>You Must <b>Add your Site</b> On <a href="http://dollarmob.com/sites">Publisher Panel</a> And Put Ad Code On Your Site.If We <b>Not Find Our Adcode</b> On Your Site Your Request Will Be <b>Rejected</b></br>
     - If you have <b>Adult Site or Toplist</b> then you can use this service, We donot allow non adult site, <br/>
            - We will give you <b>0.12$/install</b> on per valid install on ucweb<br/>
            - <b>Payment-</b>Your payment will be paid to your bank or via recharge.
<br/>
            - <b>Report-</b>We will give your daily installation report on our control panel.<br/>
            - <b>Report-</b>Minimum Payout is just 1$ , You can request your payment any time.<br/>
       
    <p><br/>
    - Payment-We will transfer your ucweb balance to your main balance between 1-20th of each month.<br/>
  
    <font color="red"><b>- We are accepting only adult sites and toplist for ucweb promotion.</b></font><br/>

=> For more details please contact '.$Adminmail.'</p></div>';


$get = mysql_query("SELECT * FROM ucuser WHERE user='$user'") or die();
$hmm = mysql_num_rows($get);

if($hmm>0){
$getu1 = mysql_fetch_array($get);
$url = $getu1['link'];
$title = $getu1['title'];
$uc = $getu1['uclink'];
$status = $getu1['userid'];

if($status=='0')
{
echo '<div class="error">Site Is Pending.... Wait For Approve..</div>';

}
elseif($status=='2'){

echo '<divclass="success">Site Already Registerd In Ucweb Please Submit Another Site -<b><a href="/ucweb.php?act=fresh"><font color=red>Submit Again</font></a></b></div>';
}
else {

echo '<div class="title">Your Promoting Link</div><div class="ad">Site: '.$url.'<br/>Title: '.$title.'<br/>Your Promoting Link: <font color="red"><b><a href="'.$uc.'">'.$uc.'</a></b></font><br/><textarea cols="40" rows="3"><a href="'.$uc.'">Download 3G Speed UCWEB Downloader and Win Samsung Tab!</a></textarea></div>';
}
}

else {

echo '<div class="title">Add Site</div><div class="form"><form method="post" action="/ucweb.php" name="form">
       Site name:<br/>
            <input name="title" type="text" class="inp1" maxlength="50" value=""/>(8 characters only)
          <br/>Site URL:<br/><input name="url" type="text"  maxlength="255" class="inp1" value="http://"/><br/>
             Category<br/>
            <label><select name="cid"  id="cid">
                <option value="">Site Type</option>
                                <option  value="Download">
                Download                </option>
                                <option  value="Music">
                Music                </option>
                                <option  value="VIdeo">
                Video                </option>
                                <option  value="Entertainment">
                Entertainment                </option>
                                <option  value="Portal">
                Portal                </option>
                                <option  value="Technology ">
                Technology                </option>
                                <option  value="Community">
                Community                </option>
                                <option  value="Chat">
                Chat                </option>
                                <option  value="Email">
                Email                </option>
                                <option  value="Search">
                Search                </option>
                                <option  value="Blog">
                Blog                </option>
                                <option  value="Travel">
                Travel                </option>
                                <option  value="Lifestyle">
                Lifestyle                </option>
                                <option  value="Others">
                Others                </option>
                              </select>
              </label>
          
         <br/><input name="Submit" class="btn btn-success" type="submit" id="button" value="Submit" />&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;<input name="Submit2" class="btn btn-success" type="reset" id="for" value="Reset" />
      </form></div>';
}
echo '<div class="ad"><img src="/home.png"/> <a href="/">Home</a> | <a href="/user/dashboard">Dashboard</a></div>';

} else { header("Location:/"); 
}
include 'foot.php';


?>