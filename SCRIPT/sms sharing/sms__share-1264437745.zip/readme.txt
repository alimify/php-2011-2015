///////////////////////sms sharing with mysql and admin panel beta 
/*


shared and made by wapadmin.info from mobtop


miss you rey :)

report bugs at bugs[at]wapadmin.info

/*/
so the admin username is metal and password is metal
the admin login is in lala.php
to login as admin open 
ursite.com/sms/lala.php
enter the details and u see admin panel