<?php
///////////////////////sms sharing with mysql and admin panel beta 
/*

shared and made by wapadmin.info from mobtop

miss you rey :)
report bugs at bugs[at]wapadmin.info

/*/
$dbuser="root";               //Database User Username
$dbpass="root";                    //Database User Password
$dbserver="localhost";          //Database Server(Usually "Localhost")
$dbname="sms";        //Database Name
$site_name="wapadmin sms";                 
$site_url="http://ursite.com/sms/";       
$admin_email="********ur email@gmail.com";
$site_theme="default";               
$site_logo="images/logo.png";         
$gzip="on";                        
$script_timer="on";                 
$site_active="on";                
?>