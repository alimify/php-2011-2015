<?php
///////////////////////sms sharing with mysql and admin panel beta 
/*

shared and made by wapadmin.info from mobtop

miss you rey :)
report bugs at bugs[at]wapadmin.info

/*/
echo"<div class=\"footer\"><img src=\"images/home.png\"> <a href=\"index.php\">Home</a></div>";

?>