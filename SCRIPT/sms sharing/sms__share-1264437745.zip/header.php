<? 
///////////////////////sms sharing with mysql and admin panel beta 
/*

shared and made by wapadmin.info from mobtop

miss you rey :)
report bugs at bugs[at]wapadmin.info

/*/
echo'<?xml version="1.0"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<html><head>';
print'<style type="text/css">';
include ("style.css");
print'</style>';
echo '<title>Welcome</title>';
print'</head><body>';
print'<div class="header">sms demo</div>';
print'<div class="sender">submit your sms!</div>';
?>