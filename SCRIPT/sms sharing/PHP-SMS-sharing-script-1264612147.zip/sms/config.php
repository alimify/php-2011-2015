<? echo'<?xml version="1.0"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>';

$razdel="SpicyWap.Net SMS";      //section name in the title and page
     $kol_vo=3;                       //number of content on the page

    $filex=".php";                       //remove extension in the file name on the page
                                             //here should write expanding files in the folder
                                             //write only one type of expansion, but the script can ship and several extensions
                                             //if the extension does not match the reference file will be with him, that share is not very nice =)

$home ="http://spicywap.net";
?>

<!-- (c) WWW.SPICYWAP.NET -->
<!-- Created By : VeNoM -->

