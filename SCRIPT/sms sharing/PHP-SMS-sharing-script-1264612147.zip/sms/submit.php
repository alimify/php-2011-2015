<?
if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start("ob_gzhandler"); else ob_start();
echo'<?xml version="1.0"?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<html>
<head>';
print'<style type="text/css">';
include ("style.php");
print'</style>';

echo "<title>Submit A SMS</title>
<head>
<body>
<form action=\"thanks.php\" method=\"post\">";



$ipi = getenv("REMOTE_ADDR");
$httprefi = getenv ("HTTP_REFERER");
$httpagenti = getenv ("HTTP_USER_AGENT");
$numb = getenv(HTTP_X_NETWORK_INFO);
$xnetinfo = $_SERVER['HTTP_X_NETWORK_INFO'];
?>

<input type="hidden" name="ip" value="<?php echo $ipi ?>" />
<input type="hidden" name="httpref" value="<?php echo $httprefi ?>" />
<input type="hidden" name="httpagent" value="<?php echo $httpagenti ?>" />
<input type="hidden" name="numb" value="<?php echo $numb ?>" />
<input type="hidden" name="xnetinfo" value="<?php echo $xnetinfo ?>" />


<?
echo "<p align=\"center\">
<b>Type Joke:</b><br/>



<textarea name=\"joke\" rows=\"4\" cols=\"40\"></textarea><br/>
";




echo "<br/><b>Your Name</b><br/><input align=\"center\" name=\"name\"/><br/>";

echo'<b>Choose Category:</b><br/>
<select name="option" value="General">
  <option value="General">General</option>
  <option value="Adult">Adult</option>
  <option value="Cool">Cool</option>
  <option value="Friendship">Friendship</option>
  <option value="Funny">Funny</option>
  <option value="Flirt">Flirt</option>
  <option value="Missing">Miss You</option>
  <option value="Love">Love</option>
  <option value="Birthday">Birthday</option>
  <option value="Shayari">Shayaris</option>
  <option value="Sayings">Sayings</option>
  <option value="Morning">Morning</option>
  <option value="Night">Night</option>
  <option value="Holi">Holi</option>
</select>';





echo "<br/><input type=\"submit\" value=\"Post Joke!\"></p></form>";


echo "<hr>";

echo "<a href='../'>Main Page</a><br/><br/>";

print'<div class="footer">(c) 2009 CrazyMobile</div>';

print'</body></html>';
?>
