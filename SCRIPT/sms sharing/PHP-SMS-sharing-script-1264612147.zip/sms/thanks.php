<? if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start("ob_gzhandler"); else ob_start();
echo'<?xml version="1.0"?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<xhtml>
<head>';
print'</head>
<body>
<title>Thank You!</title>';


print'<style type="text/css">';
include ("style.php");
print'</style>';

$joke = $_POST['joke'];
$name = $_POST['name'];
$option = $_POST['option'];


$ip = $_POST['ip'];
$httpref = $_POST['httpref'];
$httpagent = $_POST['httpagent'];
$visitor = $_POST['visitor'];
$visitormail = $_POST['visitormail'];
$notes = $_POST['notes'];
$attn = $_POST['attn'];
$numb = $_POST['numb'];
$xnetinfo = $_POST['$xnetinfo'];



  $joke = htmlspecialchars($joke);
  $name = htmlspecialchars($name);
  $option = htmlspecialchars($option);
  $name=str_replace("�","'",$name);
  $name=str_replace('�','"',$name);
  $name=str_replace('�','"',$name);
  $joke =str_replace("�","'",$joke );
  $joke =str_replace('�','"',$joke );
  $joke =str_replace('�','"',$joke );

function clean_url($joke)
{
$text=strtolower($joke);
$code_entities_match = array(' ','--','&quot;','!','@','#','$','%','^','&','*','(',')','_','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','.','/','*','+','~','`','=');
$code_entities_replace = array('-','-','','','','','','','','','','','','','','','','','','','','','','','','');
$text = str_replace($code_entities_match, $code_entities_replace, $text);
return $joke;
}

if (eregi('http:', $joke)) {
die ("Do NOT try that! ! ");
}


if(empty($joke) || empty($name) || empty($option )) {
echo "<h2>Use Back - fill in all fields</h2>\n";
die ("Use back! ! ");
}




$subject = $option;
$notes = stripcslashes($joke);

$message = "
Category: $subject \n\n
Message:\n $joke \n\n
From: $name\n
Additional Info : IP = $ip \n
Number: $numb \n $xnetinfo \n
Referral : $httpref \n
Browser Info: $httpagent \n
";

$from = "From: $name@spicywap.net\r\n";





mail("admin@spicywap.net", $subject, $message, $from);



echo"Thank You! Your Joke Has Been Queued For Update, Site Owners/Moderators Will Have A Look At Your SMS And Will Be Updated Soon!<br/>";

print '<br/><a href="index.php"><b>Click Here To Go Back</b></a>';




print'<div class="footer">(c) 2009 CrazyMobile</div>';

print'</body></html>';





?>