<? 
include ("../config.php");
print'<style type="text/css">';
include ("../style.css");
print'</style>';
$more= $_GET['more'];
?>

<title><? echo $razdel ?></title>
</head>
<body>

<div class="header"><? echo $razdel ?></div>



<?php
$pg = $_GET['page'];
$fl=array();
$dir_pointer=opendir(".");
while (($res=readdir($dir_pointer))!==FALSE){
if($res==".")unset($res);
if($res=="..")unset($res);
if($res=="index.php")unset($res);
if($res=="error_log")unset($res);
if($res=="style.php")unset($res);
if(!$res==""){array_push($fl,$res);}
}
for($i=0; $i<count($fl); $i++) {
$time[$fl[$i]] = filemtime($fl[$i]); }
arsort($time);
$keys = array_keys($time);
$cnt=count($keys);
$n = $kol_vo;
@$p= intval($_REQUEST['p']);
if(empty($_REQUEST['page']) or $_REQUEST['page']<1) {$_REQUEST['page']=1; }
if($_REQUEST['page']>$cnt) { $page=$cnt; }
$pages = intval(($cnt-1 )/$n+1);
$st = $_REQUEST['page']*$n-$n;
$nx = $st+$n;
for($i=$st; $i<$nx;$i++)
{
if(!isset($keys[$i]))continue;
$fname2= ereg_replace ("$filex", "", $keys[$i]);
$fnsize2= round(filesize ($keys[$i]) /1024 , 1);
$fninfo2="info/".$fname2.".txt";
if ($keys[$i] !="info" and $keys[$i] !="conf") {
if (file_exists($fninfo2)) {echo "<li><a href=\"$keys[$i]\">$fname2</a> ($fnsize2 Kb)<br/>"; include($fninfo2); echo "</li>";}
else {




$content = file("$keys[$i]");
  $text = implode("<br>",$content);


        $text=str_replace("�","...",$text);
        $text=str_replace("mobile.web.tr","",$text);
        $text=str_replace("http://","",$text);
        $text=str_replace("www.","",$text);
        $text=str_replace(".com","",$text);
        $text=str_replace("567678","",$text);
        $text=str_replace("9900145368","",$text);
        $text=str_replace("9980199801","",$text);
        $text=str_replace("smn4u","",$text);
        $text=str_replace("wapath","",$text);
        $text=str_replace(".prodigits","",$text);
        $text=str_replace("tagtag","",$text);
        $text=str_replace(".net","",$text);
        $text=str_replace(".biz","",$text);
        $text=str_replace(".wen.","",$text);
        $text=str_replace(".in","",$text);
        $text=str_replace(".org","",$text);
        $text=str_replace(".co.uk","",$text);
        $text=str_replace(".co.in","",$text);
        $text=str_replace("info","",$text);
        $text=str_replace(".Wen.","",$text);
        $text=str_replace('tjtj','',$text);
        $text=str_replace('gmgm','',$text);
        $text=str_replace('papap','',$text);
        $text=str_replace('mamam','',$text);
        $text=str_replace('wawaw','',$text);
        $text=str_replace('gagag','',$text);
        $text=str_replace('wpw','',$text);
        $text=str_replace('atat','',$text);
        $text=str_replace('jajaj','',$text);
        $text=str_replace('mjm','',$text);
        $text=str_replace('gjg','',$text);
        $text=str_replace('jatj','',$text);
        $text=str_replace('tpt','',$text);
        $text=str_replace('___','_',$text);
        $text=str_replace('__','_',$text);
        $text=str_replace(" . .."," .",$text);
        $text=str_replace(".. . ",". ",$text);
        $text=str_replace(" . . "," ",$text);
        $text=str_replace(" . "," ",$text);
        $text=str_replace("...","..",$text);
        $text=str_replace("  "," ",$text);
        $text=str_replace('??? ???',"",$text);
        $text=str_replace('??????',"",$text);
        $text=str_replace('*** ***',"",$text);
        $text=str_replace('******',"",$text);
        $text=str_replace('??? ***',"",$text);
        $text=str_replace('???***',"",$text);
        $text=str_replace('*** ???',"",$text);
        $text=str_replace('***???',"",$text);
        $text=str_replace("\\","",$text);    //[:punct:]


 echo $text;

$text = str_replace("<div class='joke'>", "", $text);
$text = str_replace("<div class='title'>", "", $text);
$text = str_replace("<div class='sender'>", "", $text);
$text = str_replace("</div>", "",$text);
$text = str_replace("'", "", $text);
$text = str_replace('"', ' ', $text);
$text = str_replace('<br>', '', $text);
$text = str_replace(';', '', $text);

if($more==1)
{

echo "<br/><a href=\"".$path."?more=0&page=".$pg."\">Copy SMS Off</a>";

echo "<br/><textarea name=\"joke\" rows=\"4\" cols=\"40\">$text </textarea><br/>
<br/>";

}
else
{
echo "<br/><a href=\"".$self."?more=1&page=".$pg."\">Copy SMS</a><br/>";
}


echo"<a href=\"sms:?body=$text \n -www.spicywap.net\">Forward This SMS</a>";


 echo "<hr>";


///echo "<li><a href=\"$keys[$i]\">$fname2</a> ($fnsize2 Kb)</li>";

}
;}
}

/*
echo "Pages:<br/>";
for($c=0; $c<$pages; $c++) {
$pg = $c+1;
if($pg == $_REQUEST['page']) {
echo "|&nbsp;<span class=\"bold\">$pg</span>&nbsp;|"; }
else {echo "|&nbsp;<a href=\"?page=".$pg."\">".$pg."</a>&nbsp;|"; }
}

*/


$pages1 = $pages -1;
if($_REQUEST['page'] > 1 && $_REQUEST['page']<=$pages1)
{
$npage = $_REQUEST['page']+1;
$ppage = $_REQUEST['page']-1;

echo "<a href=\"?page=$ppage\">Previous Page</a><br/>";
echo "<a href=\"?page=$npage\">Next Page</a>";

}
else if ($_REQUEST['page']<=$pages && $_REQUEST['page'] != 1)
{
$ppage = $_REQUEST['page']-1;

echo "<a href=\"?page=$ppage\">Previous Page</a>";
}

else  if ($pages == 1)
{

}

else
{
$npage = $_REQUEST['page']+1;
echo "<a href=\"?page=$npage\">Next Page</a>";
}


include ("../foot.php");

?>
</div></body>
</html>