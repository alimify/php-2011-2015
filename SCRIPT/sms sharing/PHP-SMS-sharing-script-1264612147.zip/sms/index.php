<? echo'<?xml version="1.0"?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>';


print'<style type="text/css">';
include ("style.css");
print'</style>';

print'<title>Welcome</title>';

print'</head>
<body>
';


print'<div class="header">SpicyWap.Net SMS World</div>';





print'<div class="sender">Category!</div>';




if(!($dp = opendir("Adult"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count = count ($file_array);


if(!($dp = opendir("General"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php"  and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count1 = count ($file_array);


if(!($dp = opendir("Birthday"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count2 = count ($file_array);

if(!($dp = opendir("Friendship"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php"  and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count3 = count ($file_array);

if(!($dp = opendir("Funny"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count4 = count ($file_array);

if(!($dp = opendir("Missing"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count5 = count ($file_array);


if(!($dp = opendir("Flirt"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php"and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count6 = count ($file_array);


if(!($dp = opendir("Love"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count7 = count ($file_array);


if(!($dp = opendir("Cool"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count8 = count ($file_array);

if(!($dp = opendir("Shayari"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count9 = count ($file_array);

if(!($dp = opendir("Sayings"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count10 = count ($file_array);


if(!($dp = opendir("Night"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count11 = count ($file_array);


if(!($dp = opendir("Morning"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count12 = count ($file_array);

if(!($dp = opendir("Holi"))) die ("Cannot open ./");
$file_array = array(); 
while ($file = readdir ($dp))
{
if(substr($file,0,1) != '.' and $file != "index.php" and $file != "style.php" and $file != "dl.php" and $file != "search.php" and $file != "error_log")
{
$file_array[] = $file;
}
}
$file_count13 = count ($file_array);


echo "<a href='Holi'>Holi SMS($file_count13)</a> [new] <br/>";

echo "<a href='Adult'>Adult SMS ($file_count)</a><br/>";
echo "<a href='General'>General SMS ($file_count1)</a><br/>";
echo "<a href='Birthday'>BirthdaySMS ($file_count2)</a><br/>";
echo "<a href='Friendship'>Friendship SMS ($file_count3)</a><br/>";
echo "<a href='Funny'>Funny SMS ($file_count4)</a><br/>";
echo "<a href='Missing'>Miss You SMS ($file_count5)</a><br/>";
echo "<a href='Flirt'>Flirt SMS ($file_count6)</a><br/>";
echo "<a href='Love'>Love SMS ($file_count7)</a><br/>";
echo "<a href='Cool'>Cool SMS ($file_count8)</a><br/>";
echo "<a href='Shayari'>Shayari SMS ($file_count9)</a><br/>";

echo "<a href='Sayings'>Sayings ($file_count10)</a><br/>";
echo "<a href='Night'>Good Night SMS($file_count11)</a><br/>";
echo "<a href='Morning'>Good Morning SMS($file_count12)</a>";




echo "<hr>";


echo "<a href='submit.php'>Submit SMS</a><br/>";

echo "<a href='../'>Main Page</a><br/><br/>";



print'<div class="footer">(c) 2009 SMSSCRIPT!</div>';

print'</body></html>';
?>