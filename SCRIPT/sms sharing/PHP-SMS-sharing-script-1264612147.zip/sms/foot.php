<?

echo "<br/><br/><a href='../'>SMS Menu</a><br/>";
echo "<a href='$home'>Home</a><br/>";
?>
<div class="footer">(c) SpicyWap.Net 2009</div>