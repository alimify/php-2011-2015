-- MySQL dump 10.13  Distrib 5.5.37, for Linux (x86_64)
--
-- Host: localhost    Database: jewelxp_p
-- ------------------------------------------------------
-- Server version	5.5.37-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `sitename` varchar(255) NOT NULL,
  `filepostfix` varchar(50) NOT NULL,
  `title` text NOT NULL,
  `thumbw` int(3) NOT NULL,
  `thumbh` int(3) NOT NULL,
  `set` varchar(255) NOT NULL,
  `dthumbw` int(3) NOT NULL,
  `dthumbh` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `username`, `password`, `email`, `sitename`, `filepostfix`, `title`, `thumbw`, `thumbh`, `set`, `dthumbw`, `dthumbh`) VALUES (1,'Jewel','zipadminfile','jewelworld9@gmail.com','AnyMaza.CoM','(AnyMaza.CoM)','Wellcome To AnyMaza.CoM',50,60,'aHR0cDovL2Z1bGwybW9iLnRrLw==',50,60);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_setting`
--

DROP TABLE IF EXISTS `admin_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_setting` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `value` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `adminsetting_id` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_setting`
--

LOCK TABLES `admin_setting` WRITE;
/*!40000 ALTER TABLE `admin_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` double NOT NULL,
  `name` text NOT NULL,
  `path` text NOT NULL,
  `pathc` text NOT NULL,
  `totalitem` double NOT NULL,
  `folder` text NOT NULL,
  `newitemtag` tinyint(1) NOT NULL,
  `updateitemtag` tinyint(1) NOT NULL,
  `subcate` tinyint(1) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `clink` text NOT NULL,
  `des` text NOT NULL,
  `thumb` text NOT NULL,
  `kram` double NOT NULL,
  `sub` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_index` (`id`),
  KEY `date_index` (`date`),
  KEY `parentid_index` (`parentid`),
  KEY `kramindex` (`kram`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`, `parentid`, `name`, `path`, `pathc`, `totalitem`, `folder`, `newitemtag`, `updateitemtag`, `subcate`, `date`, `clink`, `des`, `thumb`, `kram`, `sub`) VALUES (7,0,'Testfolder','&nbsp;&raquo;&nbsp;<a href=\"?pid=7\">Testfolder</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/7/Testfolder.html\">Testfolder</a>',0,'upload_file/7/',0,0,0,'2014-06-04 04:26:20','Testfolder','','',5,''),(2,0,'English Album','&nbsp;&raquo;&nbsp;<a href=\"?pid=2\">English Album</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/2/English Album.html\">English Album</a>',0,'upload_file/2/',0,0,0,'2014-06-03 16:36:43','English Album','','',2,''),(3,0,'Hindi Album','&nbsp;&raquo;&nbsp;<a href=\"?pid=3\">Hindi Album</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/3/Hindi Album.html\">Hindi Album</a>',0,'upload_file/3/',0,0,0,'2014-06-03 16:38:51','Hindi Album','','',3,''),(4,0,'Kalkata Album','&nbsp;&raquo;&nbsp;<a href=\"?pid=4\">Kalkata Album</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/4/Kalkata Album.html\">Kalkata Album</a>',5,'upload_file/4/',0,0,1,'2014-08-08 04:52:55','Kalkata Album','','',4,''),(5,0,'Bangla Album','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>',24,'upload_file/5/',0,0,1,'2014-08-08 04:52:55','Bangla Album','','',5,''),(6,5,'Agnee Ft Mahi','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=6\">Agnee Ft Mahi</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/6/Agnee Ft Mahi.html\">Agnee Ft Mahi</a>',2,'upload_file/5/6/',0,0,0,'2014-06-04 04:54:59','Bangla Album/Agnee Ft Mahi','','',1,''),(8,5,'Dure Ki Thaka Jay Ft VA','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=8\">Dure Ki Thaka Jay Ft VA</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/8/Dure Ki Thaka Jay Ft VA.html\">Dure Ki Thaka Jay Ft VA</a>',2,'upload_file/5/8/',0,0,0,'2014-06-04 07:04:02','Bangla Album/Dure Ki Thaka Jay Ft VA','','',2,''),(9,5,'Bhalo Lage Na (2014)Hridoy Khan','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=9\">Bhalo Lage Na (2014)Hridoy Khan</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/9/Bhalo Lage Na (2014)Hridoy Khan.html\">Bhalo Lage Na (2014)Hridoy Khan</a>',4,'upload_file/5/9/',0,0,0,'2014-06-08 02:05:17','Bangla Album/Bhalo Lage Na (2014)Hridoy Khan','','',3,''),(10,5,'Drhubotara(2014)Sonia,Belal Khan & V A','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=10\">Drhubotara(2014)Sonia,Belal Khan & V A</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/10/Drhubotara(2014)Sonia,Belal Khan & V A.html\">Drhubotara(2014)Sonia,Belal Khan & V A</a>',4,'upload_file/5/10/',0,0,0,'2014-06-12 14:58:23','Bangla Album/Drhubotara(2014)Sonia,Belal Khan & V A','','',4,''),(11,4,'Sesh Bole Kichu Nei (2014) Jishu ft Subosree','&nbsp;&raquo;&nbsp;<a href=\"?pid=4\">Kalkata Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=11\">Sesh Bole Kichu Nei (2014) Jishu ft Subosree</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/4/Kalkata Album.html\">Kalkata Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/11/Sesh Bole Kichu Nei (2014) Jishu ft Subosree.html\">Sesh Bole Kichu Nei (2014) Jishu ft Subosree</a>',3,'upload_file/4/11/',0,0,0,'2014-06-18 15:21:48','Kalkata Album/Sesh Bole Kichu Nei (2014) Jishu ft Subosree','','',1,''),(12,5,'Borshar Gaan (2014) Belal Khan Ft Mixed Album','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=12\">Borshar Gaan (2014) Belal Khan Ft Mixed Album</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/12/Borshar Gaan (2014) Belal Khan Ft Mixed Album.html\">Borshar Gaan (2014) Belal Khan Ft Mixed Album</a>',2,'upload_file/5/12/',0,0,0,'2014-06-26 13:31:30','Bangla Album/Borshar Gaan (2014) Belal Khan Ft Mixed Album','','',5,''),(13,5,'Aaj Keno Borsha Name ( 2014 ) Mixed Album','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=13\">Aaj Keno Borsha Name ( 2014 ) Mixed Album</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/13/Aaj Keno Borsha Name ( 2014 ) Mixed Album.html\">Aaj Keno Borsha Name ( 2014 ) Mixed Album</a>',2,'upload_file/5/13/',0,0,0,'2014-06-29 23:32:36','Bangla Album/Aaj Keno Borsha Name ( 2014 ) Mixed Album','','',6,''),(14,5,'Ya Nobi Salamu Alaika-VA','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=14\">Ya Nobi Salamu Alaika-VA</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/14/Ya Nobi Salamu Alaika-VA.html\">Ya Nobi Salamu Alaika-VA</a>',2,'upload_file/5/14/',0,0,0,'2014-07-06 14:37:54','Bangla Album/Ya Nobi Salamu Alaika-VA','','',7,''),(15,5,'Elo Melo ( 2014 ) By Habib FT Shakib','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=15\">Elo Melo ( 2014 ) By Habib FT Shakib</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/15/Elo Melo ( 2014 ) By Habib FT Shakib.html\">Elo Melo ( 2014 ) By Habib FT Shakib</a>',2,'upload_file/5/15/',0,0,0,'2014-07-07 18:35:17','Bangla Album/Elo Melo ( 2014 ) By Habib FT Shakib','','',8,''),(16,4,'Golpo Holeo Sotti ( 2014 )','&nbsp;&raquo;&nbsp;<a href=\"?pid=4\">Kalkata Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=16\">Golpo Holeo Sotti ( 2014 )</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/4/Kalkata Album.html\">Kalkata Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/16/Golpo Holeo Sotti ( 2014 ).html\">Golpo Holeo Sotti ( 2014 )</a>',2,'upload_file/4/16/',0,0,0,'2014-07-08 07:24:01','Kalkata Album/Golpo Holeo Sotti ( 2014 )','','',2,''),(17,5,'Janina Kon Montorey ( 2014 ) Bappa Mazumder','&nbsp;&raquo;&nbsp;<a href=\"?pid=5\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"?pid=17\">Janina Kon Montorey ( 2014 ) Bappa Mazumder</a>','&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/5/Bangla Album.html\">Bangla Album</a>&nbsp;&raquo;&nbsp;<a href=\"http://zip.anymaza.com/category/17/Janina Kon Montorey ( 2014 ) Bappa Mazumder.html\">Janina Kon Montorey ( 2014 ) Bappa Mazumder</a>',4,'upload_file/5/17/',0,0,0,'2014-08-08 04:52:45','Bangla Album/Janina Kon Montorey ( 2014 ) Bappa Mazumder','','',9,'');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `dname` text NOT NULL,
  `cid` double NOT NULL,
  `ext` varchar(5) NOT NULL,
  `thumbext` varchar(5) NOT NULL,
  `size` varchar(10) NOT NULL,
  `desc` text NOT NULL,
  `download` double NOT NULL,
  `thits` double NOT NULL,
  `yhits` double DEFAULT NULL,
  `whits` double NOT NULL,
  `mhits` double NOT NULL,
  `view` double NOT NULL,
  `newtag` tinyint(1) NOT NULL,
  `imagetype` tinyint(1) NOT NULL,
  `kram` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_index` (`id`),
  KEY `download_index` (`download`),
  KEY `kramindex` (`kram`),
  KEY `cidindex` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` (`id`, `name`, `dname`, `cid`, `ext`, `thumbext`, `size`, `desc`, `download`, `thits`, `yhits`, `whits`, `mhits`, `view`, `newtag`, `imagetype`, `kram`) VALUES (12,'Bhalo Lage Na( 64kbps)','Bhalo Lage Na( 64kbps)(AnyMaza.CoM)',9,'zip','','25761068','',212,7,1,6,378,106,0,0,3),(8,'album.jpg','album(AnyMaza.CoM)',8,'jpg','','26648','',29,0,NULL,56,56,7,0,0,2),(9,'album','album(AnyMaza.CoM)',9,'jpg','','8318','',38,0,0,73,73,8,0,0,1),(6,'album','album(AnyMaza.CoM)',6,'jpg','','69584','',27,0,0,52,52,4,0,0,2),(5,'Agnee Full Album','AGNEE-2B-28Movie-2BSongs-29Full(AnyMaza.CoM)',6,'zip','','29541710','',104,2,9,21,186,40,0,0,1),(7,'Dure Ki Thaka Jay (64kbps) Ft Va','Dure-2BKi-2BThaka-2BJay-28Hema-2B-26VA-2964kbps(AnyMaza.CoM)',8,'zip','','19405032','',103,0,3,23,189,41,0,0,1),(11,'Bhalo Lage Na (192kbps)Hridoy Khan','Bhalo Lage Na (192kbps)Hridoy Khan(AnyMaza.CoM)',9,'zip','','72273032','',104,0,0,22,197,43,0,0,2),(13,'Bhalo Lage Na (128kbps)Hridoy Khan','Bhalo-Lagena--28128kbps-29(AnyMaza.CoM)',9,'zip','','61378770','',146,4,1,83,265,73,0,0,4),(14,'album','album(AnyMaza.CoM)',10,'jpg','','12958','',30,0,0,54,56,5,0,0,1),(15,'Dhrubotara (128kbps)Sonia,Belal Khan & Va','Dhrubotara (128kbps)Sonia,Belal Khan & Va(AnyMaza.CoM)',10,'zip','','48240272','',55,0,8,104,104,21,0,0,2),(16,'Dhrubotara(192kbps)Sonia,Belal Khan & VA','Dhrubotara-28192kbps-29Sonia-2cBelal-Khan--26-VA(AnyMaza.CoM)',10,'zip','','56328204','',48,0,0,91,91,10,0,0,3),(17,'Dhrubotara(64kbps)Sonia,Belal Khan','file(AnyMaza.CoM)',10,'zip','','19765999','',101,0,0,124,181,42,0,0,4),(24,'Aaj Keno Borsha Name ( 128kbps ) Mixed Album','Aaj-Keno-Borsha--28-128kbps--29-Mixed-Album(AnyMaza.CoM)',13,'zip','','53405520','',128,1,0,111,232,50,0,0,1),(19,'Sesh Bole Kichu Nei (2014) Jishu ft Subosree - 64kbps','Sesh-Bole-Kichu-Nei--2864kbps-29(AnyMaza.CoM)',11,'zip','','16710130','',90,0,0,62,169,51,0,0,2),(20,'album','album(AnyMaza.CoM)',11,'jpg','','3476','',29,0,0,26,53,2,0,0,3),(21,'Sesh Bole Kichu Nei Ft Jishu & Subosree - 128kbps','sesh-bole-kichu-nae-128kbps(AnyMaza.CoM)',11,'zip','','43915460','',57,0,1,82,106,18,0,0,4),(22,'Borshar Gaan (128kbps) Belal Khan Ft Mixed Album','file(AnyMaza.CoM)',12,'zip','','66530608','',112,0,0,15,206,41,0,0,1),(23,'Borshar Gaan (64kbps) Belal Khan Ft Mixed Album','file(AnyMaza.CoM)',12,'zip','','23193842','',201,3,2,103,363,106,0,0,2),(27,'Ya Nobi Salamu Alaika-VA 128kbps','Yaa-Salamualaikum(AnyMaza.CoM)',14,'zip','','18787222','',69,0,0,32,130,27,0,0,2),(25,'Aaj Keno Borsha Name ( 64kbps ) Mixed Album','hindi(AnyMaza.CoM)',13,'zip','','22564030','',269,3,1,171,459,126,0,0,2),(26,'Ya Nobi Salamu Alaika-VA 64kbps','Ya-Nobi-Salamu-Alaika-VA(AnyMaza.CoM)',14,'zip','','9475418','',64,0,0,119,119,22,0,0,1),(28,'Elo Melo ( 2014 ) By Habib FT Shakib - 128kbps','Elo-Melo--28-128kbps--29-Ft-Habib--26-Shakib(AnyMaza.CoM)',15,'zip','','41080705','',75,0,0,93,136,38,0,0,1),(29,'Elo Melo ( 2014 ) By Habib FT Shakib - 64kbps','Elo-Melo-64kbps(AnyMaza.CoM)',15,'zip','','20643567','',118,1,8,70,210,55,0,0,2),(30,'Golpo Holeo Sotti ( 2014 ) 128kbps','Golpo-Holeo-Sotti--28-2014--29-128kbps(AnyMaza.CoM)',16,'zip','','29325217','',54,0,3,84,100,22,0,0,1),(31,'Golpo Holeo Sotti ( 2014 ) 64kbps','Golpo-Holeo-Sotti--28-2014--29-64kbps(AnyMaza.CoM)',16,'zip','','10356109','',92,0,4,134,157,35,0,0,2),(32,'Janina Kon Montorey ( 2014 ) Bappa Mazumder - 128kbps','Janina-Kon--Montorey-128kbps(AnyMaza.CoM)',17,'zip','','63192090','',46,0,0,81,81,22,0,0,1),(33,'Janina Kon Montorey ( 2014 ) Bappa Mazumder - 320kbps','Janina-Kon-Montorey--28320kbps-29-By-Bappa-Mazumder(AnyMaza.CoM)',17,'zip','','106895416','',36,0,0,61,61,4,0,0,2),(34,'Janina Kon Montorey ( 2014 ) Bappa Mazumder - 64kbps','Janina-Kon-Montorey--28-64kbps--29-Bappa-Mazumder(AnyMaza.CoM)',17,'zip','','25333221','',64,0,0,103,103,40,0,0,3),(35,'Trimatrik-Prithibi---Lutfor-Hasan-KingBD','Trimatrik-Prithibi---Lutfor-Hasan-KingBD(AnyMaza.CoM)',17,'mp3','','2163104','',20,0,2,29,29,5,0,0,4);
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guest_book`
--

DROP TABLE IF EXISTS `guest_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest_book` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(17) COLLATE utf8_unicode_ci NOT NULL,
  `flag` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `uagent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uprofile` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest_book`
--

LOCK TABLES `guest_book` WRITE;
/*!40000 ALTER TABLE `guest_book` DISABLE KEYS */;
/*!40000 ALTER TABLE `guest_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `update`
--

DROP TABLE IF EXISTS `update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `update` (
  `id` double NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `link` text NOT NULL,
  `home` tinyint(1) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `update`
--

LOCK TABLES `update` WRITE;
/*!40000 ALTER TABLE `update` DISABLE KEYS */;
INSERT INTO `update` (`id`, `name`, `link`, `home`, `date`) VALUES (9,'<a href=\"http://zip.anymaza.com/category/10/Drhubotara(2014)Sonia,Belal%20Khan%20&%20V%20A.html\">Drhubotara By Sonia & Va Full Album</a>','',1,'2014-06-12 20:49:25'),(8,'<a href=\"fileList/9/new2old/1.html\">Bhalo Lage Nah ( 2014 ) By Hridoy Khan Full Album</a>','',1,'2014-06-08 01:37:39'),(6,'<a href=\"http://zip.anymaza.com/fileList/6/new2old/1.html\"> AGNEE Full Album</a>','',1,'2014-06-08 01:34:36'),(7,'<a href=\"fileList/8/new2old/1.html\">Dure Ki Thaka Jay Ft Va</a>','',1,'2014-06-08 01:36:24'),(10,'<a href=\"http://zip.anymaza.com/fileList/11/new2old/1.html\">Sesh Bole Kichu Nei ( Cd Rip )Ft Jishu & Subosree</a>','',1,'2014-06-18 21:24:42'),(15,'<a href=\"http://zip.anymaza.com/fileList/12/new2old/1.html\">Borshar Gaan (2014) Belal Khan & VA</a>','',1,'2014-06-26 21:09:58'),(16,'<a href=\"http://zip.anymaza.com/fileList/13/new2old/1.html\">Aj Keno Borsha Name (2014) Mixed Album</a>','',1,'2014-06-30 05:38:29');
/*!40000 ALTER TABLE `update` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-09-29  0:00:13
