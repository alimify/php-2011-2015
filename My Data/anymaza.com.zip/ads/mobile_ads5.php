<?php
        $adq_params = array(
                       "ADQ_PARAMS"  => array(
                                 "pazid"=>"adqk55sn-14z1lol9-ub6bq",//PAZID      
		                 "adbgcolor"=>"FFFFFF", //Ad Unit Background color
           			 "adtcolor"=>"0063DC",  //Ad Unit Text color

				 )
                        );
        adiquity_ad($adq_params);
?>       