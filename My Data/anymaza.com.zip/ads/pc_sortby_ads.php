<script type="text/javascript">
var uid = '29209';
var wid = '55003';
</script>
<script type="text/javascript" src="http://cdn.popcash.net/pop.js"></script>