<!-- G&R_300x600 -->
<script>
	var gandr_conf = {
		siteid : 2705,
		slot : 6728,
	};
</script>
<script src="http://www.gandrad.org/lib/ad.js"></script>
<noscript><iframe frameborder="0" scrolling="no" width='300' height='600' src='http://nojs.green-red.com/src/?e=a&p=2705&l=6728'></iframe></noscript>
<!-- End of G&R_300x600 -->