<?
$set[1]="AnyMaza.Com 2014<br/>All Rights Reserved";
$set[2]="0987654321";
$set[3]="0";
$set[4]="10";
$set[5]="AnyMaza.Com | Updates";
$set[6]="Post your Updates";
?>
