<img src="/usersonline.php" alt="Online"/><div align="right"><a href="?logout=1">Logout</a></div><div class="f1" align="center"><b>Copyright &copy; AnyMaza.Com 2014</b></div>
</body></html>