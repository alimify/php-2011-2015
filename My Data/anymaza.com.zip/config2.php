<?php
//Enable compression? (1 or 0)
$zip = 1;
//Number of files on the page:
$filestr = 6;
//The number of folders on the page:
$dirstr = 20;
//Filelist
$allfile = 'thm,apt,apk,nth,mp3,amr,wav,mmf,mid,jpg,JPG,gif,GIF,png,3gp,avi,mp4,swf,sis,sisx,sys,jar,zip,rar';
//The length and height of the image for preview
$neww = 40;
$newh = 40;
//Number of comments per page:
$kommstr = 9;

// PCLZIP
$pclzip = 'pclzip.lib.php';
// ID
$mp3 = 'id.php'; // ibid should be pear.php



// Top

$top = '<?xml version="1.0" encoding="UTF-8" ?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>

';

// Bottom

$foot = '</body></html>';







?>