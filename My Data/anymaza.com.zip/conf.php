<?php
$dbname = "jewelxp_newsql";
$dbhost = "localhost";
$dbuser = "jewelxp_newsql";
$dbpass = "SHD{om=8Rn1d";
?>
