<?php

include_once('./assets/ads/footer.php');

echo '<div class="tCenter"><h2>&#169; <a href="'.$ss->settings['url'].'">'.$ss->settings['title'].'</a></h2>
Developed By : <a href="">SanVK</a><div>
</body>
</html>';