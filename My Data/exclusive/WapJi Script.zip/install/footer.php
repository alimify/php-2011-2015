<?php

echo '<div class="f1">&#169; Made by SanVK</a></div>
</body>
</html>';
