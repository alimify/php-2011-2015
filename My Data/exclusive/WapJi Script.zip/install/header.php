<?php

echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SanVK Auto index</title>
<meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" name="viewport" />
<meta name="viewport" content="width=device-width" />
<link href="../assets/css/css.css" type="text/css" rel="stylesheet"/>
</head>
<body>
<h2>SS Autoindex</div>
<div class="bkmk">Made  by SanVK</div>';
