<?php

require_once(dirname(dirname(dirname(__FILE__)))."/inc/init.php");
