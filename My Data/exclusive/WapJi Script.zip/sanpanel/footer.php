<?php
echo '<h2><a href="'.$ss->settings['url'].'">'.escape($ss->settings['title']).'</a></h2>
<div class="tCenter">Developed By : <a href="">SanVK</a><div>
</body>
</html>';
