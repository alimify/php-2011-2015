<?php

// Database details
$config['database']['type'] = "mysqli";
$config['database']['database'] = "wapjiin_san";
$config['database']['table_prefix'] = "san";

$config['database']['hostname'] = "localhost";
$config['database']['username'] = "wapjiin_san";
$config['database']['password'] = "svk585101";

/**
 * Admin CP directory
 *  For security reasons, it is recommended you
 *  rename your Admin CP directory. You then need
 *  to adjust the value below to point to the
 *  new directory.
 */

$config['admin_dir'] ="sanpanel";

/**
 * Database Encoding
 *  If you wish to set an encoding for SS uncomment
 *  the line below (if it isnt already) and change
 *  the current value to the mysql charset:
 *  http://dev.mysql.com/doc/refman/5.1/en/charset-mysql.html
 */

$config['database']['encoding'] = "utf8";