<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Wapji99.TK :: Funny videos, Free HD Videos, Ringtones, Wallpapers, Themes, Games, Softwares, Mp3 Songs, Videos</title>
<meta name="title" content="'.$title.', HD Videos, funny videos, Free HD Videos, Ringtones, Wallpapers, Themes, Games, Softwares, Mp3 Songs, Videos" />
<meta name="robots" content="index, follow" />
<meta name="language" content="en" />
<meta name="keywords" content="songs, desh bhakti songs, old Sonngs, ringtones, wallpapers, '.$title.'">
<meta name="description" content="Free Mobile Ringtones, Desh Bhakti Songs, Old Sonngs, Bollywood Songs, Wallpaper, Videos, Animations And More services '.$title.'">
<meta content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" name="viewport" />
<meta name="viewport" content="width=device-width" />
<meta name="google-site-verification" content="p85Gb_3l4PrcaLeLQiFZqSycxdjb9UdaxAwdTuyPBUA" />
<link rel="shortcut icon" href="http://wapji99.tk/assets/images/favicon.ico" />
<link href="http://wapji99.tk/assets/css/css.css" type="text/css" rel="stylesheet"/>
</head>
<body>

<div class="logo"><a href="http://wapji99.tk"><img alt="wapji99.tk" src="http://wapji99.tk/logo.png" /></a></div>
<div class="top"><a href="http://www.facebook.com/santu.kankurte" target="_blank">Like us on Facebook</a></div>

<div class="catRow"><strong>! This is a promotional website only</strong>, All the downloadable content provided on this site (<strong>All materials</strong>) is for testing/promotion purposes only.All files placed here are for introducing purpose.
</div>
<div class="catRow"><strong>! </strong>We highly ENCOURAGE users to <strong>BUY</strong> the CDs or DVDs of the movie or the music they like.Please, buy original Songs/contents from author or developer site!

</div>
<div class="catRow"><strong>! </strong>If you <strong>Do not agree</strong> to all the terms, please disconnect from this site now itself.
</div>
<div class="catRow"><strong>! </strong> By remaining at this site, you affirm your    understanding and compliance of the above disclaimer and absolve this    site of any responsibility henceforth
</div>
<div class="catRow"><strong>! </strong>All files found on this site have been collected    from various sources across the web and are believed to be in the    &quot;public domain&quot;.
</div>
<div class="catRow"><strong>! </strong>All the logos and stuff are the property of their respective owners</div>

<div class="catRow"><strong>! </strong>You should DELETE IT(data) within <strong>within 24 hours</strong> and make a point to buy the original CD or DVD from a local or online store.</div>
<div class="catRow"><strong>! </strong> If you are the rightful owner of any contents    posted here, and object to them being displayed or If you are one of    representativities of copy rights department and you dont like our    conditions of store,please mail us (<strong>thesanvk@gmail.com</strong>) or <strong>Contact Us</strong> immediately and we will delete it!</div>
<div class="f1"><a href="http://wapji99.tk/">Wapji99.TK</a></div>
<div class="db">Developed By : <a href="">SanVK</a><div>
</body>
</html>


	
