<?php

// Services
echo '
<div class="l1"><a href="/newitems/1.html">> Last Added All Files</a></div>
<div class="l1"><a href="/assets/disclaimer.php">> Disclaimer</a></div>
</div>';
