<?if(!strstr($PHP_SELF,"index.php") && !$member){$noface=1;include("index.php");}?><?
echo('<?xml version="1.0" encoding="UTF-8"?>');

if($WAP==2)
{
?>

<!-- Start xhtml -->
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="description" content="Hotwapi.Com is a mobile toplist for mobile web sites. We have over 2000 registered sites." />

	<meta name="keywords" content="Mobile Wap Sites, creat wap toplist, toplist,wap toplist,mobile,toplist,directory,link,mobile toplist,wap,top sites"/> 


<style type="text/css">
body {background-color:#ececec}
body,td {font-family: Times,"Times New Roman";;color:#000000;font-size:9pt}
tr {background-color:#cccccc}
th,tr.dark {background-color:#ffffff}
a {color:#0000ff}
p{display:none;}
.header {text-align: center; COLOR: #FFFFFF; background-color: #84f225; padding: 2px; font-size: 12px;}
</style>

<title>hotwapi.com-wap toplist</title>
</head>
<body>
<div class="header"><b>HOTWAPI.COM</b></div>
<center>Bookmark Now!<br/>
<a href="http://mywapi.com"><span style="color: #ff0000">New</span> Download</a><br/>
<a href="hotwapi.php?t=<?echo($jsum)?>&amp;link=FREE-downloads">New Downloads</a><br/>
<a href="hotwapi.php?t=<?echo($jsum)?>&amp;link=NEW-downloads">Free Downloads</a><br/>
<div class="header"><b>Free Download Menu</b></div>
</center>

<table width="100%" cellspacing="0" cellpadding="2">

<?
}
else
{
?>

<!-- Start wml -->
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">
<wml>
<template>
<do type="prev" name="Back">
<prev/>
</do>
</template>
<card id="home" title="hotwapi.com-wap toplist">
<p>
<a href="go.php?link=new-downloads">New Downloads</a><br/>
Categories:<br/>

<br/>
Best:<br/>
<!-- End wml -->

<?
}
?><?
if($WAP==2)
{
?>

<!-- Start xhtml -->
</table>
<div class="header">

<a href=".php">&lt; Prev</a><br/>
</div>
<small><?php include("user_online.php");?></small><br/>
<small>1 active sites</small><br/>
<small>in-out stats for 48 hours</small><br/>
<a href="edit.php?wap=add">Add/Edit site</a><br/>
<a href="http://mywapi.com/?id=hotwapicom">More Toplist</a>
<div class="header"><b>HOTWAPI.COM</b></div><p>


<!-- End xhtml -->

<?
}
else
{
?>

<!-- Start wml -->
<br/>
#%NEXT_START%#<a href="#%NEXTPAGE%#.php">Next &gt;</a><br/>#%NEXT_END%#
<a href=".php">&lt; Prev</a><br/>
<br/>
<small>1 active sites</small><br/>
<a href="webmasters.php?wap=add">Add site</a><br/>
<!-- End wml -->
<p style="display:none;">
<?
}
?>
<?if($WAP==2){echo('</p></body></html>');}else{echo('</p></card></wml>');}?>