GB Top+HOTWAPI.COM TOPLIST Installation Guide

Requirements:

- PHP 4.1, ionCube PHP Loader (recommended)

Manual installation:

1. Upload Hotwapi.zip into root directory And unzip
2. backupfiles, datafiles, memberfiles, templates and chmod these subdirectories and root directory to 777
3.all html-files into templates directory and chmod these files to 666
4. Chmod config.php to 666
5. Edit Config.php
$scripts_path="http://hotwapi.com"; //replace your site URL
$sitename="hotwapi.com-wap toplist";
$email="info@hotwapi.com";
6. Go to http://domain.com/admin.php
pass: 12345  and press UPDATE 
ENJOY

if you get ionCube error:
1. Download ionCube PHP Loader for your server http://www.ioncube.com/loaders.php
2. Upload ionCube PHP Loader into directory "ioncube"

Updating of old versions:
- Upload all php files, exclude config.php
- Correct new fields in settings
///////////////////////////
This version is gbtop5.4
Dont Update for your sefty