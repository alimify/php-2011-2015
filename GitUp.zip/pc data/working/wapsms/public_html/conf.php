<?php
$dbname = "admin_wapsmsbd";
$dbhost = "localhost";
$dbuser = "admin_wapsmsbd";
$dbpass = "G5bT9aBaR1";
?>
