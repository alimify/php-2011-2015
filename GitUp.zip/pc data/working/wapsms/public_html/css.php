<style>body {max-width: 700px; display: block; margin:0 auto;font-size: 12px; font-family: verdana, "Comic Sans MS",Helvetica,sans-serif;margin-top: 0px;margin-right: auto;margin-bottom: 0px;margin-left: auto;padding: 0px;width: 100%;}
.h1 {text-align:center;font-weight:bold; background-color: #007777 ; color: #ffffff; border-width: 1px; border-color: #007777 ; border-style: solid; padding-top: 2px; padding-bottom: 1px; padding-left: 2px; margin-top: 2px; margin-left: 1px; margin-right: 1px; }
h1 {font-size:10px;padding:none;}
h2{font-weight:small;font-size:10px;}
.footer a , .h1 a { color: #ffffff; font-weight:bold;}
a {color: #007777 ; text-decoration: none;font-weight: normal}
.h1 a {color:#fff;padding:5px}
.fmenu:nth-child(odd){background-color: #f5f5f5 ; color: #000000 ; border-bottom-width: 1px; border-bottom-color: #e5e5e5; border-bottom-style: solid; padding-top: 4px; padding-bottom: 4px; padding-left: 4px; padding-right: 4px;padding-top: 5px;}
.fmenu:nth-child(odd) a { color: #007777; }
.fmenu:nth-child(even) { background-color: #ffffff; color: black ; border-bottom-width: 1px; border-bottom-color: #e5e5e5; border-bottom-style: solid; padding-top: 4px; padding-bottom: 4px; padding-left: 4px; padding-right: 4px;padding-top: 5px; }
.fmenu:nth-child(even) a { color: #007777 ; }
.paging {margin: 0px;
font-size: 0px; text-align:center;}
.paging a {padding: 7px;font-weight:normal; color: black; display: inline-block;
background: #fff; border: 1px solid #abc; margin: 2px;font-size: 15px; text-decoration: none; }
.paging b, .paging a:hover {color: white; display: inline-block; background: #3D9F08; margin: 2px;
padding: 7px; font-size: 15px;font-weight:normal}
.sms a { color: #007777; }
.share{text-align:center;}
.path {padding-bottom:5px;padding-top:5px;}
.user {padding-bottom:5px;}
.textarea {padding-bottom:7px;padding-top:7px;}
.box { background-color: #ffffff; color: #000000; border-width: 1px; border-color: #007777; border-bottom-style: solid; padding-top: 3px; padding-bottom: 3px; padding-left: 2px; padding-right: 0px; margin-left: 1px; margin-right: 1px; border-left-style: solid; border-right-style: solid; }
.logo { padding:5px;background-color: #007777 ; color: #ffffff; border-width: 1px; border-color: #007777 ; border-style: solid; padding-top: 2px; padding-bottom: 1px; padding-left: 2px; margin-top: 2px; margin-left: 1px; margin-right: 1px; }
.logo a , .logo a { color: #ffffff; font-weight:bold;}
a {color: #3b5998 ; text-decoration: none;font-weight: normal}
.logo a {color:#fff}
.smsbox {background:#fff;border-color:#ccced3 #c4c6ca #b4b6ba;border-style:solid;border-width:1px;margin:0 6px 6px;padding:6px;}
.utem { background-color: #ffffff; color: black ; border-bottom-width: 1px; border-bottom-color: #e5e5e5; border-bottom-style: solid; padding-top: 5px; padding-bottom: 4px; padding-left: 4px; padding-right: 4px; }
.utem a { color: #007777 ; }.bos { background-color: #ffffff; color: #000000; border-width: 1px; border-color: #007777;padding-top: 3px; padding-bottom: 3px; padding-left: 2px; padding-right: 0px; margin-left: 1px; margin-right: 1px; border-style: solid; }</style>