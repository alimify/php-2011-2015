<?php
if($mysql_status){print '<div class="bos"><b>Setting | Help | Report | <a href="/logout.php"><b>Logout</b></a>('.$mysql_name.')</b></div>';}
print '<div class="h1">WapsmsBD.Com - 2015</div>';
?>