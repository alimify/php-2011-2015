<?php
//Enable compression? (1 or 0)
$zip = 1;
//Number of files on the page:
$filestr = 6;
//The number of folders on the page:
$dirstr = 20;
//Filelist
$allfile = 'thm,apt,apk,nth,mp3,amr,wav,mmf,mid,jpg,JPG,gif,GIF,png,3gp,avi,mp4,swf,sis,sisx,sys,jar,zip,rar';
//The length and height of the image for preview
$neww = 40;
$newh = 40;
//Number of comments per page:
$kommstr = 9;

// PCLZIP
$pclzip = 'pclzip.lib.php';
// ID
$mp3 = 'id.php'; // ibid should be pear.php



// Top
//SEO
$top = '<?xml version="1.0" encoding="UTF-8" ?><!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head><meta name="google-site-verification" content="Ls0e5jl41RDZEGjc6N7soAaaNlTOSsYW357wfF6X9Xk" /><meta content="chrome=1" http-equiv="X-UA-Compatible"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0; maximum-scale=1.0;"/>
<meta name="revisit-after" content="1 days"/>
<meta content="10" name="pagerank™" />
<meta content="1,2,3,10,11,12,13,ATF" name="serps"/>
<meta content="5" name="seoconsultantsdirectory"/>
<meta content="MD Zisan" name="author"/>
<meta content="General" name="Rating"/>
<meta content="never" name="Expires"/>
<meta content="all" name="audience"/>
<meta content="english" name="Language" />
<meta name="format-detection" content="telephone=no"/>
<meta name="HandheldFriendly" content="true"/>
<meta name="robots" content="index,follow"/><meta name="distribution" content="global"/><meta name="Identifier-URL" content="http://wapsmsbd.com"/><meta http-equiv="Cache-control" content="no-cache">';
// Bottom
$foot = '</body></html>';







?>