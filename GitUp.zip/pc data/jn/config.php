<?php
$url = "http://bdboys.net";
$site = "BDBOYS.NET";
$ads = '<div class="ad"><a href="//bdboys.net">Unlimited Free Downloads Portal</a></div>';
$home = "bdboys.net";
$voice = "ON"; // ON or OFF
$day = "1"; // Stored File deleted times
/* MP3 Tag Settings */
$albumart = "Art.jpg";
$mp3_album = "www.bdboys.net";
$mp3_artist = "www.bdboys.net";
$mp3_composer = "www.bdboys.net";
$mp3_copyright = "www.bdboys.net";
$mp3_comment = "Various Songs Available On bdboys.net";
$mp3_genre = "bdboys.net";
$mp3_year = "2014";
$mp3_original_artist = "bdboys.net";
$mp3_encoded_by = "www.bdboys.net";
?>
