<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><link rel="stylesheet" href="./css/mixbd.com.css" type="text/css" /><title>Read The Disclaimer Of MixBD.CoM</title></head><body><div class="title"><center>Read Disclaimer</center></div><div class="item1"><img src="arrow.gif">   Please Read The Disclaimer Before Download Anything From MixBD.CoM</div><div class="item2"><img src="arrow.gif">   This is a promotional WAPSITE only, All files placed here are for introducing purpose only.</div>
<div class="item1"><img src="arrow.gif">   Please, buy original Songs/contents from author or developer site!</div>
<div class="item2"><img src="arrow.gif">   If you do not agree to all the terms, please disconnect from this site now itself.</div>
<div class="item1"><img src="arrow.gif">   By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth</div>
<div class="item2"><img src="arrow.gif">   All files found on this site have been collected from various sources across the web and are believed to be in the "public domain"..</div>
<div class="item1"><img src="arrow.gif">   All the logos and stuff are the property of their respective owners!</div>
<div class="item2"><img src="arrow.gif">   If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, Please <a href="contact.php">Contact Us</a> We will remove it in 24 hour!.</div>
<div class="footer"><center>&#169; <a href="http://MixBD.CoM">MixBD.CoM</a> 2012<br/>All Rights Reserved</center></div>
</body></html>
