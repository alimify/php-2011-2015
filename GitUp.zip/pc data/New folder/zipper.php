<?php
$id = $_GET['id'];

print '<head><link rel="shortcut icon" href="http://www.bollyclassic.com/uploads/favicon.ico"/><link rel="stylesheet" href="/css/style.css" type="text/css" /><title>Download Full Album As Zip</title></head><center><h2>Full Zip File Downloader</h2><a href="/zd.php?id='.$id.'&type=320"><b>Original Quality Zip Download</b></a><br/><br/><a href="/zd.php?id='.$id.'&type=64"><b>64KBPS Quality Zip Download</b></a><br/><br/><a href="/zd.php?id='.$id.'&type=128"><b>128KBPS Zip Download</b></a></center>'

?>