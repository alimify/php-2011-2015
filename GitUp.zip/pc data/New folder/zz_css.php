<?php
$css = '.Logo {background-color:#007777 ;background:url(bgi.png) repeat-x;border-bottom:1px solid #ddd;}
.Blackborder { background-color: #cff4bd; text-align: center; padding: 4px; border-bottom: 1px  dashed #a00; }
h1{font-weight:bold;text-align:center; color:#fff; font-size:120%; margin: 0;padding: 4px;
background:#007777 ; border:2px solid #97B0D6;border-width:2px 0;
}
.update{ border-bottom:1px solid #ddd; padding:3px;padding-top:4px; }
.foot{font-weight:bold; text-align:center; color:#fff; font-size:120%; padding:4px; 
background:#007777 ; border:2px solid #97B0D6;border-width:2px 0; 
}
.dbtn{background-color: #f5f5f5; width: 50%; margin: 10px; border: 1px solid #ccc; padding: 10px;} .button3:hover { -moz-box-shadow: 0 0 5px rgba(0,0,0,0.5); -webkit-box-shadow: 0 0 5px rgba(0,0,0,0.5); box-shadow: red(0,0,0,0.5); }
.folder,.file	{ border-top:1px solid #ddd; font-weight:bold;padding-top:2px;padding-bottom:2px; }
.folder a,.file a{ padding:5px; display:block;}
.folder:hover,
.file:hover { 
background:#EDEDED; 
background: -moz-linear-gradient(top, #d4eaf3 0%, #d4eaf3 100%); 
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#d4eaf3), color-stop(100%,#d4eaf3)); 
background: -webkit-linear-gradient(top, #d4eaf3 0%, #d4eaf3 100%); 
}
h2{margin:0;text-align:center;font-weight:small;font-size:80%;}
.sorting{text-align:center;}
body {background: ;
color: #000000;
}
a { color: teal;
}
.pnum{text-align:center;background-color:#eee;}
.pgn a{border:1px solid #ddd;padding:2px 5px;margin:0 1px;background:#eee;-moz-border-radius:3px;-webkit-border-radius:3px;border-radius:3px;text-decoration:none;font-weight:bold}
.pgn a:hover,.newpgn span{background:#ddd;border-color:#ddd}.pgn div{padding-top:5px}
.pgn form{padding-top:5px}
.path{padding:3px;margin:5px 0;border-top:1px solid #eee;border-bottom:1px solid #eee;}
.src{margin-left: 0px; margin-right: 0px; margin-bottom: 0px; margin-top: 1px; background-color: #fff; }
body { font:12px arial,helvetica,geneva,swiss,sunsans-regular; margin:0 }

a:focus,a:hover { text-decoration:none}

.update a:hover{ font-weight: bolder; font-size: 14px;}
input[type=text],textarea{font-size:big; }input[type=submit]{background: #007777;border-top:1px solid #007777;border-bottom:1px solid #007777;border-left:1px solid #007777;border-right:1px solid #007777;color:#ffffff;margin:1px;padding-right: 7px; padding-left:7px; padding-top: 2px;padding-botttom: 2px; font-size:big;}

hr{ background-color:#ccc; border:medium none; height:1px; margin:2px 0; padding:0;}a {text-decoration:none;} a:active {color: #622222;} a:focus, a:hover { color: #282828;}
 span.c2 {color: green}
 div.c1 {text-align: center}
';
?>