<?php  
print '<div class="logo" align="center"><img src="/logo.png" alt="AnyMaza.Com" title="AnyMaza.Com" /></div>'; ?>