<?php
$css = '<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	 <style type="text/css">
      	body {
	        background-color: #f5f5f5;
			
	}
	.dlnk {padding:3px;
	border-bottom:1px solid #ddd;}
@media only screen and (min-width:600px){body{max-width: 700px;
			margin: 0 auto 20px;
			border-left:1px solid #ddd;
			border-right:1px solid #ddd;}}
.head{ text-align:center; background:#eee; color:#222; border:1px solid #ddd; font-size:120%; padding:2px;font-size:30px;padding-bottom:10px; }
.foot{ text-align:center; background:#eee; color:#222; border:1px solid #ddd; font-size:120%; padding:2px;font-weight:bold; }	
	.download {
	        max-width: 450px;
		 padding: 19px 29px 29px;
	        margin: 0 auto 20px;
	        background-color: #fff;
	        border: 1px solid #e5e5e5;
	        -webkit-border-radius: 5px;
	           -moz-border-radius: 5px;
	                border-radius: 5px;
	        -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
	           -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
	                box-shadow: 0 1px 2px rgba(0,0,0,.05);
      }

      .download .download-heading {
      		text-align:center;
        	margin-bottom: 10px;
      }

      .mime, .itag {
      		width: 75px;
		display: inline-block;
      }

      .itag {
      		width: 15px;
      }
      
      .size {
      		width: 20px;
      }

      .userscript {
        	float: right;
       		margin-top: 5px
      }
	  
	  #info {
			padding: 0 0 0 130px;
			position: relative;
			height:100px;
	  }
	  
	  #info img{
			left: 0;
			position: absolute;
			top: 0;
			width:120px;
			height:90px
	  }
    </style>';
	
	?>