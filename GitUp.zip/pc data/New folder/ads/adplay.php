<div id="adplayBannerTop"></div>
<script>
    loadAdPlayAds({
        pos: "1",
        pid: "EAF660BD-F93A-40C8-BDD3-2B343EB5F311",
        aspid: "8D8D3054-3C79-436E-B83B-9440094F07F1",
        divId: "adplayBannerTop"
    });
</script>