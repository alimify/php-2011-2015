<?php
///////////////////////sms sharing with mysql and admin panel beta 
/*

shared and made by wapadmin.info from mobtop

miss you rey :)
report bugs at bugs[at]wapadmin.info

/*/
$dbuser="admin_data";               //Database User Username
$dbpass="E3CtTnM2Ap";                    //Database User Password
$dbserver="localhost";          //Database Server(Usually "Localhost")
$dbname="admin_anymaza";        //Database Name
               
?>