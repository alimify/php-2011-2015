<?php
///////////////////////sms sharing with mysql and admin panel beta 
/*

shared and made by wapadmin.info from mobtop

miss you rey :)
report bugs at bugs[at]wapadmin.info

/*/
$dbuser="data";               //Database User Username
$dbpass="uzehyty3a";                    //Database User Password
$dbserver="localhost";          //Database Server(Usually "Localhost")
$dbname="zadmin_filemanager";        //Database Name
               
?>