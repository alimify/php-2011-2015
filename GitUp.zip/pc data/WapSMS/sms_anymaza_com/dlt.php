<?php
$a =$_GET['a'];
if ($a == "0"){ echo sms; exit;}
if ($a == "1"){ echo folder;}
else { echo invalid; }
?>