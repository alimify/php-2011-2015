<?php
$dbname = "zadmin_wapsmsbd";
$dbhost = "localhost";
$dbuser = "sms";
$dbpass = "zyha6ugug";
?>
