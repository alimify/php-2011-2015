<?php
$cid = $_GET['cid'];
print '<head><link rel="stylesheet" href="/m.css" type="text/css" /><title>Warning !</title></head>';
print '<div class="box"><div class="h1">Warning !</div>Hi,Your are going to adult content.its maybe harmful to your mind,we request if you are less then 18- please exit it.or if you agreed <font color="red">18+</font> you can continue<br/><a href="/2/Adult Sms.html"><b>Enter</b></a> | <a href="/index.php"><b>Exit</b></a></div>';
?>