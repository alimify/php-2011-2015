<?php
///////////////////////sms sharing with mysql and admin panel beta 
/*

shared and made by wapadmin.info from mobtop

miss you rey :)
report bugs at bugs[at]wapadmin.info

/*/
$dbuser="sms";               //Database User Username
$dbpass="zyha6ugug";                    //Database User Password
$dbserver="localhost";          //Database Server(Usually "Localhost")
$dbname="zadmin_wapsmsbd";        //Database Name
$site_name="WapSmsBd.Com";                 
$site_url="http://wapsmsbd.com/test/";       
$admin_email="jewelworld9@gmail.com";
$site_theme="default";               
$site_logo="images/logo.png";         
$gzip="on";                        
$script_timer="on";                 
$site_active="on";                
?>